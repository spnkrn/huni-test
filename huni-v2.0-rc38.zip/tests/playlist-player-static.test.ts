import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const page = readFileSync("src/app/playlists/[id]/page.tsx", "utf8");
const controls = readFileSync("src/app/playlists/[id]/playlist-player-controls.tsx", "utf8");
const api = readFileSync("src/app/api/playlists/[id]/tracks/route.ts", "utf8");

describe("playlist player integration static contract", () => {
  it("uses the canonical player batch API for Play All and Shuffle", () => {
    expect(page).toContain("PlaylistPlayerControls");
    expect(controls).toContain("playTracks(tracks, 0, false)");
    expect(controls).toContain("playTracks(tracks, 0, true)");
  });

  it("does not retain the old single-track playlist Play action", () => {
    expect(page).not.toContain("play(tracks[0])");
  });

  it("keeps playlist mutations protected", () => {
    expect(api).toContain("sameOrigin(request)");
    expect(api).toContain("rateLimit(`playlist-track:");
    expect(api).toContain("isTrack(body.track)");
  });
});
