# Huni 2.0 RC24

## Qobuz normalized metadata search wiring

- Wired the authorized server-side Qobuz normalized metadata gateway into `/api/search`.
- Search now passes the user's saved content region to Qobuz.
- Qobuz search results are merged with iTunes results instead of replacing the Apple catalog.
- Qobuz is first in the merge order when configured, allowing the deployment to prefer Qobuz metadata while retaining iTunes fields/providers where available.
- MusicBrainz artist matches continue to enrich the merged artist results.
- Added deterministic artist, album and track de-duplication using normalized music identity fields.
- If Qobuz is unavailable or unconfigured, iTunes remains the search fallback.
- If both providers fail, the API returns a truthful 502 instead of fabricated results.

## Validation

- Static QA passed for 18 API route files.
- Security audit passed for 18 API route files.
- Full TypeScript/Vitest/Next production certification remains environment-dependent because the project does not have a generated package-lock and the npm registry is unavailable in the build environment.
