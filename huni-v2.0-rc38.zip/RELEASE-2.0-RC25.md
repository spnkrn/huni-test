# Huni 2.0 RC25 — Provider provenance

## Added

- Added a shared provider provenance component for detail pages.
- Artist, album, and song pages now show the actual metadata identities present on the returned canonical model.
- Supported provenance labels are Qobuz, Apple Music / iTunes, and MusicBrainz.
- Pages show a `Merged` indicator when more than one provider identity is attached to the same entity.
- Provenance is derived only from existing `providerIds`; no provider is displayed when its identifier is absent.
- Added static regression coverage for the provenance component and all three detail pages.

## Verification

Static QA and security audit should be run in the release environment. Full dependency-backed TypeScript, Vitest, ESLint, and Next production build certification remains environment-dependent until npm dependencies and a package lockfile are available.
