# Huni 2.0.0 RC.10

## Phase
Playback session isolation and final static hardening.

## Changes
- Playback session persistence now uses the server-only Supabase admin client.
- Added migration `0004_playback_sessions_server_managed.sql` to remove client-facing RLS policies from `playback_sessions`.
- Provider playback URLs remain AES-256-GCM encrypted at rest.
- Cleaned the static API QA route-count notice to the current 15 routes.
- Added static tests covering server-managed playback storage, RLS policy removal, and encryption-at-rest invariants.

## Verification
- Static API QA: passed (15 API route files).
- Security audit: passed (15 API route files).
- Node syntax checks for release/static scripts: passed.
- Dependency install, typecheck, lint, Vitest, and Next production build: still blocked in this environment because the npm registry cannot be resolved and no package-lock.json/node_modules are present.
