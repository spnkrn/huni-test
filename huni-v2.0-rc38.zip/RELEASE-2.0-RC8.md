# Huni 2.0.0 RC.8

## Phase
Playback token validation and stream-boundary hardening.

## Changes
- Strict Zod validation for signed playback claims.
- UUID validation for playback session and authenticated user IDs.
- Bounded canonical track/provider identifiers.
- Token size bound before signature processing.
- Stream proxy emits `X-Content-Type-Options: nosniff`.
- Download proxy uses a generic attachment filename and never exposes the upstream URL.
- Version bumped to `2.0.0-rc.8`.

## Verification
Static/security checks are dependency-free and must pass before packaging. Full typecheck, lint, tests, and production build remain dependent on installing the npm dependency tree with a generated `package-lock.json`.
