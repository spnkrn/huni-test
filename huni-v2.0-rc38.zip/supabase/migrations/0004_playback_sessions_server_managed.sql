-- Playback sessions are a server-managed capability store.
-- The application server uses the Supabase secret/service-role key, which bypasses RLS.
-- Remove client-facing policies so authenticated users cannot mint, alter, or delete sessions.
alter table public.playback_sessions enable row level security;

drop policy if exists "playback_sessions_self_select" on public.playback_sessions;
drop policy if exists "playback_sessions_self_insert" on public.playback_sessions;
drop policy if exists "playback_sessions_self_update" on public.playback_sessions;
drop policy if exists "playback_sessions_self_delete" on public.playback_sessions;
