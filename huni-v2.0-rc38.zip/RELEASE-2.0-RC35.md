# Huni 2.0 RC35

## Library + Discovery continuity

- Added podcast following/subscriptions.
- Anonymous follows are stored in the versioned Huni local store.
- Authenticated follows sync to Supabase through `/api/podcast-follows`.
- Added Supabase migration `0005_podcast_follows.sql` with RLS.
- Podcast channel pages expose a Follow/Following control.
- Existing music and podcast history/progress/library/favorites/playlists/downloads remain shared through the media model.
- Local store migrated from v1 to v2 without dropping existing anonymous library data.
