import { NextRequest, NextResponse } from "next/server";
import { withApiHeaders } from "@/lib/security/api";
import { getUserContentRegion } from "@/lib/region";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: NextRequest) {
  const { region, userId } = await getUserContentRegion();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401, headers: withApiHeaders(req) });
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return NextResponse.json({ email: user?.email ?? "", region }, { headers: withApiHeaders(req) });
}
