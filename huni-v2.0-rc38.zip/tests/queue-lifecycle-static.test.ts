import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("queue lifecycle source", () => {
  const source = readFileSync(resolve(process.cwd(), "src/components/player/player-context.tsx"), "utf8");

  it("persists queue and playback mode together", () => {
    expect(source).toContain('"huni-player-state"');
    expect(source).toContain("playerStateHydrated");
    expect(source).toContain("{ queue, index, shuffle, repeat }");
  });

  it("validates restored queue tracks", () => {
    expect(source).toContain("const restoredQueue = Array.isArray(parsed?.queue) ? parsed.queue.filter(isTrack) : Array.isArray(legacyParsed) ? legacyParsed.filter(isTrack) : []");
  });

  it("clears pending playback before clearing the queue", () => {
    expect(source).toContain("sessionRequestRef.current?.abort()");
    expect(source).toContain("setQueue([])");
    expect(source).toContain("setIndex(0)");
  });

  it("exposes explicit queue removal and clearing", () => {
    expect(source).toContain("removeFromQueue");
    expect(source).toContain("clearQueue");
  });
});
