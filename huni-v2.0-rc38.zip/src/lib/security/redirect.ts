/** Accept only same-origin relative paths for auth redirects. */
export function safeNextPath(value: string | null | undefined, fallback = "/library") {
  if (!value) return fallback;
  try {
    if (!value.startsWith("/") || value.startsWith("//")) return fallback;
    const parsed = new URL(value, "https://huni.invalid");
    if (parsed.origin !== "https://huni.invalid") return fallback;
    return `${parsed.pathname}${parsed.search}${parsed.hash}`;
  } catch {
    return fallback;
  }
}
