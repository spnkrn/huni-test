import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("local-first account boundary", () => {
  it("has a versioned local store and auth sync provider", () => {
    const store = readFileSync("src/lib/local-store.ts", "utf8");
    const provider = readFileSync("src/components/library/local-library-provider.tsx", "utf8");
    expect(store).toContain('"huni-local-store-v1"');
    expect(store).toContain("favorites");
    expect(store).toContain("playlists");
    expect(provider).toContain("SIGNED_IN");
    expect(provider).toContain("syncToAccount");
  });
  it("keeps account-only middleware boundaries limited to protected areas", () => {
    const proxy = readFileSync("src/lib/supabase/proxy.ts", "utf8");
    expect(proxy).toContain('["/settings", "/admin"]');
    expect(proxy).not.toContain('["/library", "/playlists", "/settings", "/admin"]');
  });
});
