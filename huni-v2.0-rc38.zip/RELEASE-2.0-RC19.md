# Huni 2.0 RC.19

## Library ↔ Player integration

- Added `playTracks()` to the player context for replacing the active queue with a validated batch of tracks.
- Added Library **Play all** and **Shuffle library** controls.
- Batch playback invalidates pending playback work and clears the previous authorized session before starting the new queue.
- Library rows now receive stable display indexes.
- Added static coverage for library batch-play integration and queue/session replacement.

## Verification

Static source checks can run without installing npm dependencies. Dependency-backed typecheck, lint, Vitest, and Next production build remain dependent on a working npm registry and a generated lockfile.
