# Deployment

1. Install dependencies with Node 20+.
2. Configure `.env.local` from `.env.example`.
3. Set a real MusicBrainz User-Agent.
4. Run `npm run typecheck`, `npm test`, `npm run build`.
5. Deploy to a Next.js-compatible runtime.
6. Add a persistent cache and API rate limiter for multi-user production.
7. Configure an authorized audio provider before advertising full-length playback.

## v1.4 production gate

For a single-instance deployment, the built-in limiter provides a baseline. For horizontally scaled/serverless production, configure a shared rate limiter (for example Redis/Upstash or an equivalent managed store) and key it by authenticated subject plus trusted client IP where appropriate.

Do not expose provider URLs in application logs. Use the `X-Request-ID` returned by API routes to correlate failures with server logs.

Recommended release sequence:

1. `npm ci`
2. `npm run verify:env`
3. `npm run typecheck`
4. `npm test`
5. `npm run test:security`
6. `npm run build`
7. Apply Supabase migrations.
8. Smoke-test auth, library, playlist, search, lyrics and playback-session authorization.

## v1.5 Release Candidate gate

Run these in a clean CI/deployment environment:

```text
npm ci
npm run verify:env
npm run typecheck
npm test
npm run test:security
npm run build
```

For more than one application instance, replace the included process-local rate limiter with a shared atomic store before production traffic. The process-local limiter is intentionally best-effort and does not provide a global quota across instances.
