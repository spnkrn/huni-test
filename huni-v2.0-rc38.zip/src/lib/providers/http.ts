import { z } from "zod";
import dns from "node:dns/promises";
import net from "node:net";

const responseSchema = z.object({
  sessionId: z.string().min(1),
  expiresAt: z.string().datetime(),
  streamUrl: z.string().url(),
  downloadUrl: z.string().url().optional(),
});

function allowedHosts() {
  return (process.env.HUNI_AUDIO_PROVIDER_ALLOWED_HOSTS ?? "")
    .split(",").map((v) => v.trim().toLowerCase()).filter(Boolean);
}

export function assertSafeUrl(raw: string) {
  const url = new URL(raw);
  if (url.protocol !== "https:") throw new Error("Audio provider URLs must use HTTPS.");
  const hosts = allowedHosts();
  if (!hosts.length || !hosts.includes(url.hostname.toLowerCase())) {
    throw new Error("Audio provider URL is not on the configured allowlist.");
  }
  return url.toString();
}

export async function callAuthorizedAudioGateway(input: {
  track: unknown;
  userId: string;
  provider: string;
}) {
  const endpoint = process.env.HUNI_AUDIO_PROVIDER_GATEWAY_URL;
  if (!endpoint) throw new Error("Authorized audio gateway is not configured.");
  assertSafeUrl(endpoint);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(input),
      cache: "no-store",
      redirect: "manual",
      signal: controller.signal,
    });
    if (response.status >= 300 && response.status < 400) throw new Error("Audio gateway redirects are not allowed.");
    if (!response.ok) throw new Error(`Audio gateway failed: ${response.status}`);
    const parsed = responseSchema.safeParse(await response.json());
    if (!parsed.success) throw new Error("Audio gateway returned an invalid playback session.");
    assertSafeUrl(parsed.data.streamUrl);
    if (parsed.data.downloadUrl) assertSafeUrl(parsed.data.downloadUrl);
    return parsed.data;
  } finally {
    clearTimeout(timer);
  }
}

export async function assertSafePodcastUrl(raw: string) {
  const url = new URL(raw);
  if (url.protocol !== "https:") throw new Error("Podcast URLs must use HTTPS.");
  const host = url.hostname.toLowerCase();
  if (["localhost", "localhost.localdomain"].includes(host) || host.endsWith(".local")) throw new Error("Private podcast hosts are not allowed.");
  if (net.isIP(host)) {
    if (host === "127.0.0.1" || host === "::1" || host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("169.254.")) throw new Error("Private podcast hosts are not allowed.");
    const parts = host.split(".").map(Number);
    if (parts.length === 4 && parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) throw new Error("Private podcast hosts are not allowed.");
    return url.toString();
  }
  const records = await dns.lookup(host, { all: true });
  if (!records.length) throw new Error("Podcast host could not be resolved.");
  for (const record of records) {
    const ip = record.address;
    if (ip === "127.0.0.1" || ip === "::1" || ip.startsWith("10.") || ip.startsWith("192.168.") || ip.startsWith("169.254.") || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(ip) || ip.startsWith("fc") || ip.startsWith("fd") || ip.startsWith("fe80:")) throw new Error("Private podcast hosts are not allowed.");
  }
  return url.toString();
}
