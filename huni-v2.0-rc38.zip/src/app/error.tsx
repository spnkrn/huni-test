"use client";

import { useEffect } from "react";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {}, []);
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-xl items-center justify-center text-center">
      <div className="glass rounded-3xl p-8">
        <div className="eyebrow">Something went wrong</div>
        <h1 className="mt-3 text-2xl font-semibold">Huni hit an unexpected error.</h1>
        <p className="mt-3 text-sm leading-6 text-white/45">Your library and account data are not intentionally changed by this error. Try again or return home.</p>
        <button type="button" onClick={() => reset()} className="mt-6 rounded-xl bg-white px-4 py-2 text-sm font-medium text-black hover:bg-white/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70">Try again</button>
      </div>
    </div>
  );
}
