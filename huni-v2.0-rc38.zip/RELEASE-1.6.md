# Huni 1.6 — Release Candidate QA Gate

## Completed in this phase

- Closed the auth callback open-redirect path with same-origin relative-path validation.
- Applied the same redirect validation before client-side login/signup navigation.
- Added regression tests for internal, absolute, protocol-relative, and fallback redirect values.
- Included the redirect test in `npm run test:security`.
- Bumped the package version to `1.6.0`.

## Required clean-environment validation

Run in a clean checkout with network access:

```bash
npm ci
npm run verify:env
npm run typecheck
npm test
npm run test:security
npm run build
```

This repository intentionally does not claim these commands passed in the artifact-building environment when dependency installation is unavailable or times out.

## Production sign-off

Before launch, confirm:

- Supabase migrations are applied in order.
- RLS is enabled for all user-owned tables.
- Admin IDs are explicitly configured.
- `PLAYBACK_SESSION_SECRET` is high entropy and server-only.
- Audio provider credentials are server-only and authorized for the intended use.
- A shared rate-limit store is used for multi-instance production deployments.
- Monitoring scrubs credentials, cookies, access tokens, and signed media URLs.
- Auth redirect URLs are restricted to the Huni origin.
- Private API/audio responses are excluded from service-worker/CDN caching.
