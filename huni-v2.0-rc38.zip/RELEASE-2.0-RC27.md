# Huni 2.0 RC27 — First-class Podcast Playback

## Highlights

- Podcast episodes now behave as first-class playable media across shared Huni surfaces.
- Library and Favorites copy explicitly includes podcast episodes.
- Shared TrackRow routes podcast episodes back to their podcast channel instead of a music song page.
- Queue and mini-player identify podcast items clearly while retaining the same controls and player.
- Podcast episode tracks preserve their Apple/iTunes identity when available.
- Shared player sleep timer now exposes presets: 15, 30, 45, 60, 90 minutes, plus Off.
- Queue playback de-duplicates duplicate track IDs while preserving the requested starting item.
- Direct `play(track)` now updates queue and index from one consistent next-queue snapshot.

## Verification

Static regression coverage added for podcast routing, provenance preservation, and sleep timer presets.

Full dependency-backed TypeScript/Vitest/Next build remains environment-dependent when dependencies are not installed.
