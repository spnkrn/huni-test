"use client";
import { useLocalLibrary } from "@/components/library/local-library-provider";
import { TrackRow } from "@/components/music/track-row";
import { FavoriteControls } from "./favorite-controls";
export default function FavoritesPage(){const{userId,favorites}=useLocalLibrary();return <div className="mx-auto max-w-5xl"><div className="eyebrow">Favorites</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Your favorites</h1><p className="mt-2 text-sm text-white/40">{userId?'Favorites are synced to your Huni account.':'Favorites are stored locally on this device until you sign in.'}</p>{favorites.length?<><FavoriteControls tracks={favorites}/><div className="mt-8 space-y-2">{favorites.map((track,index)=><TrackRow key={track.id} track={track} index={index+1}/>)}</div></>:<div className="glass mt-10 rounded-2xl p-12 text-center text-sm text-white/35">No favorites yet. Favorite a song or podcast episode to see it here.</div>}</div>}
