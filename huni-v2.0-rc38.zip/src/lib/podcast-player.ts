import type { Track } from "@/lib/types";
import type { PodcastEpisode } from "@/lib/podcast-types";

export function episodeToTrack(episode: PodcastEpisode, podcastTitle: string, author: string): Track {
  const guid = episode.guid ?? episode.id;
  const raw = JSON.stringify({ podcastId: episode.podcastId.replace(/^podcast-/, ""), guid });
  const bytes = new TextEncoder().encode(raw);
  const binary = Array.from(bytes, byte => String.fromCharCode(byte)).join("");
  const payload = btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  return {
    id: `podcast-episode-${payload}`,
    mediaType: "podcast",
    podcastId: episode.podcastId,
    podcastTitle,
    title: episode.title,
    artists: [{ id: `podcast-author-${encodeURIComponent(author)}`, name: author, providerIds: {} }],
    album: { id: episode.podcastId, title: podcastTitle, artwork: episode.artwork ? { small: episode.artwork, medium: episode.artwork, large: episode.artwork } : undefined },
    durationMs: episode.durationMs,
    releaseDate: episode.publishedAt,
    artwork: episode.artwork ? { small: episode.artwork, medium: episode.artwork, large: episode.artwork } : undefined,
    providerIds: { itunes: episode.appleUrl },
    description: episode.description,
    chapters: episode.chapters,
    explicit: episode.explicit,
  };
}
