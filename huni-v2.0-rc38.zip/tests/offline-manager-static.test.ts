import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const store = readFileSync("src/lib/offline-store.ts", "utf8");
const button = readFileSync("src/components/music/download-button.tsx", "utf8");
const downloads = readFileSync("src/app/downloads/page.tsx", "utf8");
const podcast = readFileSync("src/app/podcast/[id]/page.tsx", "utf8");

describe("RC34 offline manager", () => {
  it("supports aggregate usage and clearing", () => {
    expect(store).toContain("async usage()");
    expect(store).toContain("async clear()");
    expect(store).toContain("indexedDB");
  });
  it("reports download progress", () => {
    expect(button).toContain("getReader()");
    expect(button).toContain("onProgress");
  });
  it("shows storage and network state", () => {
    expect(downloads).toContain("Offline mode");
    expect(downloads).toContain("Remove all");
    expect(downloads).toContain("usage");
  });
  it("supports batch podcast page downloads", () => {
    expect(podcast).toContain("downloadTrackOffline");
    expect(podcast).toContain("Download page");
  });
});
