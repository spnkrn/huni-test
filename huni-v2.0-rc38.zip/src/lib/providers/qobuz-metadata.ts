import type { Album, Artist, SearchResponse, Track } from "@/lib/types";

/**
 * Server-side Qobuz metadata adapter. Huni intentionally does not embed or
 * invent Qobuz credentials/endpoints in the browser. The deployment's
 * authorized Qobuz integration exposes this normalized metadata gateway.
 */
const endpoint = () => process.env.QOBUZ_METADATA_GATEWAY_URL?.trim();

export type QobuzHome = {
  newReleases?: Album[];
  mostStreamed?: Album[];
  bestsellers?: Album[];
  tracks?: Track[];
};

async function call<T>(operation: string, payload: Record<string, unknown>): Promise<T> {
  const url = endpoint();
  if (!url) throw new Error("Qobuz metadata gateway is not configured.");
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ operation, ...payload }),
    cache: "no-store",
    signal: AbortSignal.timeout(10_000)
  });
  if (!res.ok) throw new Error(`Qobuz metadata gateway failed: ${res.status}`);
  return res.json() as Promise<T>;
}

export const qobuzMetadata = {
  isConfigured: () => Boolean(endpoint()),
  home: (country: string) => call<QobuzHome>("home", { country }),
  search: (query: string, country: string) => call<SearchResponse>("search", { query, country }),
  artist: (id: string, country: string) => call<{ artist: Artist; albums: Album[] }>("artist", { id, country }),
  album: (id: string, country: string) => call<Album>("album", { id, country }),
  track: (id: string, country: string) => call<Track>("track", { id, country })
};
