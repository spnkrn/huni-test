import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("podcast phase static coverage", () => {
  it("keeps Apple/iTunes search and RSS flow server-side", () => {
    const provider = readFileSync("src/lib/providers/podcasts.ts", "utf8");
    expect(provider).toContain('media: "podcast"');
    expect(provider).toContain("feedUrl");
    expect(provider).toContain("<item");
    expect(provider).toContain("episodeUrl");
  });
  it("uses the authenticated playback session for podcast IDs", () => {
    const route = readFileSync("src/app/api/playback/session/route.ts", "utf8");
    expect(route).toContain('startsWith("podcast-episode-")');
    expect(route).toContain('provider: "podcast"');
    expect(route).toContain("storePlaybackSession");
  });
  it("exposes podcast search and paginated channel routes", () => {
    expect(readFileSync("src/app/api/podcasts/route.ts", "utf8")).toContain("searchPodcasts");
    expect(readFileSync("src/app/api/podcasts/[id]/route.ts", "utf8")).toContain("pageSize");
    expect(readFileSync("src/app/podcasts/page.tsx", "utf8")).toContain("Top podcast channels");
    expect(readFileSync("src/app/podcast/[id]/page.tsx", "utf8")).toContain("Filter episodes");
  });
  it("adds the shared sleep timer", () => {
    const player = readFileSync("src/components/player/player-context.tsx", "utf8");
    expect(player).toContain("sleepTimerMinutes");
    expect(player).toContain("setSleepTimer");
  });
});
