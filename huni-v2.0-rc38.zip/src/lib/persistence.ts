import { Track } from "@/lib/types";

export function serializeTrack(track: Track) {
  return track;
}

export function isTrack(value: unknown): value is Track {
  if (!value || typeof value !== "object") return false;
  const t = value as Record<string, unknown>;
  return typeof t.id === "string" && typeof t.title === "string" && Array.isArray(t.artists);
}
