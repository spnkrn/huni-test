import { NextRequest, NextResponse } from "next/server";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";
import { getLyrics } from "@/lib/providers/lrclib";

export async function GET(req: NextRequest) {
  const rate = rateLimit(`api:lyrics:${getRequestFingerprint(req)}`, 60, 60_000);
  const headers = { "X-Request-ID": requestId(req), ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers: { ...headers, "Retry-After": String(Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000))) } });

  const p = req.nextUrl.searchParams;
  const trackName = p.get("track")?.trim();
  const artistName = p.get("artist")?.trim();
  if (!trackName || !artistName) return NextResponse.json({ error: "track and artist are required" }, { status: 400, headers });

  const lyrics = await getLyrics({
    trackName,
    artistName,
    albumName: p.get("album") || undefined,
    duration: p.get("duration") ? Number(p.get("duration")) : undefined
  });

  return NextResponse.json(lyrics, { headers });
}