import fs from "node:fs";
import path from "node:path";

const root = path.resolve("src/app/api");
const files = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name === "route.ts" || entry.name === "route.tsx") files.push(full);
  }
}
walk(root);
const problems = [];
for (const file of files) {
  const source = fs.readFileSync(file, "utf8");
  const rel = path.relative(process.cwd(), file);
  const mutating = /export async function (POST|PUT|PATCH|DELETE)\(/.test(source);
  if (mutating && !source.includes("sameOrigin(request)")) problems.push(`${rel}: missing sameOrigin() guard`);
  if (!source.includes("Cache-Control") && !source.includes("withApiHeaders") && !source.includes("jsonError")) problems.push(`${rel}: no explicit private/no-store response helper detected`);
}
if (problems.length) {
  console.error("Security audit failed:");
  for (const problem of problems) console.error(`- ${problem}`);
  process.exit(1);
}
console.log(`Security audit passed for ${files.length} API route files.`);
