"use client";

import { Download, Loader2, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import type { Track } from "@/lib/types";
import { offlineStore } from "@/lib/offline-store";

async function fetchOfflineAudio(track: Track, onProgress?: (value: number | null) => void) {
  const res = await fetch("/api/playback/session", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ trackId: track.id }), cache: "no-store" });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.downloadUrl) throw new Error(body.error ?? "Download is unavailable.");
  const audio = await fetch(body.downloadUrl, { cache: "no-store" });
  if (!audio.ok || !audio.body) throw new Error("The audio download could not be fetched.");
  const total = Number(audio.headers.get("content-length") || 0);
  const reader = audio.body.getReader();
  const chunks: Uint8Array[] = []; let received = 0;
  while (true) {
    const { done, value } = await reader.read(); if (done) break;
    if (value) { chunks.push(value); received += value.byteLength; onProgress?.(total ? received / total : null); }
  }
  const blob = new Blob(chunks, { type: audio.headers.get("content-type") || "audio/mpeg" });
  if (!blob.size) throw new Error("The downloaded audio was empty.");
  await offlineStore.put(track, blob);
}

export async function downloadTrackOffline(track: Track, onProgress?: (value: number | null) => void) {
  await fetchOfflineAudio(track, onProgress);
}

export function DownloadButton({ track, compact = false }: { track: Track; compact?: boolean }) {
  const [busy, setBusy] = useState(false); const [downloaded, setDownloaded] = useState(false); const [progress, setProgress] = useState<number | null>(null); const [message, setMessage] = useState("");
  const refresh = () => void offlineStore.has(track.id).then(setDownloaded).catch(() => undefined);
  useEffect(() => { refresh(); }, [track.id]);
  useEffect(() => { const onChange = refresh; window.addEventListener("huni-offline-store", onChange); return () => window.removeEventListener("huni-offline-store", onChange); }, [track.id]);
  async function download() { setBusy(true); setMessage(""); setProgress(0); try { await downloadTrackOffline(track, setProgress); setDownloaded(true); setMessage("Saved for offline playback on this device."); window.setTimeout(() => setMessage(""), 3500); } catch (error) { setMessage(error instanceof Error ? error.message : "Download is unavailable."); window.setTimeout(() => setMessage(""), 3500); } finally { setBusy(false); setProgress(null); } }
  async function remove() { setBusy(true); try { await offlineStore.remove(track.id); setDownloaded(false); } finally { setBusy(false); } }
  const label = busy && progress !== null ? `${Math.round(progress * 100)}%` : downloaded ? "Offline" : "Download";
  return <div className="relative"><button onClick={() => void (downloaded ? remove() : download())} disabled={busy} className={compact ? "icon-button" : "inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[.06] px-3 py-2 text-xs text-white/65 hover:bg-white/[.1] hover:text-white disabled:opacity-50"} aria-label={downloaded ? "Remove offline download" : "Download for offline playback"} title={downloaded ? "Remove offline download" : "Download for offline playback"}>{busy ? <Loader2 size={15} className="animate-spin" /> : downloaded ? <Trash2 size={15} /> : <Download size={15} />}{compact ? null : label}</button>{message ? <div className="absolute right-0 top-full z-30 mt-2 w-72 rounded-xl border border-white/10 bg-[#111] p-3 text-[11px] text-white/50 shadow-2xl">{message}</div> : null}</div>;
}
