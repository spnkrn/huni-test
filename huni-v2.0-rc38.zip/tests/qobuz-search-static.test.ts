import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const route = readFileSync("src/app/api/search/route.ts", "utf8");
const gateway = readFileSync("src/lib/providers/qobuz-metadata.ts", "utf8");
const merge = readFileSync("src/lib/providers/catalog-merge.ts", "utf8");

describe("Qobuz normalized search wiring", () => {
  it("calls the normalized Qobuz search gateway with the user's region", () => {
    expect(route).toContain("qobuzMetadata.search(q, region)");
    expect(route).toContain("qobuzMetadata.isConfigured()");
    expect(gateway).toContain('call<SearchResponse>("search", { query, country })');
  });

  it("keeps iTunes and Qobuz as complementary catalog sources", () => {
    expect(route).toContain("mergeSearchResults(qobuz, itunes)");
    expect(merge).toContain("providerIds: { ...incoming.providerIds, ...existing.providerIds }");
    expect(merge).toContain("normalizeMusicText(track.title)");
  });
});
