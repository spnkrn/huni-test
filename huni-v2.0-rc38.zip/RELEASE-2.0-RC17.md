# Huni 2.0 RC.17

## Player UX/state hardening

- Persist player volume and mute state across reloads.
- Restore audio volume/mute state before playback begins.
- Keep Media Session playback state and position synchronized with the audio element.
- Add Media Session seek backward/forward (10 seconds) and seek-to support.
- Improve buffered-range reporting by preferring the range containing the current playback position.
- Keep existing queue, shuffle, repeat, playback-session, and recovery protections.

## Verification

Static/security checks should be run against this release. Full dependency-backed typecheck, tests, lint, and production build remain dependent on installing the pinned npm dependency tree.
