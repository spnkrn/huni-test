# Huni 2.0.0 RC.12

## Phase
Playback upstream redirect and environment hardening.

## Changes
- Playback upstream URLs are revalidated immediately before proxy fetch.
- Playback proxy rejects upstream HTTP redirects instead of following them.
- The authorized audio gateway no longer follows redirects.
- URL allowlist validation is exported for reuse by the playback proxy.
- Environment verification now requires the server Supabase secret and dedicated playback encryption key.
- Added static coverage for redirect and environment hardening.

## Verification
- Static API QA: passed (15 API route files).
- Security audit: passed (15 API route files).
- Node syntax checks: passed.
- Full dependency installation, typecheck, lint, Vitest, and Next production build remain blocked because the npm registry is unavailable in the execution environment and no package-lock.json/node_modules are present.
