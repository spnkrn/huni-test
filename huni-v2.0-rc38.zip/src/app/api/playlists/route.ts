import { NextResponse } from "next/server";
import { bodyWithinLimit, sameOrigin, jsonError, readJson, withApiHeaders } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";

export async function GET(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { data, error } = await supabase.from("playlists").select("id,name,description,artwork_url,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false });
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ playlists: data }, { headers: withApiHeaders(request) });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`playlist:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const body = await readJson<Record<string, unknown>>(request);
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  if (!name || name.length > 100) return jsonError(request, "Playlist name must be 1–100 characters", 400);
  const description = typeof body?.description === "string" ? body.description.trim().slice(0, 500) : null;
  const { data, error } = await supabase.from("playlists").insert({ user_id: user.id, name, description }).select("id,name,description,artwork_url,updated_at").single();
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ playlist: data }, { status: 201, headers: withApiHeaders(request) });
}
