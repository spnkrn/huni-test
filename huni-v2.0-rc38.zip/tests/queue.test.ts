import { describe, expect, it } from "vitest";

type Track = { id: string };

function addQueue(queue: Track[], track: Track) {
  return queue.some(t => t.id === track.id) ? queue : [...queue, track];
}

describe("queue", () => {
  it("does not duplicate a track", () => {
    const a = { id: "a" };
    expect(addQueue([a], a)).toHaveLength(1);
  });
});