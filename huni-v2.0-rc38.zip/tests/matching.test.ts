import { describe, expect, it } from "vitest";
import { matchScore, normalizeIsrc, rankMatches } from "@/lib/matching";

describe("music matching", () => {
  it("normalizes ISRC punctuation", () => {
    expect(normalizeIsrc("US-ABC-12-34567")).toBe("USABC1234567");
  });
  it("prioritizes exact ISRC", () => {
    expect(matchScore({ artist: "A", title: "B", isrc: "USABC1234567" }, { artist: "Wrong", title: "Wrong", isrc: "US-ABC-12-34567" })).toBe(100);
  });
  it("ranks the best candidate first", () => {
    const ranked = rankMatches(
      { artist: "The Artist", title: "Song", album: "Album", durationSec: 180 },
      [
        { value: "weak", candidate: { artist: "Other", title: "Song" } },
        { value: "best", candidate: { artist: "The Artist", title: "Song", album: "Album", durationSec: 181 } },
      ],
    );
    expect(ranked[0].value).toBe("best");
    expect(ranked[0].score).toBe(90);
  });
});
