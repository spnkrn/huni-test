# Huni 2.0 RC36

## Unified Library + Offline UX

- Added Music / Podcasts / Followed Podcasts tabs to Library.
- Followed podcast channels are visible from the authenticated or anonymous local-first library.
- Added All / Music / Podcasts filters to Downloads.
- Preserved IndexedDB offline playback and existing download manager behavior.
- Library remains usable without authentication; local state is the anonymous source of truth until sign-in synchronization succeeds.
- Authenticated library reads continue to use the Supabase-backed API.
- No provider URLs are exposed by the library or downloads UI.

## Regression coverage

- Static route QA and security audit were run against the RC36 source.
- Full dependency-backed Next.js/TypeScript/Vitest certification remains environment-dependent when dependencies are not installed.
