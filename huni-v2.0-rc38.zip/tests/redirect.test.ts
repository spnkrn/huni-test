import { describe, expect, it } from "vitest";
import { safeNextPath } from "@/lib/security/redirect";

describe("safeNextPath", () => {
  it("allows internal paths", () => {
    expect(safeNextPath("/library?tab=saved")).toBe("/library?tab=saved");
  });
  it("rejects absolute URLs", () => {
    expect(safeNextPath("https://evil.example/phish")).toBe("/library");
  });
  it("rejects protocol-relative redirects", () => {
    expect(safeNextPath("//evil.example/phish")).toBe("/library");
  });
  it("uses the fallback for malformed input", () => {
    expect(safeNextPath(undefined, "/")).toBe("/");
  });
});
