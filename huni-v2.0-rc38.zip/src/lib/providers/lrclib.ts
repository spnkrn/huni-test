import { Lyrics, LyricsLine } from "@/lib/types";

const BASE = process.env.LRCLIB_BASE_URL || "https://lrclib.net";

function parseLrc(lrc: string): LyricsLine[] {
  const lines: LyricsLine[] = [];
  for (const raw of lrc.split(/\r?\n/)) {
    const matches = [...raw.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
    const text = raw.replace(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g, "").trim();
    for (const m of matches) {
      const minute = Number(m[1]);
      const second = Number(m[2]);
      const fraction = m[3] ? Number(m[3]) : 0;
      const ms = m[3] && m[3].length === 3 ? fraction : fraction * 10;
      lines.push({ timeMs: minute * 60000 + second * 1000 + ms, text });
    }
  }
  return lines.sort((a, b) => a.timeMs - b.timeMs);
}

export async function getLyrics(input: {
  trackName: string;
  artistName: string;
  albumName?: string;
  duration?: number;
}): Promise<Lyrics> {
  const url = new URL("/api/get", BASE);
  url.searchParams.set("track_name", input.trackName);
  url.searchParams.set("artist_name", input.artistName);
  if (input.albumName) url.searchParams.set("album_name", input.albumName);
  if (input.duration) url.searchParams.set("duration", String(input.duration));

  const res = await fetch(url, { next: { revalidate: 86400 } });
  if (!res.ok) {
    return { synced: false, lines: [], source: "none" };
  }

  const data = await res.json() as {
    syncedLyrics?: string | null;
    plainLyrics?: string | null;
  };

  const synced = data.syncedLyrics ? parseLrc(data.syncedLyrics) : [];
  return {
    synced: synced.length > 0,
    lines: synced,
    plainText: data.plainLyrics ?? undefined,
    source: synced.length || data.plainLyrics ? "lrclib" : "none"
  };
}