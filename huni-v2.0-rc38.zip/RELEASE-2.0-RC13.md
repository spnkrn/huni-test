# Huni 2.0 RC.13

## Playback/player resilience

- Added a single automatic playback-session recovery attempt when the authorized audio element emits an error while the current track is still playing.
- Recovery requests a fresh short-lived server playback session instead of reusing a potentially expired upstream URL.
- Recovery is bounded to one attempt per track to avoid infinite retry loops on broken provider streams.
- Successful playback clears the recovery guard.
- New tracks reset the recovery guard.
- Existing server-side URL encryption, provider allowlisting, redirect blocking, token validation, and session expiry enforcement remain unchanged.

## Verification

Static source checks can run without npm dependencies. Full typecheck, tests, lint, and production build still require dependency installation and remain release-gate requirements.
