"use client";

import type { Track } from "@/lib/types";

type OfflineRecord = { id: string; track: Track; blob: Blob; bytes: number; downloadedAt: string; mimeType: string };
const DB_NAME = "huni-offline-v1";
const STORE = "downloads";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Offline storage unavailable"));
  });
}

export const offlineStore = {
  async usage(): Promise<{ bytes: number; count: number }> {
    const items = await this.list();
    return { bytes: items.reduce((sum, item) => sum + item.bytes, 0), count: items.length };
  },
  async get(id: string): Promise<OfflineRecord | null> {
    if (typeof indexedDB === "undefined") return null;
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, "readonly").objectStore(STORE).get(id);
      request.onsuccess = () => resolve((request.result as OfflineRecord | undefined) ?? null);
      request.onerror = () => reject(request.error);
    });
  },
  async list(): Promise<OfflineRecord[]> {
    if (typeof indexedDB === "undefined") return [];
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
      request.onsuccess = () => resolve((request.result as OfflineRecord[]).sort((a,b) => b.downloadedAt.localeCompare(a.downloadedAt)));
      request.onerror = () => reject(request.error);
    });
  },
  async put(track: Track, blob: Blob): Promise<void> {
    if (typeof indexedDB === "undefined") throw new Error("This browser does not support offline downloads.");
    const db = await openDb();
    const record: OfflineRecord = { id: track.id, track, blob, bytes: blob.size, downloadedAt: new Date().toISOString(), mimeType: blob.type || "audio/mpeg" };
    await new Promise<void>((resolve, reject) => {
      const request = db.transaction(STORE, "readwrite").objectStore(STORE).put(record);
      request.onsuccess = () => resolve(); request.onerror = () => reject(request.error);
    });
    window.dispatchEvent(new CustomEvent("huni-offline-store"));
  },
  async remove(id: string): Promise<void> {
    if (typeof indexedDB === "undefined") return;
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const request = db.transaction(STORE, "readwrite").objectStore(STORE).delete(id);
      request.onsuccess = () => resolve(); request.onerror = () => reject(request.error);
    });
    window.dispatchEvent(new CustomEvent("huni-offline-store"));
  },
  async has(id: string): Promise<boolean> { return Boolean(await this.get(id)); },
  async clear(): Promise<void> {
    if (typeof indexedDB === "undefined") return;
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const request = db.transaction(STORE, "readwrite").objectStore(STORE).clear();
      request.onsuccess = () => resolve(); request.onerror = () => reject(request.error);
    });
    window.dispatchEvent(new CustomEvent("huni-offline-store"));
  },
};
