import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'README.md', 'SECURITY.md', 'DEPLOYMENT.md', 'ARCHITECTURE.md',
  'PROVIDERS.md', 'SUPABASE.md', 'RELEASE-CANDIDATE.md',
];
const failures = [];
for (const file of required) if (!fs.existsSync(path.join(root, file))) failures.push(`missing ${file}`);
if (!fs.existsSync(path.join(root, 'package-lock.json'))) failures.push('missing package-lock.json (run npm install --package-lock-only in a network-enabled environment)');
if (!fs.existsSync(path.join(root, 'tests'))) failures.push('missing tests directory');
if (!fs.existsSync(path.join(root, 'scripts', 'security-audit.mjs'))) failures.push('missing security audit');

const source = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.next', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx|js|mjs)$/.test(entry.name)) source.push(full);
  }
}
walk(path.join(root, 'src'));
for (const file of source) {
  const text = fs.readFileSync(file, 'utf8');
  if (/NEXT_PUBLIC_.*(SECRET|TOKEN|PASSWORD)/i.test(text)) failures.push(`possible public secret reference: ${path.relative(root,file)}`);
  if (/audioUrl\s*[:=]\s*(?:[^\n]*\.)?previewUrl|audioUrl\s*[:=]\s*[\'\"]https?:/i.test(text)) failures.push(`possible preview-as-playback usage: ${path.relative(root,file)}`);
}

if (failures.length) {
  console.error('Release QA: BLOCKED');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}
console.log('Release QA: PASS');
