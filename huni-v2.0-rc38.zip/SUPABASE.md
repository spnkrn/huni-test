# Supabase roadmap

The metadata/discovery starter does not require Supabase to run.

When persistence is enabled, create tables for:
- profiles
- user_preferences
- tracks
- artists
- albums
- track_artists
- album_tracks
- external_ids
- track_provider_matches
- audio_sources
- lyrics
- playlists
- playlist_tracks
- favorites
- library_items
- listening_history
- queues
- queue_items
- provider_settings
- metadata_cache
- admin_settings

Enable RLS. Normal users must never read provider secrets or admin configuration. Prefer server-side secrets/Vault for credentials.

## Interaction API

- `POST/DELETE/GET /api/library` — save/remove/list saved track IDs.
- `POST/DELETE/GET /api/favorites` — favorite/unfavorite/list favorite track IDs.
- `POST /api/history` — record an authenticated listening event.
- `GET/POST /api/playlists` — list/create owned playlists.
- `GET /api/playlists/:id` — retrieve an owned playlist and its tracks.
- `POST/DELETE /api/playlists/:id/tracks` — add/remove tracks from an owned playlist.

All routes derive the user from the Supabase server session. The browser never supplies `user_id` as an authorization decision.
