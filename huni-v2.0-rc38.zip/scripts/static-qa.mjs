import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const routeDir=path.join(root,'src','app','api');
const files=[];
function walk(dir){ for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else if(e.name==='route.ts') files.push(p); } }
walk(routeDir);
const failures=[];
const sessionStore = path.join(root, "src", "lib", "playback", "session-store.ts");
if (fs.existsSync(sessionStore)) {
  const sessionStoreSource = fs.readFileSync(sessionStore, "utf8");
  if (!sessionStoreSource.includes('createAdminClient')) failures.push('playback session store must use the server-only Supabase admin client');
  if (sessionStoreSource.includes('@/lib/supabase/server')) failures.push('playback session store must not use the browser-session Supabase client');
}
const playbackIsolationMigration = path.join(root, "supabase", "migrations", "0004_playback_sessions_server_managed.sql");
if (!fs.existsSync(playbackIsolationMigration)) failures.push('missing playback session server-managed RLS migration');


for(const file of files){
  const s=fs.readFileSync(file,'utf8');
  if (/export async function (POST|PUT|PATCH|DELETE)/.test(s) && !s.includes('sameOrigin(')) failures.push(`${path.relative(root,file)} missing sameOrigin guard`);
  if (/export async function (POST|PUT|PATCH|DELETE)/.test(s) && !s.includes('bodyWithinLimit(')) failures.push(`${path.relative(root,file)} missing body size guard`);
  if (/export async function (POST|PUT|PATCH|DELETE)/.test(s) && !s.includes('rateLimit(')) failures.push(`${path.relative(root,file)} missing rate limit`);
  if (/NextResponse\.json/.test(s) && !s.includes('withApiHeaders') && !s.includes('Cache-Control') && !s.includes('jsonError')) failures.push(`${path.relative(root,file)} has an unreviewed JSON response`);
  if (file.endsWith(path.join('playback','stream','route.ts'))) {
    if (!s.includes('createClient') || !s.includes('auth.getUser')) failures.push(`${path.relative(root,file)} must authenticate the stream request`);
    if (!s.includes('await getPlaybackSession(')) failures.push(`${path.relative(root,file)} must use the persistent playback session store`);
  }
  if (file.endsWith(path.join('playback','session','route.ts')) && !s.includes('await storePlaybackSession(')) failures.push(`${path.relative(root,file)} must persist playback sessions`);
  if (file.endsWith(path.join('playback','stream','route.ts')) && s.includes('providerUrl')) failures.push(`${path.relative(root,file)} must not expose provider URL variables`);
  if (file.endsWith(path.join('playback','stream','route.ts')) && s.includes('Content-Disposition') && !s.includes('filename=\"huni-audio\"')) failures.push(`${path.relative(root,file)} must use a fixed non-user-controlled download filename`);
  if (/export async function GET\(\)/.test(s) && /jsonError\(request,/.test(s)) failures.push(`${path.relative(root,file)} references request without accepting it in GET`);
  if (/NextResponse\.json\([^\n]*\)/.test(s) && /export async function GET\(request: Request\)/.test(s) && !s.includes('withApiHeaders(request)') && !s.includes('Cache-Control')) failures.push(`${path.relative(root,file)} GET JSON response lacks explicit no-store headers`);
}
if (files.length !== 16) console.warn(`Notice: expected 16 API routes, found ${files.length}`);
if(failures.length){ console.error('Static QA failed:'); failures.forEach(x=>console.error(`- ${x}`)); process.exit(1); }
console.log(`Static QA passed for ${files.length} API route files.`);
