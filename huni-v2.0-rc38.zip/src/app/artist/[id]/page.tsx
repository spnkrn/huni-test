"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Play } from "lucide-react";
import { Album, Artist, Track } from "@/lib/types";
import { AlbumCard } from "@/components/music/album-card";
import { TrackRow } from "@/components/music/track-row";
import { usePlayer } from "@/components/player/player-context";
import { ProviderProvenance } from "@/components/metadata/provider-provenance";

export default function ArtistPage({ params }: { params: Promise<{ id: string }> }) {
  const [data, setData] = useState<{ artist: Artist; albums: Album[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const { play } = usePlayer();

  useEffect(() => { params.then(({ id }) => fetch(`/api/artist/${id}`).then(r => r.ok ? r.json() : null).then(setData).finally(() => setLoading(false))); }, [params]);
  const singles = useMemo(() => (data?.albums ?? []).filter(a => (a.trackCount ?? 0) <= 3), [data]);
  const albums = useMemo(() => (data?.albums ?? []).filter(a => (a.trackCount ?? 0) > 3), [data]);

  if (loading) return <div className="py-24 text-center text-sm text-white/35">Loading artist…</div>;
  if (!data) return <div className="py-24 text-center text-sm text-white/35">Artist unavailable.</div>;

  return <div className="mx-auto max-w-6xl">
    <Link href="/search" className="mb-8 inline-flex items-center gap-2 text-xs text-white/40 hover:text-white"><ArrowLeft size={15}/> Back</Link>
    <header className="relative overflow-hidden rounded-[30px] border border-white/10 bg-white/[.035] p-7 md:p-10">
      <div className="absolute inset-0 bg-gradient-to-r from-white/[.05] to-transparent" />
      <div className="relative flex flex-col gap-6 md:flex-row md:items-end">
        <div className="grid size-32 shrink-0 place-items-center rounded-full bg-white/[.06] text-4xl font-semibold md:size-44">{data.artist.name.slice(0,1)}</div>
        <div><div className="eyebrow">Artist</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.055em] md:text-6xl">{data.artist.name}</h1><div className="mt-3 text-sm text-white/40">{[data.artist.type, data.artist.country].filter(Boolean).join(" · ") || "Music artist"}</div><ProviderProvenance entity={data.artist} /><button onClick={() => albums[0] && fetch(`/api/album/${albums[0].id}`).then(r=>r.json()).then(a=>a.tracks?.[0] && play(a.tracks[0]))} className="mt-6 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-medium text-black"><Play size={15} fill="currentColor"/> Play</button></div>
      </div>
    </header>
    <section className="mt-12"><div className="mb-5 flex items-end justify-between"><div><div className="eyebrow">Discography</div><h2 className="mt-1 text-xl font-semibold">Albums</h2></div><span className="text-xs text-white/30">{albums.length} releases</span></div><div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">{albums.map(a => <AlbumCard key={a.id} album={a}/>)}</div></section>
    {singles.length > 0 && <section className="mt-14"><div className="eyebrow mb-4">Singles & EPs</div><div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">{singles.map(a => <AlbumCard key={a.id} album={a}/>)}</div></section>}
  </div>;
}
