"use client";

import { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Track } from "@/lib/types";
import { isTrack } from "@/lib/persistence";

type RepeatMode = "off" | "all" | "one";

type PlaybackResponse = {
  sessionId: string;
  expiresAt: string;
  streamUrl: string;
  downloadUrl?: string;
  accessToken?: string;
};

type PlayerContextValue = {
  track: Track | null;
  playing: boolean;
  loading: boolean;
  error: string | null;
  position: number;
  duration: number;
  buffered: number;
  queue: Track[];
  index: number;
  shuffle: boolean;
  repeat: RepeatMode;
  play: (track?: Track) => void;
  playTracks: (tracks: Track[], startIndex?: number, shuffle?: boolean) => void;
  pause: () => void;
  toggle: () => void;
  seek: (seconds: number) => void;
  enqueue: (track: Track) => void;
  removeFromQueue: (trackId: string) => void;
  clearQueue: () => void;
  next: () => void;
  previous: () => void;
  setShuffle: (value: boolean) => void;
  setRepeat: (value: RepeatMode) => void;
  moveInQueue: (fromIndex: number, toIndex: number) => void;
  volume: number;
  muted: boolean;
  setVolume: (value: number) => void;
  setMuted: (value: boolean) => void;
  sleepTimerMinutes: number;
  setSleepTimer: (minutes: number) => void;
};

const PlayerContext = createContext<PlayerContextValue | null>(null);

function randomIndex(length: number, current: number) {
  if (length <= 1) return current;
  let next = current;
  while (next === current) next = Math.floor(Math.random() * length);
  return next;
}

function shuffledNextIndex(items: Track[], current: number, history: string[]) {
  if (items.length <= 1) return current;
  const unplayed = items
    .map((item, itemIndex) => ({ item, itemIndex }))
    .filter(({ item, itemIndex }) => itemIndex !== current && !history.includes(item.id));
  const pool = unplayed.length ? unplayed : items.map((item, itemIndex) => ({ item, itemIndex })).filter(({ itemIndex }) => itemIndex !== current);
  return pool[Math.floor(Math.random() * pool.length)]?.itemIndex ?? current;
}

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const queueRef = useRef<Track[]>([]);
  const indexRef = useRef(0);
  const shuffleRef = useRef(false);
  const repeatRef = useRef<RepeatMode>("off");
  const trackRef = useRef<Track | null>(null);
  const playingRef = useRef(false);
  const historyRecordedRef = useRef<string | null>(null);
  const progressSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const resumePositionRef = useRef<number | null>(null);
  const sessionRef = useRef<{ trackId: string; expiresAtMs: number; response: PlaybackResponse } | null>(null);
  const sessionRequestRef = useRef<AbortController | null>(null);
  const renewalTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recoveryAttemptedRef = useRef<string | null>(null);
  const shuffleHistoryRef = useRef<string[]>([]);
  const playbackGenerationRef = useRef(0);
  const controlsRef = useRef<{ play: () => void; pause: () => void; next: () => void; previous: () => void }>({
    play: () => undefined,
    pause: () => undefined,
    next: () => undefined,
    previous: () => undefined,
  });

  const [track, setTrack] = useState<Track | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [queue, setQueue] = useState<Track[]>([]);
  const [index, setIndex] = useState(0);
  const [shuffle, setShuffleState] = useState(false);
  const [repeat, setRepeatState] = useState<RepeatMode>("off");
  const [volume, setVolumeState] = useState(1);
  const [muted, setMutedState] = useState(false);
  const [playerStateHydrated, setPlayerStateHydrated] = useState(false);
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState(0);

  const clampVolume = (value: number) => Math.min(1, Math.max(0, Number.isFinite(value) ? value : 1));

  useEffect(() => { queueRef.current = queue; }, [queue]);
  useEffect(() => { indexRef.current = index; }, [index]);
  useEffect(() => { shuffleRef.current = shuffle; }, [shuffle]);
  useEffect(() => { trackRef.current = track; }, [track]);
  useEffect(() => { playingRef.current = playing; }, [playing]);
  useEffect(() => { repeatRef.current = repeat; }, [repeat]);

  useEffect(() => {
    const saved = localStorage.getItem("huni-player-state");
    const legacyQueue = localStorage.getItem("huni-queue");
    try {
      const parsed = saved ? JSON.parse(saved) as { queue?: unknown; index?: unknown; shuffle?: unknown; repeat?: unknown } : null;
      const legacyParsed = !parsed && legacyQueue ? JSON.parse(legacyQueue) : null;
      const restoredQueue = Array.isArray(parsed?.queue) ? parsed.queue.filter(isTrack) : Array.isArray(legacyParsed) ? legacyParsed.filter(isTrack) : [];
      setQueue(restoredQueue);
      if (restoredQueue.length && typeof parsed?.index === "number" && Number.isInteger(parsed.index)) {
        setIndex(Math.min(Math.max(parsed.index, 0), restoredQueue.length - 1));
      }
      if (typeof parsed?.shuffle === "boolean") setShuffleState(parsed.shuffle);
      if (parsed?.repeat === "off" || parsed?.repeat === "all" || parsed?.repeat === "one") setRepeatState(parsed.repeat);
      const savedSleep = Number(localStorage.getItem("huni-sleep-timer-minutes") ?? 0);
      if (Number.isFinite(savedSleep) && savedSleep > 0) setSleepTimerMinutes(savedSleep);
      const savedVolume = localStorage.getItem("huni-volume-state");
      if (savedVolume) {
        const volumeState = JSON.parse(savedVolume) as { volume?: unknown; muted?: unknown };
        if (typeof volumeState.volume === "number") setVolumeState(clampVolume(volumeState.volume));
        if (typeof volumeState.muted === "boolean") setMutedState(volumeState.muted);
      }
    } catch {
      localStorage.removeItem("huni-player-state");
      localStorage.removeItem("huni-queue");
    }
    setPlayerStateHydrated(true);

    const audio = new Audio();
    audio.preload = "metadata";
    audio.volume = clampVolume(Number(localStorage.getItem("huni-volume") ?? 1));
    audio.muted = localStorage.getItem("huni-muted") === "true";
    audioRef.current = audio;

    const onTime = () => {
      setPosition(audio.currentTime);
      const current = trackRef.current;
      if (current && playingRef.current && audio.currentTime > 0) scheduleProgressSave(current);
    };
    const onDuration = () => setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onProgress = () => {
      if (!audio.buffered.length) { setBuffered(0); return; }
      const now = audio.currentTime;
      let end = 0;
      for (let i = 0; i < audio.buffered.length; i += 1) {
        const start = audio.buffered.start(i);
        const candidate = audio.buffered.end(i);
        if (now >= start && now <= candidate) { end = candidate; break; }
        if (candidate > end) end = candidate;
      }
      setBuffered(Number.isFinite(end) ? end : 0);
    };
    const onError = () => {
      const failedTrack = trackRef.current;
      const shouldRecover = Boolean(failedTrack && playingRef.current && recoveryAttemptedRef.current !== failedTrack.id);
      if (shouldRecover && failedTrack) {
        recoveryAttemptedRef.current = failedTrack.id;
        void attachAndPlay(failedTrack);
        return;
      }
      setPlaying(false);
      setError("The authorized audio stream could not be played.");
    };
    const onEnded = () => {
      const currentTrack = trackRef.current;
      if (progressSaveTimerRef.current) { clearTimeout(progressSaveTimerRef.current); progressSaveTimerRef.current = null; }
      if (currentTrack && Number.isFinite(audio.duration)) {
        void fetch("/api/history/progress", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ trackId: currentTrack.id, positionSeconds: audio.duration, durationSeconds: audio.duration, completed: true }) }).catch(() => undefined);
      }
      const items = queueRef.current;
      const current = indexRef.current;
      const mode = repeatRef.current;
      if (mode === "one") {
        audio.currentTime = 0;
        void audio.play().catch(() => setPlaying(false));
        return;
      }
      if (items.length <= 1) { setPlaying(false); return; }
      let nextIndex = -1;
      if (shuffleRef.current) {
        shuffleHistoryRef.current = [...shuffleHistoryRef.current.filter((id) => items.some((item) => item.id === id)), items[current].id];
        nextIndex = shuffledNextIndex(items, current, shuffleHistoryRef.current);
        if (shuffleHistoryRef.current.length >= items.length - 1) shuffleHistoryRef.current = [items[current].id];
      } else {
        nextIndex = current + 1 < items.length ? current + 1 : mode === "all" ? 0 : -1;
      }
      if (nextIndex < 0) { setPlaying(false); return; }
      setIndex(nextIndex);
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("durationchange", onDuration);
    audio.addEventListener("progress", onProgress);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);

    return () => {
      audio.pause();
      sessionRequestRef.current?.abort();
      if (progressSaveTimerRef.current) clearTimeout(progressSaveTimerRef.current);
      if (renewalTimerRef.current) clearTimeout(renewalTimerRef.current);
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("durationchange", onDuration);
      audio.removeEventListener("progress", onProgress);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audioRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!playerStateHydrated) return;
    localStorage.setItem("huni-player-state", JSON.stringify({ queue, index, shuffle, repeat }));
  }, [queue, index, shuffle, repeat, playerStateHydrated]);

  useEffect(() => {
    if (!playerStateHydrated) return;
    localStorage.setItem("huni-sleep-timer-minutes", String(sleepTimerMinutes));
  }, [sleepTimerMinutes, playerStateHydrated]);

  useEffect(() => {
    if (sleepTimerMinutes <= 0) return;
    const timer = window.setTimeout(() => {
      controlsRef.current.pause();
      setSleepTimerMinutes(0);
    }, sleepTimerMinutes * 60_000);
    return () => window.clearTimeout(timer);
  }, [sleepTimerMinutes]);

  useEffect(() => {
    if (!playerStateHydrated) return;
    localStorage.setItem("huni-volume-state", JSON.stringify({ volume, muted }));
    localStorage.setItem("huni-volume", String(volume));
    localStorage.setItem("huni-muted", String(muted));
  }, [volume, muted, playerStateHydrated]);
  useEffect(() => {
    const current = queue[index];
    if (current) setTrack(current);
    else if (!queue.length) setTrack(null);
  }, [index, queue]);

  async function loadResumePosition(target: Track) {
    try {
      const response = await fetch(`/api/history/progress?trackId=${encodeURIComponent(target.id)}`, { cache: "no-store" });
      if (!response.ok) return;
      const body = await response.json().catch(() => ({})) as { progress?: { position_seconds?: unknown } | null };
      const position = body.progress?.position_seconds;
      if (typeof position === "number" && Number.isFinite(position) && position > 5) resumePositionRef.current = position;
    } catch { /* Resume is best-effort. */ }
  }

  function scheduleProgressSave(target: Track) {
    if (progressSaveTimerRef.current) clearTimeout(progressSaveTimerRef.current);
    progressSaveTimerRef.current = setTimeout(() => {
      progressSaveTimerRef.current = null;
      const audio = audioRef.current;
      if (!audio || trackRef.current?.id !== target.id || !Number.isFinite(audio.currentTime)) return;
      void fetch("/api/history/progress", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ trackId: target.id, positionSeconds: audio.currentTime, durationSeconds: Number.isFinite(audio.duration) ? audio.duration : undefined }),
      }).catch(() => undefined);
      if (playingRef.current) scheduleProgressSave(target);
    }, 10_000);
  }

  async function requestSession(target: Track, signal?: AbortSignal) {
    const cached = sessionRef.current;
    if (cached && cached.trackId === target.id && cached.expiresAtMs > Date.now() + 15_000) return cached.response;

    const response = await fetch("/api/playback/session", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ trackId: target.id }),
      cache: "no-store",
      signal,
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error ?? "Playback is unavailable.");
    const parsed = body as PlaybackResponse;
    if (!parsed.streamUrl || !parsed.expiresAt) throw new Error("Playback provider returned an invalid session.");
    const expiresAtMs = Date.parse(parsed.expiresAt);
    if (!Number.isFinite(expiresAtMs) || expiresAtMs <= Date.now()) throw new Error("Playback session has already expired.");
    sessionRef.current = { trackId: target.id, expiresAtMs, response: parsed };
    return parsed;
  }

  async function attachAndPlay(target: Track) {
    const audio = audioRef.current;
    const generation = ++playbackGenerationRef.current;
    if (!audio) return;
    setLoading(true);
    setError(null);
    sessionRequestRef.current?.abort();
    const controller = new AbortController();
    sessionRequestRef.current = controller;
    try {
      const session = await requestSession(target, controller.signal);
      if (generation !== playbackGenerationRef.current || trackRef.current?.id !== target.id) return;
      if (renewalTimerRef.current) clearTimeout(renewalTimerRef.current);
      const renewIn = Math.max(5_000, Date.parse(session.expiresAt) - Date.now() - 20_000);
      renewalTimerRef.current = setTimeout(() => {
        if (trackRef.current?.id === target.id && playingRef.current) void attachAndPlay(target);
      }, renewIn);
      await loadResumePosition(target);
      if (generation !== playbackGenerationRef.current || trackRef.current?.id !== target.id) return;
      audio.src = session.streamUrl;
      audio.currentTime = 0;
      audio.load();
      await new Promise<void>((resolve) => {
        if (audio.readyState >= 1) { resolve(); return; }
        audio.addEventListener("loadedmetadata", () => resolve(), { once: true });
      });
      if (generation !== playbackGenerationRef.current || trackRef.current?.id !== target.id) return;
      const resume = resumePositionRef.current;
      resumePositionRef.current = null;
      if (resume !== null && Number.isFinite(audio.duration) && resume < Math.max(0, audio.duration - 5)) audio.currentTime = Math.min(resume, audio.duration - 1);
      await audio.play();
      if (generation !== playbackGenerationRef.current || trackRef.current?.id !== target.id) return;
      recoveryAttemptedRef.current = null;
      if (historyRecordedRef.current !== target.id) {
        historyRecordedRef.current = target.id;
        void fetch("/api/history", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ track: target, positionSeconds: 0 }) }).catch(() => undefined);
      }
    } catch (reason) {
      if (reason instanceof DOMException && reason.name === "AbortError") return;
      setPlaying(false);
      setError(reason instanceof Error ? reason.message : "Playback is unavailable.");
    } finally {
      if (generation === playbackGenerationRef.current) setLoading(false);
    }
  }

  useEffect(() => {
    const audio = audioRef.current;
    if (!track || !audio) return;
    setPosition(0);
    setDuration(0);
    setBuffered(0);
    setError(null);
    playbackGenerationRef.current += 1;
    sessionRef.current = null;
    sessionRequestRef.current?.abort();
    recoveryAttemptedRef.current = null;
    historyRecordedRef.current = null;
    if (renewalTimerRef.current) clearTimeout(renewalTimerRef.current);
    audio.removeAttribute("src");
    audio.load();
    if (playing) void attachAndPlay(track);
  }, [track]);

  useEffect(() => {
    if (!track || !playing) return;
    const audio = audioRef.current;
    if (!audio) return;
    if (!audio.src) void attachAndPlay(track);
  }, [playing, track]);

  useEffect(() => {
    const nav = navigator as Navigator & { mediaSession?: MediaSession };
    if (!nav.mediaSession) return;
    nav.mediaSession.playbackState = playing ? "playing" : "paused";
    if (duration > 0 && Number.isFinite(position)) {
      try {
        nav.mediaSession.setPositionState({
          duration,
          playbackRate: audioRef.current?.playbackRate || 1,
          position: Math.min(Math.max(position, 0), duration),
        });
      } catch {}
    }
  }, [playing, position, duration]);

  useEffect(() => {
    if (!track) return;
    const nav = navigator as Navigator & { mediaSession?: MediaSession };
    if (!nav.mediaSession) return;
    nav.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artists.map((artist) => artist.name).join(", "),
      album: track.album?.title,
      artwork: track.artwork?.large ? [{ src: track.artwork.large }] : [],
    });
    const actions: Array<[MediaSessionAction, () => void]> = [
      ["play", () => controlsRef.current.play()], ["pause", () => controlsRef.current.pause()],
      ["nexttrack", () => controlsRef.current.next()], ["previoustrack", () => controlsRef.current.previous()],
      ["seekbackward", () => seek(Math.max(0, (audioRef.current?.currentTime ?? 0) - 10))],
      ["seekforward", () => seek(Math.min(duration || Number.MAX_SAFE_INTEGER, (audioRef.current?.currentTime ?? 0) + 10))],
    ];
    try {
      nav.mediaSession.setActionHandler("seekto", (details) => {
        const target = details.seekTime ?? 0;
        seek(Math.min(duration || Number.MAX_SAFE_INTEGER, Math.max(0, target)));
      });
    } catch {}
    for (const [action, handler] of actions) { try { nav.mediaSession.setActionHandler(action, handler); } catch {} }
    return () => { for (const [action] of actions) { try { nav.mediaSession?.setActionHandler(action, null); } catch {} } };
  }, [track, duration]);

  const playTracks = (tracks: Track[], startIndex = 0, shouldShuffle = false) => {
    const validTracks = tracks.filter(isTrack);
    if (!validTracks.length) return;
    const safeStart = Math.min(Math.max(startIndex, 0), validTracks.length - 1);
    playbackGenerationRef.current += 1;
    sessionRequestRef.current?.abort();
    if (renewalTimerRef.current) { clearTimeout(renewalTimerRef.current); renewalTimerRef.current = null; }
    sessionRef.current = null;
    recoveryAttemptedRef.current = null;
    shuffleHistoryRef.current = shouldShuffle ? [validTracks[safeStart].id] : [];
    setQueue(validTracks);
    setIndex(safeStart);
    setShuffleState(shouldShuffle);
    setError(null);
    setPlaying(true);
  };

  const play = (nextTrack?: Track) => {
    if (nextTrack) {
      const existing = queueRef.current.findIndex((item) => item.id === nextTrack.id);
      if (existing >= 0) setIndex(existing);
      else {
        const newIndex = queueRef.current.length;
        setQueue((items) => [...items, nextTrack]);
        setIndex(newIndex);
      }
      setTrack(nextTrack);
      setError(null);
    }
    if (!nextTrack && !track) return;
    setPlaying(true);
  };
  const pause = () => {
    playbackGenerationRef.current += 1;
    sessionRequestRef.current?.abort();
    if (renewalTimerRef.current) { clearTimeout(renewalTimerRef.current); renewalTimerRef.current = null; }
    const audio = audioRef.current;
    if (audio && trackRef.current && Number.isFinite(audio.currentTime) && audio.currentTime > 0) {
      void fetch("/api/history/progress", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ trackId: trackRef.current.id, positionSeconds: audio.currentTime, durationSeconds: Number.isFinite(audio.duration) ? audio.duration : undefined }) }).catch(() => undefined);
    }
    if (progressSaveTimerRef.current) { clearTimeout(progressSaveTimerRef.current); progressSaveTimerRef.current = null; }
    audio?.pause();
    setPlaying(false);
  };
  const toggle = () => playing ? pause() : play();
  const seek = (seconds: number) => { if (audioRef.current) audioRef.current.currentTime = Math.max(0, seconds); };
  const enqueue = (item: Track) => setQueue((items) => items.some((existing) => existing.id === item.id) ? items : [...items, item]);
  const removeFromQueue = (trackId: string) => {
    const items = queueRef.current;
    const removeIndex = items.findIndex((item) => item.id === trackId);
    if (removeIndex < 0) return;
    const isCurrent = removeIndex === indexRef.current;
    const nextItems = items.filter((item) => item.id !== trackId);
    if (!nextItems.length) {
      pause();
      setQueue([]);
      setIndex(0);
      return;
    }
    setQueue(nextItems);
    setIndex((current) => {
      if (removeIndex < current) return current - 1;
      if (isCurrent) return Math.min(current, nextItems.length - 1);
      return Math.min(current, nextItems.length - 1);
    });
  };
  const clearQueue = () => {
    playbackGenerationRef.current += 1;
    sessionRequestRef.current?.abort();
    if (progressSaveTimerRef.current) { clearTimeout(progressSaveTimerRef.current); progressSaveTimerRef.current = null; }
    if (renewalTimerRef.current) { clearTimeout(renewalTimerRef.current); renewalTimerRef.current = null; }
    audioRef.current?.pause();
    audioRef.current?.removeAttribute("src");
    audioRef.current?.load();
    sessionRef.current = null;
    setPlaying(false);
    setQueue([]);
    setIndex(0);
  };
  const next = () => {
    const items = queueRef.current; if (!items.length) return;
    const current = indexRef.current;
    let nextIndex = -1;
    if (shuffleRef.current) {
      shuffleHistoryRef.current = [...shuffleHistoryRef.current.filter((id) => items.some((item) => item.id === id)), items[current].id];
      nextIndex = shuffledNextIndex(items, current, shuffleHistoryRef.current);
      if (shuffleHistoryRef.current.length >= items.length - 1) shuffleHistoryRef.current = [items[current].id];
    } else {
      nextIndex = current + 1 < items.length ? current + 1 : repeatRef.current === "all" ? 0 : -1;
    }
    if (nextIndex >= 0) setIndex(nextIndex); else setPlaying(false);
  };
  const previous = () => {
    const items = queueRef.current; if (!items.length) return;
    if ((audioRef.current?.currentTime ?? 0) > 3) { seek(0); return; }
    if (shuffleRef.current && shuffleHistoryRef.current.length > 1) {
      const history = shuffleHistoryRef.current.slice(0, -1);
      const previousId = history[history.length - 1];
      const previousIndex = items.findIndex((item) => item.id === previousId);
      shuffleHistoryRef.current = history;
      if (previousIndex >= 0) { setIndex(previousIndex); return; }
    }
    setIndex((current) => Math.max(0, current - 1));
  };
  const setShuffle = (value: boolean) => {
    shuffleHistoryRef.current = value && trackRef.current ? [trackRef.current.id] : [];
    setShuffleState(value);
  };
  const setRepeat = (value: RepeatMode) => setRepeatState(value);
  const moveInQueue = (fromIndex: number, toIndex: number) => {
    const items = queueRef.current;
    if (fromIndex < 0 || fromIndex >= items.length || toIndex < 0 || toIndex >= items.length || fromIndex === toIndex) return;
    const nextItems = [...items];
    const [moved] = nextItems.splice(fromIndex, 1);
    nextItems.splice(toIndex, 0, moved);
    setQueue(nextItems);
    setIndex((current) => {
      if (current === fromIndex) return toIndex;
      if (fromIndex < current && toIndex >= current) return current - 1;
      if (fromIndex > current && toIndex <= current) return current + 1;
      return current;
    });
  };
  const setVolume = (value: number) => {
    const next = clampVolume(value);
    setVolumeState(next);
    if (audioRef.current) audioRef.current.volume = next;
  };
  const setSleepTimer = (minutes: number) => setSleepTimerMinutes(Math.max(0, Math.round(minutes)));
  const setMuted = (value: boolean) => {
    setMutedState(value);
    if (audioRef.current) audioRef.current.muted = value;
  };
  controlsRef.current = { play, pause, next, previous };

  const value = useMemo(() => ({ track, playing, loading, error, position, duration, buffered, queue, index, shuffle, repeat, play, playTracks, pause, toggle, seek, enqueue, removeFromQueue, clearQueue, next, previous, setShuffle, setRepeat, moveInQueue, volume, muted, setVolume, setMuted, sleepTimerMinutes, setSleepTimer }), [track, playing, loading, error, position, duration, buffered, queue, index, shuffle, repeat, volume, muted, sleepTimerMinutes]);
  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}

export function usePlayer() {
  const value = useContext(PlayerContext);
  if (!value) throw new Error("usePlayer must be used inside PlayerProvider");
  return value;
}
