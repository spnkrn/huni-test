import { NextRequest, NextResponse } from "next/server";
import { withApiHeaders } from "@/lib/security/api";
import { searchITunes } from "@/lib/providers/itunes";
import { qobuzMetadata } from "@/lib/providers/qobuz-metadata";
import { searchMusicBrainzArtists } from "@/lib/providers/musicbrainz";
import { getUserContentRegion } from "@/lib/region";
import { mergeSearchResults } from "@/lib/providers/catalog-merge";
import { searchPodcasts } from "@/lib/providers/podcasts";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const headers = withApiHeaders(req);
  if (!q) return NextResponse.json({ tracks: [], albums: [], artists: [], podcasts: [] }, { headers });

  try {
    const { region } = await getUserContentRegion();
    const [qobuz, itunes, mbArtists, podcasts] = await Promise.all([
      qobuzMetadata.isConfigured() ? qobuzMetadata.search(q, region).catch(() => null) : Promise.resolve(null),
      searchITunes(q, region).catch(() => null),
      searchMusicBrainzArtists(q).catch(() => []),
      searchPodcasts(q, region).then(r => r.podcasts).catch(() => [])
    ]);

    if (!qobuz && !itunes) {
      return NextResponse.json({ error: "Search temporarily unavailable" }, { status: 502, headers });
    }

    const merged = mergeSearchResults(qobuz, itunes);
    const artists = mergeSearchResults(merged, { tracks: [], albums: [], artists: mbArtists }).artists;
    return NextResponse.json({ ...merged, artists, podcasts }, { headers });
  } catch {
    return NextResponse.json({ error: "Search temporarily unavailable" }, { status: 502, headers });
  }
}
