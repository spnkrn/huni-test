# Huni 2.0 Release Candidate

Current candidate: **2.0.0-rc.6**.

## Verified in the source environment

- Static API QA: 14/14 routes pass.
- Security audit: 14/14 routes pass.
- Node syntax checks for release scripts pass.
- ZIP/source archive integrity checks pass.
- State-changing API routes enforce same-origin checks, bounded request bodies, and rate limits.
- API responses use private/no-store boundaries where applicable.
- Health endpoint reports the current release candidate version.
- Playlist and history mutations have dedicated rate-limit buckets.
- Playlist track identifiers are bounded before database operations.
- Playback upstream URLs are no longer returned directly to the browser; the client receives a Huni-owned proxy URL backed by a short-lived signed token.
- Playback proxy forwards HTTP Range requests so browser seeking/buffering continues to work.
- Proxy session state is bounded and expires automatically; multi-instance deployments should replace the process-local session store with shared ephemeral storage.

## Local dependency/build certification

This environment does not currently have the npm dependency tree installed. A direct `npm install --package-lock-only` attempt timed out while resolving the registry, so the project does **not** claim TypeScript, ESLint, Vitest, or Next production-build success here.

## Required external certification

Run in a network-enabled Node/npm environment:

```bash
npm install --package-lock-only
npm ci
npm run verify:env
npm run qa:static
npm run audit:security
npm run audit:release
npm run typecheck
npm run lint
npm test
npm run test:security
npm run build
```

Only after every command succeeds should this candidate be promoted to **2.0.0**.
