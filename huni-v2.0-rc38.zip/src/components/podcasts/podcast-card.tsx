import Image from "next/image";
import Link from "next/link";
import type { Podcast } from "@/lib/podcast-types";

export function PodcastCard({ podcast }: { podcast: Podcast }) {
  return <Link href={`/podcast/${podcast.collectionId}`} className="group block">
    <div className="relative aspect-square overflow-hidden rounded-2xl border border-white/10 bg-white/5 shadow-xl shadow-black/20">
      {podcast.artwork ? <Image src={podcast.artwork} alt="" fill sizes="220px" className="object-cover transition duration-500 group-hover:scale-[1.03]" /> : null}
      {podcast.rank ? <div className="absolute left-2 top-2 rounded-full border border-white/15 bg-black/60 px-2 py-1 text-[10px] backdrop-blur-xl">#{podcast.rank}</div> : null}
    </div>
    <div className="mt-3 truncate text-sm font-medium">{podcast.title}</div>
    <div className="mt-1 truncate text-xs text-white/40">{podcast.author}</div>
  </Link>;
}
