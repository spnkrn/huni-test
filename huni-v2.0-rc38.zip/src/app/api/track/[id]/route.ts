import { NextRequest, NextResponse } from "next/server";
import { lookupTrack } from "@/lib/providers/itunes";
import { qobuzMetadata } from "@/lib/providers/qobuz-metadata";
import { getUserContentRegion } from "@/lib/region";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const rate = rateLimit(`track:${getRequestFingerprint(req)}`, 120, 60_000);
  const headers = { "X-Request-ID": requestId(req), ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers });
  const { id } = await ctx.params; const { region } = await getUserContentRegion();
  try {
    if (id.startsWith("qobuz-track-") && qobuzMetadata.isConfigured()) return NextResponse.json(await qobuzMetadata.track(id.replace("qobuz-track-", ""), region), { headers });
    const itunesId = id.replace(/^itunes-track-/, "");
    if (!/^\d+$/.test(itunesId)) return NextResponse.json({ error: "Unsupported track id" }, { status: 400, headers });
    const track = await lookupTrack(itunesId, region);
    if (!track) return NextResponse.json({ error: "Track not found" }, { status: 404, headers });
    return NextResponse.json(track, { headers });
  } catch { return NextResponse.json({ error: "Track unavailable" }, { status: 502, headers }); }
}
