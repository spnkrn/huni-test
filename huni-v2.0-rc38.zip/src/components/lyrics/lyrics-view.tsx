"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Lyrics } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";

export function LyricsView({ lyrics }: { lyrics: Lyrics }) {
  const { position, seek } = usePlayer();
  const [manual, setManual] = useState(false);
  const manualTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const activeIndex = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < lyrics.lines.length; i++) {
      if (lyrics.lines[i].timeMs <= position * 1000) idx = i;
      else break;
    }
    return idx;
  }, [lyrics.lines, position]);

  useEffect(() => {
    if (manual || activeIndex < 0) return;
    document.getElementById(`lyric-${activeIndex}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeIndex, manual]);

  useEffect(() => () => { if (manualTimer.current) clearTimeout(manualTimer.current); }, []);

  if (!lyrics.lines.length) {
    return <div className="h-full overflow-y-auto px-6 py-16 text-center text-white/40">{lyrics.plainText || "Lyrics aren't available for this track."}</div>;
  }

  const resumeAutoScroll = () => {
    setManual(false);
    if (manualTimer.current) clearTimeout(manualTimer.current);
  };

  return (
    <div
      className="relative h-full max-h-[75vh] overflow-y-auto px-5 py-16"
      onWheel={() => {
        setManual(true);
        if (manualTimer.current) clearTimeout(manualTimer.current);
        manualTimer.current = setTimeout(() => setManual(false), 3500);
      }}
      onTouchMove={() => {
        setManual(true);
        if (manualTimer.current) clearTimeout(manualTimer.current);
        manualTimer.current = setTimeout(() => setManual(false), 3500);
      }}
    >
      <div className="mx-auto max-w-3xl space-y-5">
        {lyrics.lines.map((line, i) => {
          const active = i === activeIndex;
          return (
            <button
              key={`${line.timeMs}-${i}`}
              id={`lyric-${i}`}
              onClick={() => { resumeAutoScroll(); seek(line.timeMs / 1000); }}
              className={`block w-full text-left text-2xl font-semibold leading-tight tracking-tight transition-all duration-300 md:text-4xl ${active ? "scale-[1.015] text-white" : "text-white/25 hover:text-white/55"}`}
            >
              {line.text || "♪"}
            </button>
          );
        })}
      </div>
      {manual && <button onClick={resumeAutoScroll} className="sticky bottom-3 left-1/2 mx-auto block rounded-full border border-white/10 bg-white/10 px-3 py-1.5 text-[11px] text-white/70 backdrop-blur-xl">Resume lyrics</button>}
    </div>
  );
}
