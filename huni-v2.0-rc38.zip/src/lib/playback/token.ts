import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { z } from "zod";

const VERSION = "h1";
const MAX_TRACK_ID = 256;
const claimsSchema = z.object({
  sessionId: z.string().uuid(),
  userId: z.string().uuid(),
  trackId: z.string().min(1).max(MAX_TRACK_ID),
  provider: z.string().regex(/^[a-z0-9_-]{1,64}$/),
  exp: z.number().int().positive(),
}).strict();

type TokenClaims = z.infer<typeof claimsSchema>;
export type PlaybackClaims = TokenClaims;

function secret() {
  const value = process.env.PLAYBACK_SESSION_SECRET;
  if (!value || value.length < 32) {
    throw new Error("PLAYBACK_SESSION_SECRET must be set and contain at least 32 characters.");
  }
  return value;
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issuePlaybackToken(input: Omit<PlaybackClaims, "sessionId">, ttlSeconds = 300) {
  if (!Number.isInteger(ttlSeconds) || ttlSeconds < 1 || ttlSeconds > 3600) {
    throw new Error("Playback token TTL must be an integer between 1 and 3600 seconds.");
  }
  const claims: PlaybackClaims = {
    ...input,
    sessionId: randomUUID(),
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  };
  const parsed = claimsSchema.parse(claims);
  const encoded = Buffer.from(JSON.stringify(parsed)).toString("base64url");
  return `${VERSION}.${encoded}.${sign(encoded)}`;
}

export function verifyPlaybackToken(token: string): PlaybackClaims | null {
  if (typeof token !== "string" || token.length > 4096) return null;
  const [version, encoded, signature] = token.split(".");
  if (version !== VERSION || !encoded || !signature) return null;
  const expected = sign(encoded);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const claims = claimsSchema.parse(JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")));
    if (claims.exp <= Math.floor(Date.now() / 1000)) return null;
    return claims;
  } catch {
    return null;
  }
}
