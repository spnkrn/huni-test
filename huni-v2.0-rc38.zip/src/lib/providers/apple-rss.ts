import { highResArtwork } from "@/lib/utils";
import type { Album, Artist, Track } from "@/lib/types";

const BASE = "https://rss.marketingtools.apple.com/api/v2";

type AppleItem = {
  artistName?: string;
  id?: string;
  name?: string;
  releaseDate?: string;
  artistId?: string;
  artistUrl?: string;
  artworkUrl100?: string;
  genres?: { genreId: string; name: string; url?: string }[];
  url?: string;
  contentAdvisoryRating?: string;
};

type AppleFeed = { feed?: { updated?: string; country?: string; results?: AppleItem[] } };

function artistFrom(item: AppleItem): Artist {
  return { id: `apple-artist-${item.artistId ?? item.artistName ?? "unknown"}`, name: item.artistName ?? "Unknown Artist", providerIds: { itunes: item.artistId } };
}

function artwork(url?: string) {
  if (!url) return undefined;
  const large = highResArtwork(url, 1200);
  return { small: url, medium: large ?? url, large: large ?? url };
}

function albumFrom(item: AppleItem): Album {
  return {
    id: `apple-album-${item.id ?? item.name ?? "unknown"}`,
    title: item.name ?? "Unknown Album",
    artist: artistFrom(item),
    artwork: artwork(item.artworkUrl100),
    releaseDate: item.releaseDate,
    genre: item.genres?.filter(g => g.name !== "Music").map(g => g.name),
    providerIds: { itunes: item.id }
  };
}

function trackFrom(item: AppleItem): Track {
  return {
    id: `apple-track-${item.id ?? item.name ?? "unknown"}`,
    title: item.name ?? "Unknown Song",
    artists: [artistFrom(item)],
    artwork: artwork(item.artworkUrl100),
    releaseDate: item.releaseDate,
    genre: item.genres?.filter(g => g.name !== "Music").map(g => g.name),
    providerIds: { itunes: item.id }
  };
}

async function feed(path: string): Promise<AppleFeed> {
  const res = await fetch(`${BASE}/${path}`, { next: { revalidate: 900 } });
  if (!res.ok) throw new Error(`Apple Music RSS failed: ${res.status}`);
  return res.json() as Promise<AppleFeed>;
}

export async function getAppleMostPlayed(region: string, limitAlbums = 25, limitSongs = 10) {
  const country = region.toLowerCase();
  const [albums, songs] = await Promise.all([
    feed(`${country}/music/most-played/${limitAlbums}/albums.json`),
    feed(`${country}/music/most-played/${limitSongs}/songs.json`)
  ]);
  return {
    updated: albums.feed?.updated ?? songs.feed?.updated,
    albums: (albums.feed?.results ?? []).map(albumFrom),
    tracks: (songs.feed?.results ?? []).map(trackFrom)
  };
}
