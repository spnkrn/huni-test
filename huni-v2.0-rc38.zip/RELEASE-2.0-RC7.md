# Huni 2.0.0 RC.7

## Distributed playback session hardening

- Playback sessions are persisted in Supabase instead of relying on process-local memory.
- Provider stream/download URLs are encrypted at rest with AES-256-GCM using a key derived from `PLAYBACK_SESSION_SECRET`.
- The stream endpoint requires the authenticated Huni user to match the signed playback token.
- Playback session IDs returned to the client now match the Huni signed-token session ID.
- Expired sessions are excluded at query time.

## Certification status

Static/security checks remain source-level gates until npm dependencies can be installed in a network-enabled environment.
