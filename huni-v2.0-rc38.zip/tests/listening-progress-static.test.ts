import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();

describe("listening progress architecture", () => {
  it("has an RLS-protected progress table", () => {
    const sql = readFileSync(join(root, "supabase/migrations/0005_listening_progress.sql"), "utf8");
    expect(sql).toContain("alter table public.listening_progress enable row level security");
    expect(sql).toContain("auth.uid() = user_id");
    expect(sql).toContain("primary key (user_id, track_id)");
  });

  it("uses the progress endpoint for resume and persistence", () => {
    const source = readFileSync(join(root, "src/components/player/player-context.tsx"), "utf8");
    expect(source).toContain("/api/history/progress?trackId=");
    expect(source).toContain("/api/history/progress");
    expect(source).toContain("resumePositionRef");
  });
});
