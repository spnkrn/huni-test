import { NextRequest, NextResponse } from "next/server";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";

export async function GET(request: NextRequest) {
  const rate = rateLimit(`provider-status:${getRequestFingerprint(request)}`, 20, 60_000);
  const headers = { "X-Request-ID": requestId(request), ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers: { ...headers, "Retry-After": String(Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000))) } });
  const checks = await Promise.allSettled([
    fetch("https://itunes.apple.com/search?term=huni&media=music&limit=1", { cache: "no-store" }),
    fetch("https://musicbrainz.org/ws/2/artist?query=artist:huni&fmt=json&limit=1", { cache: "no-store", headers: { "User-Agent": process.env.MUSICBRAINZ_USER_AGENT || "Huni/1.4.0" } }),
    fetch("https://lrclib.net/api/get?track_name=Huni&artist_name=Huni", { cache: "no-store" }),
  ]);
  return NextResponse.json({
    itunes: checks[0].status === "fulfilled" && checks[0].value.ok,
    musicbrainz: checks[1].status === "fulfilled" && checks[1].value.ok,
    lrclib: checks[2].status === "fulfilled" && (checks[2].value.ok || checks[2].value.status === 404),
    qobuz: Boolean(process.env.QOBUZ_ENABLED && process.env.QOBUZ_APP_ID && process.env.QOBUZ_APP_SECRET && process.env.QOBUZ_AUTH_TOKEN),
  }, { headers });
}
