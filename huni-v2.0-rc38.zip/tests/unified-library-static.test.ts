import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("unified library and offline UX", () => {
  it("exposes media and followed-podcast library tabs", () => {
    const page = readFileSync("src/components/library/unified-library-view.tsx", "utf8");
    expect(page).toContain('"music"');
    expect(page).toContain('"podcasts"');
    expect(page).toContain('"following"');
    expect(page).toContain("followedPodcasts");
  });
  it("keeps download filters media-type aware", () => {
    const page = readFileSync("src/app/downloads/page.tsx", "utf8");
    expect(page).toContain('"podcasts"');
    expect(page).toContain('track.mediaType');
  });
});
