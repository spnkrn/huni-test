import { Database, Music2, Radio, Sparkles } from "lucide-react";
import type { Album, Artist, Track } from "@/lib/types";

type Entity = Artist | Album | Track;

function providers(entity: Entity) {
  const ids = entity.providerIds ?? {};
  return [
    ids.qobuz ? { key: "qobuz", label: "Qobuz", icon: Radio } : null,
    ids.itunes ? { key: "itunes", label: "Apple Music / iTunes", icon: Music2 } : null,
    ids.musicbrainz ? { key: "musicbrainz", label: "MusicBrainz", icon: Database } : null
  ].filter(Boolean) as Array<{ key: string; label: string; icon: typeof Radio }>;
}

export function ProviderProvenance({ entity, compact = false }: { entity: Entity; compact?: boolean }) {
  const sources = providers(entity);
  if (!sources.length) return null;
  const merged = sources.length > 1;
  return (
    <div className={compact ? "inline-flex items-center gap-1.5" : "mt-4 flex flex-wrap items-center gap-2"} aria-label={`Metadata source${sources.length > 1 ? "s" : ""}: ${sources.map(s => s.label).join(", ")}`}>
      {!compact && <span className="eyebrow mr-1">Metadata</span>}
      {sources.map(({ key, label, icon: Icon }) => (
        <span key={key} title={label} className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[.045] px-2.5 py-1 text-[10px] text-white/55">
          <Icon size={11} /> {label}
        </span>
      ))}
      {merged && <span title="This page combines metadata identities from multiple providers" className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[.025] px-2 py-1 text-[10px] text-white/35"><Sparkles size={10} /> Merged</span>}
    </div>
  );
}
