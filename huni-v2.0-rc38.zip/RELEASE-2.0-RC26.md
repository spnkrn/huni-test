# Huni 2.0 RC26 — Podcasts + Sleep Timer

- Added a dedicated Podcasts discovery surface with Apple Podcasts charts and top subscriber channels.
- Added iTunes podcast search and a Podcasts tab in global search. Apple documents `media=podcast` and the `podcast` entity for the iTunes Search API.
- Added podcast channel pages with RSS-backed episode lists, pagination, and an episode title/description filter.
- Podcast discovery resolves Apple/iTunes search -> collectionId -> lookup -> feedUrl, then fetches publisher RSS. Episode audio is taken from RSS `<enclosure>` URLs and never exposed directly to the browser.
- Added server-side podcast playback sessions through the existing authenticated playback proxy. Podcast upstream URLs are server-side session data and are revalidated before streaming.
- Added podcast episodes to the same queue/player/mini-player/fullscreen player path as music tracks.
- Added a sleep timer to the shared player; the timer persists locally and pauses playback when it expires.
- Added a Home podcast chart section.
- Added regression-oriented podcast provider/player files.

Apple's archived iTunes Search documentation confirms `media=podcast`, `entity=podcast`, and collection lookup patterns. The current implementation treats publisher RSS as the audio source and does not use iTunes music previews as podcast audio.

Full dependency-backed TypeScript/Vitest/Next build remains environment-dependent in this workspace because dependencies are not installed and registry access has previously failed.
