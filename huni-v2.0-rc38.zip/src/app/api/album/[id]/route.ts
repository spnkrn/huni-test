import { NextRequest, NextResponse } from "next/server";
import { lookupAlbum } from "@/lib/providers/itunes";
import { qobuzMetadata } from "@/lib/providers/qobuz-metadata";
import { getUserContentRegion } from "@/lib/region";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const rate = rateLimit(`album:${getRequestFingerprint(req)}`, 120, 60_000);
  const headers = { "X-Request-ID": requestId(req), ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers });
  const { id } = await ctx.params; const { region } = await getUserContentRegion();
  try {
    if (id.startsWith("qobuz-album-") && qobuzMetadata.isConfigured()) return NextResponse.json(await qobuzMetadata.album(id.replace("qobuz-album-", ""), region), { headers });
    const itunesId = id.replace(/^itunes-album-/, "");
    if (!/^\d+$/.test(itunesId)) return NextResponse.json({ error: "Unsupported album id" }, { status: 400, headers });
    const album = await lookupAlbum(itunesId, region);
    if (!album) return NextResponse.json({ error: "Album not found" }, { status: 404, headers });
    return NextResponse.json(album, { headers });
  } catch { return NextResponse.json({ error: "Album unavailable" }, { status: 502, headers }); }
}
