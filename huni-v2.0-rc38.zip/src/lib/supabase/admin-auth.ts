import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth/login?next=/admin");

  const ids = (process.env.HUNI_ADMIN_USER_IDS ?? "").split(",").map(x => x.trim()).filter(Boolean);
  if (!ids.includes(user.id)) redirect("/");
  return { supabase, user };
}
