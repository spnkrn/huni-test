import { NextRequest, NextResponse } from "next/server";
import { lookupPodcast } from "@/lib/providers/podcasts";
import { fetchPodcastRss } from "@/lib/providers/podcasts";
import { episodeToTrack } from "@/lib/podcast-player";
import { withApiHeaders } from "@/lib/security/api";
import { getUserContentRegion } from "@/lib/region";

function decode(id: string) { try { return JSON.parse(Buffer.from(id.slice("podcast-episode-".length), "base64url").toString("utf8")) as { podcastId: string; guid: string }; } catch { return null; } }
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const headers = withApiHeaders(req); const { id } = await params; const decoded = decode(id); if (!decoded) return NextResponse.json({ error: "Invalid podcast episode" }, { status: 400, headers });
  try { const region=(await getUserContentRegion()).region; const podcast=await lookupPodcast(decoded.podcastId, region); if(!podcast) return NextResponse.json({error:"Podcast not found"},{status:404,headers}); const rss=await fetchPodcastRss(podcast,1,500); const episode=rss.episodes.find(e=>e.guid===decoded.guid); if(!episode) return NextResponse.json({error:"Episode not found"},{status:404,headers}); return NextResponse.json(episodeToTrack(episode,podcast.title,podcast.author),{headers}); } catch { return NextResponse.json({error:"Podcast episode unavailable"},{status:502,headers}); }
}
