# Huni architecture

Browser
→ Huni route handlers
→ provider adapters
→ canonical domain models
→ React UI

## Provider boundaries

`src/lib/providers/itunes.ts`
`src/lib/providers/musicbrainz.ts`
`src/lib/providers/lrclib.ts`

No UI component should depend on provider-specific JSON.

## Player

A single HTMLAudioElement is mounted by `PlayerProvider` so route changes do not recreate playback state.

The player only consumes `Track.audioUrl` when an authorized audio adapter provides one. iTunes `previewUrl` is deliberately not used as the full-length player source.

## Lyrics

LRCLIB returns LRC/plain lyrics. LRC is normalized to `{timeMs,text}`. The lyrics UI determines the active line from the actual player position, scrolls it into view, and seeks when a line is tapped.

The `am-lyrics` project was studied as a reference for word/line synchronization behavior; its current package is a Lit web component and is licensed MPL-2.0. Huni's starter uses a native React renderer so the visual system can be controlled directly.

## Next phase

Add a `MusicProvider` interface:

```ts
interface MusicProvider {
  searchTracks(query: string): Promise<Track[]>;
  searchAlbums(query: string): Promise<Album[]>;
  searchArtists(query: string): Promise<Artist[]>;
  getTrack(id: string): Promise<Track | null>;
  getAlbum(id: string): Promise<Album | null>;
  getArtist(id: string): Promise<Artist | null>;
}
```

Add an `AudioProvider` interface:

```ts
interface AudioProvider {
  resolve(track: Track): Promise<{ url: string; expiresAt: string } | null>;
}
```

Only the server may hold provider credentials.

## Iteration 2
Artist routes now resolve iTunes artist IDs to release collections and enrich the artist with MusicBrainz. The player has a persistent queue, shuffle/repeat state, buffered-position state and Media Session metadata. Provider health is exposed through `/api/providers/status` for deployment diagnostics.

## Iteration 3 — persistence and playback boundaries

- Player event listeners are now mounted once and use refs for queue/repeat/shuffle state, avoiding listener churn during playback.
- Tracks without an authorized `audioUrl` no longer enter a false playing state.
- `supabase-schema.sql` provides the first RLS-protected persistence model for profiles, library, playlists, playlist tracks, history, and favorites.
- `src/lib/providers/audio.ts` establishes an audio-provider adapter boundary. The Qobuz adapter is intentionally non-functional until a legitimate authorized integration is supplied.
- `POST /api/playback/session` is a server-side boundary that rejects arbitrary upstream URLs. It is deliberately disabled until Supabase authentication and an authorized provider session flow are implemented.
- No iTunes preview is promoted to full-length playback.

## Iteration 3 — persistent interactions

Huni now exposes authenticated API boundaries for library saves, favorites, listening history, playlist creation, and playlist track membership. Client controls call these routes; the server obtains the Supabase session and relies on RLS/ownership checks. No client-supplied user ID is trusted.

Playlist track JSON stores the canonical Huni Track object so the UI can render saved music without re-querying the catalog. This is intentionally a denormalized cache; canonical provider metadata can be refreshed later without changing ownership records.

Listening history is written only after the browser successfully starts an available audio URL. Metadata-only browsing does not create fake listening events.

## Iteration 6 — Authorized playback session boundary

Huni now has a provider registry and a signed playback-session token boundary. Browser requests provide only a canonical track ID. The server verifies the authenticated Supabase user and that the track belongs to that user's persisted library before asking a configured audio provider for a playback session. Provider credentials and upstream resolution remain server-only. Signed session tokens are short-lived and use HMAC-SHA256. This is an authorization boundary, not a DRM circumvention mechanism.

## Iteration 7 — provider resolution boundary

Huni now has a provider-resolution boundary separate from metadata providers. A server-side authorized audio gateway may be configured through `HUNI_AUDIO_PROVIDER_GATEWAY_URL`, with an HTTPS hostname allowlist and an 8-second timeout. The browser never submits an upstream URL. The gateway must return a short-lived playback session and must perform the provider's own authorization.

Qobuz remains opt-in. Current Qobuz API terms state that an application requires credentials issued by Qobuz and that application ID/secret must not be shared with third parties. Huni therefore does not embed or expose those credentials in browser code.

## Iteration 8 — playback client integration

The player now treats playback as an authorized server-issued session rather than consuming a client-supplied audio URL. A play request sends only the canonical Huni track ID to `/api/playback/session`; the server authenticates the user, resolves trusted metadata, asks the configured audio provider for a short-lived session, and returns the session URL. The browser keeps the URL in the HTML audio element only for the lifetime of that session.

Playback sessions are cached in-memory only at the player level and are renewed shortly before expiry while the same track is actively playing. Renewal stops when playback is paused or the player is unmounted. Provider errors are surfaced as honest player errors instead of falling back to iTunes preview audio.

## v1.0 player UX

The player now separates transport state from presentation. The persistent player owns the queue, playback session, seek position, buffered position, volume, mute state, shuffle and repeat modes. The fullscreen player is a presentation layer and never receives provider URLs directly. Queue and media-session controls call the same player transport methods, so navigation does not create a second audio element.

Lyrics remain metadata-only until a real LRCLIB response is available. Synced lines use the player clock; word-level karaoke is not fabricated when word timestamps are absent.

## v1.1 / v1.2 discovery + PWA
- Home discovery uses live iTunes metadata and authenticated Supabase history/library records when available.
- No recommendation cards are fabricated; personal sections render only when real user data exists.
- The PWA manifest is generated by the Next.js App Router.
- The service worker caches only same-origin static script/style/font/image requests. Authenticated API responses, auth routes, Next image optimization, and audio/provider traffic are intentionally excluded.
- Authenticated pages remain dynamically rendered to avoid cross-user cache leakage.

## Iteration 1.3 — Production QA gate

- Authenticated pages use `force-dynamic` to prevent ISR/shared-cache session leakage.
- Playback session tokens have bounded TTLs (1–3600 seconds).
- Authorized audio gateway endpoints and returned stream/download URLs are HTTPS-only and host-allowlisted.
- Added environment validation and security-focused provider/token tests.

## v1.4 reliability boundary

API routes now carry request IDs and bounded rate-limit headers. Public catalog endpoints use IP fingerprints; playback-session creation uses an authenticated user/IP fingerprint. This limiter is process-local by design and must be backed by a shared store for horizontally scaled production.

Structured logging records event names, timing context and safe identifiers while filtering likely secret/token/URL fields. Provider failures return generic client-facing messages while retaining a correlation request ID.

## Iteration 1.6 — release hardening

Authentication redirects now pass through a single same-origin relative-path validator. This prevents the `next` parameter from becoming an open redirect while preserving legitimate internal navigation after login/signup.
