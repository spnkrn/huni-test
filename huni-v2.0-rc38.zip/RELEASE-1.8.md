# Huni 1.8.0 — Accessibility & Release Hardening

## Completed
- Added root loading UI and a recoverable global error boundary.
- Added a not-found experience.
- Added a keyboard-accessible skip link to the main content region.
- Added consistent `:focus-visible` treatment.
- Added navigation landmarks and labels.
- Kept Admin out of the five-item mobile navigation so the mobile bar matches the product navigation model.
- Preserved reduced-motion behavior.
- Bumped the package version to 1.8.0.

## Validation gate
Run in a dependency-enabled environment:

```bash
npm ci
npm run verify:env
npm run audit:security
npm run typecheck
npm test
npm run test:security
npm run build
```

This release does not claim a green build until those commands execute successfully in a clean environment with the required dependencies and deployment variables.
