# Provider notes

## iTunes Search API

Used for public catalog metadata, artwork and lookup/search. Huni does not treat its preview audio as the main streaming source.

## MusicBrainz

Used for canonical artist/release enrichment. Requests must include a meaningful User-Agent and respect the service rate limit. Huni's adapter serializes requests.

## LRCLIB

Used for synchronized/plain lyrics. Lyrics are requested server-side and cached through Next.js revalidation.

## am-lyrics

The open-source `am-lyrics` implementation is useful as a synchronization/UI reference. Its current project describes a web component with line-click events, current-time input, autoscroll and interpolation. Huni implements the core synchronization pattern in React rather than copying its source.

## Authorized audio providers

The repository intentionally has no unauthorized or reverse-engineered audio source. A future adapter can provide short-lived `audioUrl` values to the player after authorization is established server-side.

### Audio session contract

Audio providers implement `createPlaybackSession(track, userId)` and return a short-lived session with `sessionId`, `expiresAt`, and an HTTPS `streamUrl`. Huni does not accept arbitrary upstream URLs from the client and does not implement DRM circumvention. The current Qobuz adapter remains disabled until a legitimate provider-issued integration is configured.
