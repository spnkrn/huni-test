-- RC30: local-first is a client capability; no anonymous rows are written to Supabase.
-- This migration documents the server boundary and adds an index useful for account sync.
create index if not exists library_tracks_user_created_at_idx on public.library_tracks(user_id, created_at desc);
create index if not exists track_favorites_user_created_at_idx on public.track_favorites(user_id, created_at desc);
