import { describe, expect, it, beforeEach, vi } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(process.cwd());
import { callAuthorizedAudioGateway } from "@/lib/providers/http";

describe("authorized audio gateway", () => {
  beforeEach(() => {
    process.env.HUNI_AUDIO_PROVIDER_GATEWAY_URL = "https://audio.example.com/session";
    process.env.HUNI_AUDIO_PROVIDER_ALLOWED_HOSTS = "audio.example.com";
  });

  it("rejects a gateway outside the host allowlist", async () => {
    process.env.HUNI_AUDIO_PROVIDER_GATEWAY_URL = "https://evil.example/session";
    await expect(callAuthorizedAudioGateway({ track: {}, userId: "u1", provider: "qobuz" })).rejects.toThrow(/allowlist/);
  });

  it("rejects non-HTTPS gateways", async () => {
    process.env.HUNI_AUDIO_PROVIDER_GATEWAY_URL = "http://audio.example.com/session";
    await expect(callAuthorizedAudioGateway({ track: {}, userId: "u1", provider: "qobuz" })).rejects.toThrow(/HTTPS/);
  });

  it("rejects gateway responses with an unapproved stream host", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(JSON.stringify({
      sessionId: "s1",
      expiresAt: new Date(Date.now() + 60_000).toISOString(),
      streamUrl: "https://evil.example/stream",
    }), { status: 200, headers: { "content-type": "application/json" } })));

    await expect(callAuthorizedAudioGateway({ track: {}, userId: "u1", provider: "qobuz" })).rejects.toThrow(/allowlist/);
  });
});


describe("authorized audio gateway redirect hardening", () => {
  it("rejects redirect responses from the gateway", async () => {
    const source = readFileSync(`${root}/src/lib/providers/http.ts`, "utf8");
    expect(source).toContain('redirect: "manual"');
    expect(source).toContain("Audio gateway redirects are not allowed.");
  });

  it("exports URL validation for the playback proxy", async () => {
    const source = readFileSync(`${root}/src/lib/providers/http.ts`, "utf8");
    expect(source).toContain("export function assertSafeUrl");
  });
});
