# Huni 2.0 RC.22

## Playlist lifecycle and consistency

- Added authenticated playlist-track reorder endpoint.
- Reorder requests validate ownership, uniqueness, and the complete current track set to avoid lost updates.
- Playlist UI supports drag-and-drop ordering and persists the order.
- Active playlist queues mirror reorder operations when the active queue exactly matches the playlist snapshot.
- Playlist removal updates the active queue for an exact playlist snapshot.
- Added static regression coverage.

Dependency-backed certification remains environment-dependent until npm dependencies and a lockfile are available.
