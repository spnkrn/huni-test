# Huni 2.0 RC34

## Offline download manager
- Real-time byte progress for browser-local audio downloads.
- Downloads page reports item count and aggregate storage size.
- Online/offline status indicator.
- Remove-all downloads control.
- Podcast channel pages can download all episodes on the current page sequentially.
- Shared music and podcast offline storage remains backed by IndexedDB.

## Player/discovery continuity
- Existing offline-first player preference remains intact.
- Podcast and music downloads continue using the same Huni download/session architecture.
- No raw publisher/provider URLs are exposed as the offline-store API.

Full dependency-backed certification remains environment-dependent when dependencies are not installed.
