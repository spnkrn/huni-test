"use client";

import { ListMusic, Play, Shuffle } from "lucide-react";
import { Track } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";

export function PlaylistPlayerControls({ tracks }: { tracks: Track[] }) {
  const { playTracks } = usePlayer();
  const disabled = tracks.length === 0;
  return (
    <div className="mt-6 flex flex-wrap gap-2">
      <button disabled={disabled} onClick={() => playTracks(tracks, 0, false)} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-medium text-black disabled:opacity-30">
        <Play size={16} fill="currentColor" /> Play all
      </button>
      <button disabled={disabled} onClick={() => playTracks(tracks, 0, true)} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[.05] px-4 py-2 text-sm font-medium text-white hover:bg-white/[.08] disabled:opacity-30">
        <Shuffle size={16} /> Shuffle
      </button>
      <div className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-xs text-white/40">
        <ListMusic size={14} /> {tracks.length} {tracks.length === 1 ? "track" : "tracks"}
      </div>
    </div>
  );
}
