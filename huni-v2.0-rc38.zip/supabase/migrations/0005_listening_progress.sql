create table if not exists public.listening_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id text not null,
  position_seconds numeric not null default 0,
  duration_seconds numeric,
  updated_at timestamptz not null default now(),
  primary key (user_id, track_id),
  constraint listening_progress_position_nonnegative check (position_seconds >= 0),
  constraint listening_progress_duration_positive check (duration_seconds is null or duration_seconds > 0)
);

alter table public.listening_progress enable row level security;
create policy "progress_self_all" on public.listening_progress for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists listening_progress_user_updated_idx on public.listening_progress(user_id, updated_at desc);
