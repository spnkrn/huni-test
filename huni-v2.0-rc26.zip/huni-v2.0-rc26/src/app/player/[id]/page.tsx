"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { ChevronDown, ListMusic, Pause, Play, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Shuffle, Timer } from "lucide-react";
import { Track, Lyrics } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";
import { LyricsView } from "@/components/lyrics/lyrics-view";
import { PlayerProgress } from "@/components/player/player-progress";
import { QueueDrawer } from "@/components/player/queue-drawer";

export default function PlayerPage({ params }: { params: Promise<{ id: string }> }) {
  const [track, setTrack] = useState<Track | null>(null);
  const [lyrics, setLyrics] = useState<Lyrics | null>(null);
  const [queueOpen, setQueueOpen] = useState(false);
  const { track: active, playing, loading, toggle, play, next, previous, shuffle, setShuffle, repeat, setRepeat, volume, muted, setVolume, setMuted, sleepTimerMinutes, setSleepTimer } = usePlayer();

  useEffect(() => {
    let cancelled = false;
    params.then(({ id }) => fetch(id.startsWith("podcast-episode-") ? `/api/podcast-episode/${id}` : `/api/track/${id}`).then(r => r.ok ? r.json() : null).then(async (t) => {
      if (cancelled) return;
      setTrack(t);
      if (t) {
        play(t);
        const qs = new URLSearchParams({ track: t.title, artist: t.artists[0]?.name ?? "", ...(t.album?.title ? { album: t.album.title } : {}) });
        const lr = await fetch(`/api/lyrics?${qs}`);
        if (!cancelled && lr.ok) setLyrics(await lr.json());
      }
    }));
    return () => { cancelled = true; };
  }, [params]);

  const current = active ?? track;
  if (!current) return <div className="py-24 text-center text-white/35">Loading player…</div>;

  const art = current.artwork?.large ?? current.artwork?.medium;
  return (
    <div className="fixed inset-0 z-20 overflow-hidden bg-[#080808]">
      <div className="absolute inset-0 opacity-25 blur-3xl transition-opacity duration-700">
        {art ? <Image src={art} alt="" fill className="object-cover scale-110" /> : null}
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-[#080808]/60 to-[#080808]" />
      <div className="relative mx-auto flex h-full max-w-7xl flex-col px-5 py-5 md:px-10">
        <div className="flex items-center justify-between">
          <button className="icon-button" onClick={() => history.back()} aria-label="Close player"><ChevronDown /></button>
          <div className="eyebrow">Now Playing</div>
          <button className="icon-button" onClick={() => setQueueOpen(true)} aria-label="Open queue"><ListMusic /></button>
        </div>
        <div className="grid min-h-0 flex-1 gap-7 py-6 lg:grid-cols-[minmax(300px,44%)_1fr] lg:items-center">
          <div className="flex min-h-0 flex-col justify-center">
            <div className="relative mx-auto aspect-square w-full max-w-[500px] overflow-hidden rounded-[30px] border border-white/10 bg-white/5 shadow-2xl shadow-black/50">
              {art ? <Image src={art} alt="" fill sizes="500px" className="object-cover" priority /> : null}
            </div>
            <div className="mx-auto mt-6 w-full max-w-[500px]">
              <div className="text-xl font-semibold tracking-tight">{current.title}</div>
              <div className="mt-1 text-sm text-white/45">{current.artists.map(a => a.name).join(", ")}</div>
              <div className="mt-5"><PlayerProgress /></div>
              <div className="mt-3 flex items-center justify-between">
                <button className={`icon-button ${shuffle ? "text-white" : "text-white/35"}`} onClick={() => setShuffle(!shuffle)} aria-label="Toggle shuffle"><Shuffle size={17} /></button>
                <button className="icon-button" onClick={previous} aria-label="Previous"><SkipBack size={20} fill="currentColor" /></button>
                <button onClick={toggle} disabled={loading} aria-label={playing ? "Pause" : "Play"} className="grid size-16 place-items-center rounded-full bg-white text-black shadow-xl transition hover:scale-105 disabled:opacity-50">
                  {playing ? <Pause size={25} fill="currentColor" /> : <Play size={25} fill="currentColor" />}
                </button>
                <button className="icon-button" onClick={next} aria-label="Next"><SkipForward size={20} fill="currentColor" /></button>
                <button className={`icon-button ${repeat !== "off" ? "text-white" : "text-white/35"}`} onClick={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")} aria-label={`Repeat ${repeat}`}><Repeat size={17} /></button>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <button className="text-white/45 hover:text-white" onClick={() => setMuted(!muted)} aria-label={muted ? "Unmute" : "Mute"}>{muted ? <VolumeX size={16} /> : <Volume2 size={16} />}</button>
                <input aria-label="Volume" type="range" min={0} max={1} step={0.01} value={muted ? 0 : volume} onChange={(e) => { setMuted(false); setVolume(Number(e.target.value)); }} className="h-1 w-28 accent-white" />
              </div>
              <button className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/10 px-3 py-2 text-xs text-white/50 hover:text-white" onClick={() => setSleepTimer(sleepTimerMinutes ? 0 : 30)}><Timer size={14} />{sleepTimerMinutes ? `Sleep in ${sleepTimerMinutes}m` : "Sleep timer"}</button>
              {!current.audioUrl && current.mediaType !== "podcast" && <div className="mt-4 text-center text-[11px] text-white/35">Playback requires an authorized full-length audio provider. Huni does not use catalog previews as full-track audio.</div>}
            </div>
          </div>
          <div className="min-h-0 overflow-hidden rounded-[24px] border border-white/10 bg-black/20 shadow-xl backdrop-blur-xl">
            {lyrics ? <LyricsView lyrics={lyrics} /> : <div className="grid h-full place-items-center text-sm text-white/35">Lyrics unavailable.</div>}
          </div>
        </div>
      </div>
      <QueueDrawer open={queueOpen} onClose={() => setQueueOpen(false)} />
    </div>
  );
}
