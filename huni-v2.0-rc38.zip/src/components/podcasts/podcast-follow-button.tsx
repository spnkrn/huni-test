"use client";
import { Check, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import type { Podcast } from "@/lib/podcast-types";
import { localStore } from "@/lib/local-store";
import { useLocalLibrary } from "@/components/library/local-library-provider";

export function PodcastFollowButton({ podcast }: { podcast: Podcast }) {
  const { userId } = useLocalLibrary(); const [following, setFollowing] = useState(false); const [busy, setBusy] = useState(false);
  useEffect(() => setFollowing(localStore.isFollowingPodcast(podcast.id)), [podcast.id]);
  async function toggle() {
    setBusy(true); const next = localStore.toggleFollowPodcast(podcast); setFollowing(next);
    if (userId) { const response = await fetch(`/api/podcast-follows${next ? "" : `?id=${encodeURIComponent(podcast.id)}`}`, { method: next ? "POST" : "DELETE", headers: next ? { "content-type": "application/json" } : undefined, body: next ? JSON.stringify({ podcast }) : undefined }).catch(() => null); if (!response?.ok) localStore.toggleFollowPodcast(podcast); }
    setBusy(false);
  }
  return <button disabled={busy} onClick={() => void toggle()} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[.06] px-3 py-2 text-xs text-white/70 hover:bg-white/[.1] disabled:opacity-40" aria-pressed={following}>{following ? <Check size={14}/> : <Plus size={14}/>} {following ? "Following" : "Follow"}</button>;
}
