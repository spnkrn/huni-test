"use client";

import { useEffect, useState } from "react";
import { Check, Heart, ListPlus, Loader2, Plus, X } from "lucide-react";
import { Track } from "@/lib/types";

type Playlist = { id: string; name: string };

async function request(url: string, init?: RequestInit) {
  const res = await fetch(url, { ...init, headers: { "content-type": "application/json", ...(init?.headers ?? {}) } });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error ?? "Request failed");
  return body;
}

export function TrackActions({ track }: { track: Track }) {
  const [saved, setSaved] = useState(false);
  const [favorite, setFavorite] = useState(false);
  const [open, setOpen] = useState(false);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    Promise.all([
      fetch("/api/library").then(r => r.ok ? r.json() : null),
      fetch("/api/favorites").then(r => r.ok ? r.json() : null)
    ]).then(([library, favs]) => {
      if (library) setSaved(library.trackIds.includes(track.id));
      if (favs) setFavorite(favs.trackIds.includes(track.id));
    }).catch(() => undefined);
  }, [track.id]);

  async function toggleLibrary() {
    setBusy(true); setMessage("");
    try {
      await request(saved ? `/api/library?trackId=${encodeURIComponent(track.id)}` : "/api/library", saved ? { method: "DELETE" } : { method: "POST", body: JSON.stringify({ track }) });
      setSaved(!saved);
    } catch (error) { setMessage(error instanceof Error ? error.message : "Sign in to save music"); }
    finally { setBusy(false); }
  }

  async function toggleFavorite() {
    setBusy(true); setMessage("");
    try {
      await request(favorite ? `/api/favorites?trackId=${encodeURIComponent(track.id)}` : "/api/favorites", favorite ? { method: "DELETE" } : { method: "POST", body: JSON.stringify({ trackId: track.id }) });
      setFavorite(!favorite);
    } catch (error) { setMessage(error instanceof Error ? error.message : "Sign in to favorite music"); }
    finally { setBusy(false); }
  }

  async function openPlaylists() {
    setOpen(true); setMessage("");
    try { const data = await request("/api/playlists"); setPlaylists(data.playlists ?? []); }
    catch (error) { setMessage(error instanceof Error ? error.message : "Sign in to use playlists"); }
  }

  async function addToPlaylist(id: string) {
    setBusy(true); setMessage("");
    try { await request(`/api/playlists/${id}/tracks`, { method: "POST", body: JSON.stringify({ track }) }); setMessage("Added to playlist"); }
    catch (error) { setMessage(error instanceof Error ? error.message : "Could not add track"); }
    finally { setBusy(false); }
  }

  async function createPlaylist() {
    const name = window.prompt("Playlist name");
    if (!name?.trim()) return;
    setBusy(true); setMessage("");
    try {
      const data = await request("/api/playlists", { method: "POST", body: JSON.stringify({ name }) });
      setPlaylists(prev => [data.playlist, ...prev]);
      await addToPlaylist(data.playlist.id);
    } catch (error) { setMessage(error instanceof Error ? error.message : "Could not create playlist"); setBusy(false); }
  }

  return (
    <div className="relative flex items-center gap-1">
      <button aria-label={favorite ? "Unfavorite" : "Favorite"} title={favorite ? "Unfavorite" : "Favorite"} onClick={toggleFavorite} className={`icon-button ${favorite ? "text-white" : "text-white/35"}`} disabled={busy}>
        {busy ? <Loader2 size={16} className="animate-spin" /> : <Heart size={16} fill={favorite ? "currentColor" : "none"} />}
      </button>
      <button aria-label="Add to playlist" title="Add to playlist" onClick={openPlaylists} className="icon-button text-white/35 hover:text-white"><ListPlus size={16} /></button>
      {open && <div className="absolute right-0 top-10 z-30 w-64 rounded-2xl border border-white/10 bg-[#111] p-2 shadow-2xl">
        <div className="flex items-center justify-between px-2 py-2"><span className="text-xs font-medium">Add to playlist</span><button onClick={() => setOpen(false)} className="text-white/35 hover:text-white"><X size={15} /></button></div>
        {playlists.map(p => <button key={p.id} onClick={() => addToPlaylist(p.id)} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm hover:bg-white/[.07]"><Plus size={14} className="text-white/35" />{p.name}</button>)}
        <button onClick={createPlaylist} className="mt-1 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm text-white/60 hover:bg-white/[.07] hover:text-white"><Plus size={14} />New playlist</button>
        {message && <div className="px-3 py-2 text-xs text-white/40">{message}</div>}
      </div>}
    </div>
  );
}
