import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { rateLimitHeaders, type RateLimitResult } from "@/lib/security/rate-limit";

export function requestId(request: Request) {
  return request.headers.get("x-request-id")?.slice(0, 128) || randomUUID();
}

export function jsonError(request: Request, message: string, status: number, limit?: RateLimitResult) {
  const headers: Record<string, string> = {
    "Cache-Control": "private, no-store",
    "X-Request-ID": requestId(request),
    ...(limit ? rateLimitHeaders(limit) : {}),
  };
  if (status === 429 && limit) {
    headers["Retry-After"] = String(Math.max(1, Math.ceil((limit.resetAt - Date.now()) / 1000)));
  }
  return NextResponse.json({ error: message, requestId: headers["X-Request-ID"] }, { status, headers });
}

export function withApiHeaders(request: Request, init?: HeadersInit) {
  const headers = new Headers(init);
  headers.set("Cache-Control", "private, no-store");
  headers.set("X-Request-ID", requestId(request));
  return headers;
}

/** Reject cross-origin state-changing requests when an Origin header is present. */
export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    return new URL(origin).origin === new URL(request.url).origin;
  } catch {
    return false;
  }
}

/** Lightweight content-length guard for JSON mutation endpoints. */
export function bodyWithinLimit(request: Request, maxBytes = 128 * 1024) {
  const raw = request.headers.get("content-length");
  if (!raw) return true;
  const length = Number(raw);
  return Number.isFinite(length) && length >= 0 && length <= maxBytes;
}


export async function readJson<T = unknown>(request: Request, maxBytes = 32_768): Promise<T | null> {
  const length = Number(request.headers.get("content-length") || 0);
  if (Number.isFinite(length) && length > maxBytes) return null;
  const raw = await request.text();
  if (new TextEncoder().encode(raw).byteLength > maxBytes) return null;
  try { return JSON.parse(raw) as T; } catch { return null; }
}
