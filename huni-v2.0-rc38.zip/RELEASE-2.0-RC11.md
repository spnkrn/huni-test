# Huni 2.0 RC.11

## Playback session lifecycle hardening

- Added server-side cleanup of expired playback sessions, scoped to the authenticated user whose new session is being stored.
- Cleanup is best-effort; playback access remains strictly gated by `expires_at > now`.
- Corrected the static RLS test to distinguish the baseline table migration from the follow-up server-managed hardening migration.
- Preserved AES-256-GCM encryption for provider URLs and server-only Supabase capability-store access.

## Certification status

Static and security audits must pass before packaging. Full dependency installation, TypeScript, Vitest, ESLint, and Next.js production build remain environment-dependent until the npm registry is reachable.
