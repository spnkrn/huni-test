import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { bodyWithinLimit, jsonError, readJson, sameOrigin, withApiHeaders } from "@/lib/security/api";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";

export async function GET(request: Request) {
  const supabase = await createClient(); const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const limit = Math.min(100, Math.max(1, Number(new URL(request.url).searchParams.get("limit") ?? 50)));
  const { data, error } = await supabase.from("podcast_follows").select("podcast_id,podcast,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(limit);
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ podcasts: (data ?? []).map(row => row.podcast).filter(Boolean) }, { headers: withApiHeaders(request) });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const limit = rateLimit(`podcast-follows:${getRequestFingerprint(request)}`, 60, 60_000);
  if (!limit.allowed) return jsonError(request, "Too many requests", 429, limit);
  const supabase = await createClient(); const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const body = await readJson<Record<string, unknown>>(request);
  const podcast = body?.podcast;
  if (!podcast || typeof podcast !== "object" || typeof (podcast as any).id !== "string" || typeof (podcast as any).title !== "string") return jsonError(request, "Invalid podcast", 400);
  const { error } = await supabase.from("podcast_follows").upsert({ user_id: user.id, podcast_id: (podcast as any).id, podcast }, { onConflict: "user_id,podcast_id" });
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ followed: true }, { headers: withApiHeaders(request) });
}

export async function DELETE(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  const supabase = await createClient(); const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const id = new URL(request.url).searchParams.get("id"); if (!id || id.length > 300) return jsonError(request, "Invalid podcast", 400);
  const { error } = await supabase.from("podcast_follows").delete().eq("user_id", user.id).eq("podcast_id", id);
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ followed: false }, { headers: withApiHeaders(request) });
}
