import { NextRequest, NextResponse } from "next/server";
import { lookupArtist } from "@/lib/providers/itunes";
import { qobuzMetadata } from "@/lib/providers/qobuz-metadata";
import { searchMusicBrainzArtists } from "@/lib/providers/musicbrainz";
import { getUserContentRegion } from "@/lib/region";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const rate = rateLimit(`artist:${getRequestFingerprint(req)}`, 120, 60_000);
  const headers = { "X-Request-ID": requestId(req), ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers });
  const { id } = await ctx.params;
  const { region } = await getUserContentRegion();
  try {
    if (id.startsWith("qobuz-artist-") && qobuzMetadata.isConfigured()) return NextResponse.json(await qobuzMetadata.artist(id.replace("qobuz-artist-", ""), region), { headers });
    const itunesId = id.replace(/^itunes-artist-/, "");
    if (!/^\d+$/.test(itunesId)) return NextResponse.json({ error: "Unsupported artist id" }, { status: 400, headers });
    const result = await lookupArtist(itunesId, region);
    if (!result) return NextResponse.json({ error: "Artist not found" }, { status: 404, headers });
    const mb = await searchMusicBrainzArtists(result.artist.name).catch(() => []);
    return NextResponse.json({ ...result, artist: { ...result.artist, musicbrainzId: mb[0]?.musicbrainzId, country: mb[0]?.country, type: mb[0]?.type } }, { headers });
  } catch { return NextResponse.json({ error: "Artist unavailable" }, { status: 502, headers }); }
}
