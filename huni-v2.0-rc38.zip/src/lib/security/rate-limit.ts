import { createHash } from "node:crypto";

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();
const MAX_BUCKETS = 10_000;

function now() { return Date.now(); }
function fingerprint(value: string) {
  return createHash("sha256").update(value).digest("hex").slice(0, 24);
}

export type RateLimitResult = {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetAt: number;
};

/** Best-effort per-instance limiter. Use a shared store (Redis/Upstash/etc.) for multi-instance production. */
export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const timestamp = now();
  const bucketKey = fingerprint(key);
  const current = buckets.get(bucketKey);

  if (!current || current.resetAt <= timestamp) {
    if (buckets.size >= MAX_BUCKETS) {
      for (const [k, bucket] of buckets) {
        if (bucket.resetAt <= timestamp) buckets.delete(k);
        if (buckets.size < MAX_BUCKETS) break;
      }
    }
    const next = { count: 1, resetAt: timestamp + windowMs };
    buckets.set(bucketKey, next);
    return { allowed: true, limit, remaining: Math.max(0, limit - 1), resetAt: next.resetAt };
  }

  current.count += 1;
  return {
    allowed: current.count <= limit,
    limit,
    remaining: Math.max(0, limit - current.count),
    resetAt: current.resetAt,
  };
}

export function getRequestFingerprint(request: Request, subject?: string) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const real = request.headers.get("x-real-ip")?.trim();
  const ip = forwarded || real || "unknown-ip";
  return subject ? `${subject}:${ip}` : ip;
}

export function rateLimitHeaders(result: RateLimitResult) {
  return {
    "X-RateLimit-Limit": String(result.limit),
    "X-RateLimit-Remaining": String(result.remaining),
    "X-RateLimit-Reset": String(Math.ceil(result.resetAt / 1000)),
  };
}
