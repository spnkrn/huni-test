import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const home = readFileSync("src/app/page.tsx", "utf8");
const apple = readFileSync("src/lib/providers/apple-rss.ts", "utf8");
const qobuz = readFileSync("src/lib/providers/qobuz-metadata.ts", "utf8");
const region = readFileSync("src/app/api/settings/region/route.ts", "utf8");

describe("regional home provenance", () => {
  it("uses Apple Music RSS charts and regional Qobuz metadata", () => {
    expect(home).toContain("getAppleMostPlayed");
    expect(home).toContain("qobuzMetadata.home");
    expect(apple).toContain("most-played");
    expect(qobuz).toContain("QOBUZ_METADATA_GATEWAY_URL");
  });
  it("persists a user-selected two-letter content region", () => {
    expect(region).toContain("content_region");
    expect(region).toContain("sameOrigin(request)");
    expect(region).toContain("bodyWithinLimit(request");
  });
});
