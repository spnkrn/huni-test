# Huni

Huni is a premium music discovery web application built around real catalog metadata. This iteration adds artist discography routing, queue state, Media Session metadata, provider health checks, and a stronger player foundation.

## Current real integrations
- iTunes Search API: search, artwork, albums, artist discography, track lookup.
- MusicBrainz: artist enrichment and canonical IDs. The server sends a meaningful User-Agent and must stay within MusicBrainz request limits.
- LRCLIB: synchronized/plain lyric retrieval.

## Audio boundary
Huni intentionally does not use iTunes preview URLs as its primary player. Full-length playback requires a separately configured, authorized audio provider. The player accepts an `audioUrl` only from that provider layer.

## Run
```bash
cp .env.example .env.local
npm install
npm run dev
```

## Tests
```bash
npm test
npm run typecheck
```

## Next production milestone
Add Supabase persistence/authentication and a server-side authorized audio-provider adapter. Provider credentials must remain server-side; the browser should only receive short-lived Huni playback sessions.

### Persistence and playback status

Huni now includes a Supabase/Postgres schema with row-level security and a server-side audio-session boundary. The playback route is intentionally disabled until an authenticated, authorized audio provider integration is configured. This is by design: Huni must not expose provider credentials, accept arbitrary CDN URLs, or pretend that metadata/preview access is equivalent to licensed full-length playback.

### v0.4 → v0.5 interaction layer

The current source also includes authenticated interaction endpoints and UI controls for saving/favoriting tracks, creating playlists, adding/removing tracks, opening playlist detail pages, and recording actual playback history. Apply `supabase-schema.sql` before testing these features.

### Playback status

Huni v0.8 wires the browser player to the authorized playback-session boundary. It does not use iTunes preview URLs as full-length playback. If no authorized audio provider is configured, play requests return an explicit unavailable state.

### v1.0 player

The fullscreen player now includes a buffered progress rail, seek control, volume/mute, shuffle/repeat controls, a queue drawer, and synced-lyrics auto-scroll. All controls operate on the persistent player context. Full-length playback still requires an authorized audio provider session.

### PWA
Huni now exposes a generated web manifest and a conservative service worker. Only static browser assets are cached; authenticated API responses, auth routes, optimized images, audio, and provider traffic are excluded from the service worker cache.

### Production verification

Run `npm run verify:env` before `npm run build`. The verification command checks only configuration shape and never prints secret values. For authenticated deployments, do not enable ISR/CDN caching on routes that refresh Supabase sessions.

## v1.7 security audit

Run `npm run audit:security` to statically inspect API routes for state-changing origin protection and explicit private/no-store response handling.


## 1.8 release notes
See `RELEASE-1.8.md` for the accessibility, loading/error, and release-hardening changes.


## Playback security boundary

Huni resolves authorized playback server-side. The browser receives a short-lived Huni proxy URL rather than the provider upstream URL. The proxy validates the signed session token, enforces expiry and user/track/provider binding, forwards Range requests, and never accepts an arbitrary upstream URL from the client. The included session registry is process-local and bounded; use shared ephemeral storage for horizontally scaled deployments.
