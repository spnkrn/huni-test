"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { safeNextPath } from "@/lib/security/redirect";

export function AuthForm({ mode, nextPath }: { mode: "login" | "signup"; nextPath: string }) {
  const destination = safeNextPath(nextPath);
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setMessage("");
    const supabase = createClient();
    const result = mode === "login"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(destination)}` } });
    setBusy(false);
    if (result.error) { setMessage(result.error.message); return; }
    if (mode === "signup" && !result.data.session) {
      setMessage("Check your email to confirm your account, then return to Huni.");
      return;
    }
    router.replace(destination); router.refresh();
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md items-center justify-center">
      <div className="glass w-full rounded-3xl p-7">
        <div className="eyebrow">Huni account</div>
        <h1 className="mt-2 text-3xl font-semibold tracking-[-.05em]">{mode === "login" ? "Welcome back" : "Create your Huni account"}</h1>
        <p className="mt-2 text-sm text-white/45">Your library, playlists and listening history stay tied to your account.</p>
        <form onSubmit={submit} className="mt-7 space-y-4">
          <input className="input" type="email" required autoComplete="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
          <input className="input" type="password" required minLength={6} autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
          {message && <div className="rounded-xl border border-white/10 bg-white/[.04] p-3 text-sm text-white/65">{message}</div>}
          <button disabled={busy} className="w-full rounded-xl bg-white px-4 py-3 text-sm font-medium text-black transition hover:bg-white/90 disabled:opacity-50">{busy ? "Working…" : mode === "login" ? "Sign in" : "Create account"}</button>
        </form>
        <div className="mt-5 text-center text-sm text-white/40">
          {mode === "login" ? <>New to Huni? <Link className="text-white" href="/auth/sign-up">Create an account</Link></> : <>Already have an account? <Link className="text-white" href="/auth/login">Sign in</Link></>}
        </div>
      </div>
    </div>
  );
}
