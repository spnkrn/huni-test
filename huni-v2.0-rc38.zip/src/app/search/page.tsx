"use client";

import { useEffect, useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { TrackRow } from "@/components/music/track-row";
import { AlbumCard } from "@/components/music/album-card";
import { SearchResponse } from "@/lib/types";
import { PodcastCard } from "@/components/podcasts/podcast-card";

export default function SearchPage() {
  const [q, setQ] = useState("");
  const [data, setData] = useState<SearchResponse>({ tracks: [], albums: [], artists: [] });
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"all" | "songs" | "albums" | "artists" | "podcasts">("all");

  useEffect(() => {
    const value = q.trim();
    if (!value) { setData({ tracks: [], albums: [], artists: [], podcasts: [] }); return; }
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(value)}`);
        if (res.ok) setData(await res.json());
      } finally { setLoading(false); }
    }, 350);
    return () => clearTimeout(timer);
  }, [q]);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="eyebrow">Search</div>
      <div className="relative mt-3">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-white/35" size={19} />
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1">{[["all","All"],["songs","Songs"],["albums","Albums"],["artists","Artists"],["podcasts","Podcasts"]].map(([value,label])=><button key={value} onClick={()=>setTab(value as typeof tab)} className={`rounded-full border px-3 py-1.5 text-xs ${tab===value?"border-white/20 bg-white/[.1] text-white":"border-white/10 text-white/40"}`}>{label}</button>)}</div>
      <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Artists, albums, songs…" className="search-input pl-12 text-base" />
      </div>

      {!q && <div className="py-24 text-center text-sm text-white/30">Start typing to search the live catalog.</div>}
      {loading && <div className="py-10 text-sm text-white/35">Searching…</div>}

      {q && !loading && (
        <div className="mt-10 space-y-14">
          {(tab === "all" || tab === "songs") && data.tracks.length > 0 && <section><SectionTitle label="Songs" /><div>{data.tracks.slice(0, 12).map((t, i) => <TrackRow key={t.id} track={t} index={i + 1} />)}</div></section>}
          {(tab === "all" || tab === "albums") && data.albums.length > 0 && <section><SectionTitle label="Albums" /><div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">{data.albums.slice(0, 12).map(a => <AlbumCard key={a.id} album={a} />)}</div></section>}
          {(tab === "all" || tab === "artists") && data.artists.length > 0 && <section><SectionTitle label="Artists" /><div className="grid gap-2 sm:grid-cols-2">{data.artists.slice(0, 10).map(a => <a href={`/artist/${a.id}`} key={a.id} className="glass rounded-xl p-4 text-sm transition hover:bg-white/[.08]">{a.name}<div className="mt-1 text-xs text-white/35">{a.country ?? "Artist"}</div></a>)}</div></section>}
          {(tab === "all" || tab === "podcasts") && (data.podcasts?.length ?? 0) > 0 && <section><SectionTitle label="Podcasts" /><div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-5">{data.podcasts!.slice(0, 10).map(p => <PodcastCard key={p.id} podcast={p} />)}</div></section>}
          {!data.tracks.length && !data.albums.length && !data.artists.length && !(data.podcasts?.length ?? 0) && <div className="glass rounded-2xl p-12 text-center text-sm text-white/35">No results. Try a different search.</div>}
        </div>
      )}
    </div>
  );
}

function SectionTitle({ label }: { label: string }) {
  return <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-semibold">{label}</h2><span className="eyebrow">Live</span></div>;
}