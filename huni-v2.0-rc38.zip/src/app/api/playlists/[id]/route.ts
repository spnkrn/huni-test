import { NextResponse } from "next/server";
import { jsonError, withApiHeaders } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { id } = await params;
  if (!id || id.length > 128) return jsonError(request, "Invalid playlist id", 400);
  const { data: playlist, error } = await supabase.from("playlists").select("id,name,description,artwork_url").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (error) return jsonError(request, "Request could not be completed", 400);
  if (!playlist) return jsonError(request, "Playlist not found", 404);
  const tracks = await supabase.from("playlist_tracks").select("track,position").eq("playlist_id", id).order("position", { ascending: true });
  if (tracks.error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ playlist, tracks: (tracks.data ?? []).map(row => row.track) }, { headers: withApiHeaders(request) });
}
