import type { Track } from "@/lib/types";
import type { Podcast } from "@/lib/podcast-types";

export type LocalPlaylist = { id: string; name: string; description: string | null; artwork_url: string | null; updated_at: string; tracks: Track[] };
export type LocalProgress = { track: Track; positionSeconds: number; durationSeconds: number; updatedAt: string; completed: boolean };

type LocalState = {
  version: 2;
  favorites: Track[];
  library: Track[];
  playlists: LocalPlaylist[];
  history: Array<{ track: Track; playedAt: string; positionSeconds?: number; completed?: boolean }>;
  progress: Record<string, LocalProgress>;
  followedPodcasts: Podcast[];
};

const KEY = "huni-local-store-v2";
const empty = (): LocalState => ({ version: 2, favorites: [], library: [], playlists: [], history: [], progress: {}, followedPodcasts: [] });

function read(): LocalState {
  if (typeof window === "undefined") return empty();
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) { const parsed = JSON.parse(raw); if (parsed?.version === 2) return { ...empty(), ...parsed }; }
    const legacy = JSON.parse(localStorage.getItem("huni-local-store-v1") ?? "null");
    if (legacy?.version === 1) return { ...empty(), ...legacy } as LocalState;
    return empty();
  } catch { return empty(); }
}
function write(state: LocalState) { localStorage.setItem(KEY, JSON.stringify(state)); window.dispatchEvent(new CustomEvent("huni-local-store")); }
const upsert = <T extends { id: string }>(items: T[], item: T) => [item, ...items.filter(x => x.id !== item.id)];
const remove = <T extends { id: string }>(items: T[], id: string) => items.filter(x => x.id !== id);

export const localStore = {
  snapshot: read,
  toggleFavorite(track: Track) { const s = read(); const exists = s.favorites.some(x => x.id === track.id); s.favorites = exists ? remove(s.favorites, track.id) : upsert(s.favorites, track); write(s); return !exists; },
  isFavorite(id: string) { return read().favorites.some(x => x.id === id); },
  toggleLibrary(track: Track) { const s = read(); const exists = s.library.some(x => x.id === track.id); s.library = exists ? remove(s.library, track.id) : upsert(s.library, track); write(s); return !exists; },
  isSaved(id: string) { return read().library.some(x => x.id === id); },
  createPlaylist(name: string, description: string | null = null) { const now = new Date().toISOString(); const playlist: LocalPlaylist = { id: `local-${crypto.randomUUID()}`, name: name.trim(), description, artwork_url: null, updated_at: now, tracks: [] }; const s = read(); s.playlists = [playlist, ...s.playlists]; write(s); return playlist; },
  addToPlaylist(id: string, track: Track) { const s = read(); const p = s.playlists.find(x => x.id === id); if (!p) return false; p.tracks = [track, ...p.tracks.filter(x => x.id !== track.id)]; p.updated_at = new Date().toISOString(); write(s); return true; },
  removeFromPlaylist(id: string, trackId: string) { const s = read(); const p = s.playlists.find(x => x.id === id); if (!p) return; p.tracks = remove(p.tracks, trackId); p.updated_at = new Date().toISOString(); write(s); },
  reorderPlaylist(id: string, orderedIds: string[]) { const s = read(); const p = s.playlists.find(x => x.id === id); if (!p) return; const map = new Map(p.tracks.map(x => [x.id, x])); p.tracks = orderedIds.map(x => map.get(x)).filter((x): x is Track => Boolean(x)); p.updated_at = new Date().toISOString(); write(s); },
  getPlaylist(id: string) { return read().playlists.find(x => x.id === id) ?? null; },
  deletePlaylist(id: string) { const s = read(); s.playlists = s.playlists.filter(x => x.id !== id); write(s); },
  toggleFollowPodcast(podcast: Podcast) { const s = read(); const exists = s.followedPodcasts.some(x => x.id === podcast.id); s.followedPodcasts = exists ? remove(s.followedPodcasts, podcast.id) : upsert(s.followedPodcasts, podcast); write(s); return !exists; },
  setFollowedPodcasts(podcasts: Podcast[]) { const s = read(); s.followedPodcasts = [...new Map(podcasts.map(p => [p.id, p])).values()]; write(s); },
  isFollowingPodcast(id: string) { return read().followedPodcasts.some(x => x.id === id); },
  recordHistory(track: Track, positionSeconds = 0, completed = false) { const s = read(); s.history = [{ track, playedAt: new Date().toISOString(), positionSeconds, completed }, ...s.history.filter(x => x.track.id !== track.id)].slice(0, 200); write(s); },
  recentHistory(limit = 20) { return read().history.slice(0, limit); },
  recentProgress(limit = 20) { return Object.values(read().progress).sort((a,b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit); },
  saveProgress(track: Track, positionSeconds: number, durationSeconds: number, completed = false) { const s = read(); s.progress[track.id] = { track, positionSeconds, durationSeconds, completed, updatedAt: new Date().toISOString() }; write(s); },
  clear() { localStorage.removeItem(KEY); localStorage.removeItem("huni-local-store-v1"); window.dispatchEvent(new CustomEvent("huni-local-store")); }
};
