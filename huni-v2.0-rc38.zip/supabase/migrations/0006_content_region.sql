-- v2.0 RC23: user-controlled content region for localized charts/metadata.
alter table public.profiles add column if not exists content_region text;
update public.profiles set content_region = upper(coalesce(content_region, current_setting('app.default_region', true), 'US')) where content_region is null;
alter table public.profiles drop constraint if exists profiles_content_region_format;
alter table public.profiles add constraint profiles_content_region_format check (content_region is null or content_region ~ '^[A-Z]{2}$');
