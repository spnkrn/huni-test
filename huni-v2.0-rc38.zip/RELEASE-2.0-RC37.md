# Huni 2.0 RC37

## Recently Played + unified discovery

- Added a local-first Recently Played surface to Home for anonymous and signed-in users.
- Recent music and podcast playback now appears chronologically from the local history store.
- Added offline badges to shared track rows when media is stored in IndexedDB.
- Local followed podcasts are now included in anonymous-to-account synchronization.
- Preserved the existing Supabase history/progress flow for authenticated users.
- Kept music and podcast playback unified through the existing player and offline store.

## Validation

Static and security checks should be run in an environment with project dependencies installed before final production certification.
