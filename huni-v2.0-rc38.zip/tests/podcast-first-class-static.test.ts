import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const row = readFileSync("src/components/music/track-row.tsx", "utf8");
const queue = readFileSync("src/components/player/queue-drawer.tsx", "utf8");
const mini = readFileSync("src/components/player/mini-player.tsx", "utf8");
const player = readFileSync("src/app/player/[id]/page.tsx", "utf8");
const converter = readFileSync("src/lib/podcast-player.ts", "utf8");

describe("podcast first-class playback", () => {
  it("routes podcast items to podcast pages from shared track surfaces", () => {
    expect(row).toContain('track.mediaType === "podcast"');
    expect(row).toContain("/podcast/");
    expect(queue).toContain('item.mediaType === "podcast"');
    expect(mini).toContain('track.mediaType === "podcast"');
  });

  it("preserves Apple identity on podcast episode tracks", () => {
    expect(converter).toContain("providerIds: { itunes: episode.appleUrl }");
  });

  it("offers multiple sleep timer presets in the shared player", () => {
    expect(player).toContain("sleepOptions");
    expect(player).toContain("15, 30, 45, 60, 90");
    expect(player).toContain('setSleepTimer(0)');
  });
});
