"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { PodcastCard } from "@/components/podcasts/podcast-card";
import { PodcastEpisodeRow } from "@/components/podcasts/podcast-episode-row";
import type { Podcast, PodcastEpisode } from "@/lib/podcast-types";
import { PodcastContinueListening } from "@/components/podcasts/podcast-continue-listening";

export default function PodcastsPage() {
  const [podcasts, setPodcasts] = useState<Podcast[]>([]); const [channels, setChannels] = useState<Podcast[]>([]); const [episodes, setEpisodes] = useState<PodcastEpisode[]>([]); const [q, setQ] = useState(""); const [results, setResults] = useState<Podcast[]>([]); const [loading, setLoading] = useState(true);
  useEffect(() => { fetch("/api/podcasts/charts?limit=10").then(r => r.ok ? r.json() : null).then(d => { if (d) { setPodcasts(d.podcasts ?? []); setChannels(d.channels ?? []); setEpisodes(d.episodes ?? []); } }).finally(() => setLoading(false)); }, []);
  useEffect(() => { const value=q.trim(); if(!value){setResults([]);return;} const t=setTimeout(()=>fetch(`/api/podcasts?q=${encodeURIComponent(value)}`).then(r=>r.ok?r.json():null).then(d=>setResults(d?.podcasts??[])),300); return()=>clearTimeout(t); },[q]);
  return <div className="mx-auto max-w-7xl">
    <header><div className="eyebrow">Huni / Podcasts</div><h1 className="mt-2 text-4xl font-semibold tracking-[-0.055em] md:text-6xl">Podcasts, without the noise.</h1><p className="mt-4 max-w-2xl text-sm leading-6 text-white/45">Apple Podcasts discovery, publisher RSS audio, and the same queue and player experience as music.</p></header>
    <PodcastContinueListening />
    <div className="relative mt-8 max-w-2xl"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/35" size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search podcasts…" className="search-input pl-11" /></div>
    {q ? <section className="mt-10"><div className="mb-5 flex items-end justify-between"><div><div className="eyebrow">Apple / iTunes</div><h2 className="mt-1 text-xl font-semibold">Podcast search</h2></div><Link href="/search" className="text-xs text-white/40">Search everything</Link></div>{results.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{results.map(p=><PodcastCard key={p.id} podcast={p}/>)}</div> : <div className="glass rounded-2xl p-10 text-center text-sm text-white/35">No podcasts found.</div>}</section> : null}
    {!q && <>{loading ? <div className="py-16 text-sm text-white/35">Loading podcast charts…</div> : <>
      <section className="mt-14"><Heading eyebrow="Apple Podcasts" title="Top podcasts" /><div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{podcasts.map(p=><PodcastCard key={p.id} podcast={p}/>)}</div></section>
      <section className="mt-16"><Heading eyebrow="Apple Podcasts" title="Top podcast channels" /><div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{channels.map(p=><PodcastCard key={p.id} podcast={p}/>)}</div></section>
      <section className="mt-16"><Heading eyebrow="Discovery" title="Top episodes from charted shows" trailing="RSS / iTunes" /><div className="glass overflow-hidden rounded-2xl px-2 py-1">{episodes.map((e,i)=><PodcastEpisodeRow key={e.id} episode={e} podcastTitle={podcasts.find(p=>p.id===e.podcastId)?.title ?? e.podcastId} author={e.author} index={i+1}/>)}</div></section>
    </>}</>}
  </div>;
}
function Heading({eyebrow,title,trailing}:{eyebrow:string;title:string;trailing?:string}){return <div className="mb-5 flex items-end justify-between gap-4"><div><div className="eyebrow">{eyebrow}</div><h2 className="mt-1 text-xl font-semibold">{title}</h2></div>{trailing?<span className="text-xs text-white/30">{trailing}</span>:null}</div>}
