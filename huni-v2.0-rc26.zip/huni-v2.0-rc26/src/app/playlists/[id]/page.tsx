"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, GripVertical, Trash2 } from "lucide-react";
import { Track } from "@/lib/types";
import { TrackRow } from "@/components/music/track-row";
import { PlaylistPlayerControls } from "./playlist-player-controls";
import { usePlayer } from "@/components/player/player-context";

type Playlist = { id: string; name: string; description: string | null; artwork_url: string | null };

export default function PlaylistPage({ params }: { params: Promise<{ id: string }> }) {
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [error, setError] = useState("");
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [savingOrder, setSavingOrder] = useState(false);
  const { queue, moveInQueue, removeFromQueue } = usePlayer();

  useEffect(() => {
    params.then(({ id }) => fetch(`/api/playlists/${id}`).then(async r => {
      const body = await r.json();
      if (!r.ok) throw new Error(body.error ?? "Playlist unavailable");
      setPlaylist(body.playlist); setTracks(body.tracks ?? []);
    }).catch(e => setError(e.message)));
  }, [params]);

  async function remove(trackId: string) {
    if (!playlist) return;
    const removedIndex = tracks.findIndex((track) => track.id === trackId);
    const res = await fetch(`/api/playlists/${playlist.id}/tracks?trackId=${encodeURIComponent(trackId)}`, { method: "DELETE" });
    if (!res.ok) return;
    setTracks(items => items.filter(t => t.id !== trackId));
    const activePlaylist = queue.length === tracks.length && queue.every((track, i) => track.id === tracks[i]?.id);
    if (activePlaylist) removeFromQueue(trackId);
  }

  async function reorder(fromIndex: number, toIndex: number) {
    if (!playlist || fromIndex === toIndex || savingOrder) return;
    const next = [...tracks];
    const [moved] = next.splice(fromIndex, 1);
    next.splice(toIndex, 0, moved);
    setTracks(next);
    const activePlaylist = queue.length === tracks.length && queue.every((track, i) => track.id === tracks[i]?.id);
    if (activePlaylist) moveInQueue(fromIndex, toIndex);
    setSavingOrder(true);
    try {
      const res = await fetch(`/api/playlists/${playlist.id}/tracks`, {
        method: "PATCH", headers: { "content-type": "application/json" },
        body: JSON.stringify({ orderedTrackIds: next.map((track) => track.id) }),
      });
      if (!res.ok) throw new Error();
    } catch {
      setTracks(tracks);
    } finally { setSavingOrder(false); }
  }

  if (error) return <div className="glass mx-auto mt-20 max-w-xl rounded-2xl p-10 text-center text-sm text-white/45">{error}</div>;
  if (!playlist) return <div className="py-24 text-center text-sm text-white/35">Loading playlist…</div>;

  return <div className="mx-auto max-w-6xl">
    <Link href="/playlists" className="mb-8 inline-flex items-center gap-2 text-xs text-white/40 hover:text-white"><ArrowLeft size={15}/> Playlists</Link>
    <section className="grid gap-7 md:grid-cols-[220px_1fr] md:items-end">
      <div className="relative aspect-square overflow-hidden rounded-[24px] border border-white/10 bg-white/5">
        {playlist.artwork_url && <Image src={playlist.artwork_url} alt="" fill sizes="220px" className="object-cover"/>}
      </div>
      <div><div className="eyebrow">Playlist</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em] md:text-6xl">{playlist.name}</h1><p className="mt-3 text-sm text-white/45">{playlist.description || "A private Huni playlist."}</p><PlaylistPlayerControls tracks={tracks} /></div>
    </section>
    <section className="mt-12">{tracks.length ? tracks.map((track, i) => <div key={track.id} draggable onDragStart={() => setDraggedIndex(i)} onDragOver={(event) => event.preventDefault()} onDrop={() => { if (draggedIndex !== null) void reorder(draggedIndex, i); setDraggedIndex(null); }} onDragEnd={() => setDraggedIndex(null)} className={`group relative rounded-2xl ${draggedIndex === i ? "opacity-40" : ""}`}><div className="absolute left-1 top-1/2 z-10 -translate-y-1/2 cursor-grab p-2 text-white/25" aria-label="Drag to reorder"><GripVertical size={15}/></div><TrackRow track={track} index={i + 1}/><button aria-label="Remove from playlist" title="Remove from playlist" onClick={() => void remove(track.id)} className="absolute right-14 top-1/2 -translate-y-1/2 opacity-0 transition group-hover:opacity-60 hover:!opacity-100"><Trash2 size={15}/></button></div>) : <div className="glass rounded-2xl p-12 text-center text-sm text-white/35">This playlist is empty. Add tracks from search, albums, or the song page.</div>}{savingOrder && <p className="mt-3 text-xs text-white/30">Saving order…</p>}</section>
  </div>;
}
