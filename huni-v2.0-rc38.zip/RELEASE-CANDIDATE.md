# Huni 1.5 Release Candidate

## Required production gates

- [ ] `npm ci` succeeds from the lockfile.
- [ ] `npm run typecheck` succeeds.
- [ ] `npm test` succeeds.
- [ ] `npm run test:security` succeeds.
- [ ] `npm run build` succeeds.
- [ ] `npm run verify:env` succeeds with production variables.
- [ ] Supabase migrations have been applied in order.
- [ ] RLS is enabled on every user-owned table.
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is never exposed to the browser.
- [ ] `PLAYBACK_SESSION_SECRET` is a high-entropy production secret.
- [ ] `HUNI_ADMIN_USER_IDS` contains only intended administrators.
- [ ] Any authorized audio provider has supplied legitimate credentials and terms permitting Huni's intended use.
- [ ] Provider credentials are stored only in deployment secrets.
- [ ] Rate limiting uses a shared store for multi-instance production deployments.
- [ ] Error monitoring is configured without collecting access tokens, cookies, provider secrets, or raw signed URLs.
- [ ] Auth redirect URLs are restricted to the Huni application origin.
- [ ] Service-worker caching has been smoke-tested without caching private API responses.

## Smoke test

1. Create a new account.
2. Confirm the email if confirmation is enabled.
3. Search for a real artist and album.
4. Open a real track.
5. Save and remove it from Library.
6. Create a playlist and add/remove a track.
7. Verify history only changes after actual playback starts.
8. Sign out and verify protected routes redirect to login.
9. Verify an ordinary user cannot access `/admin`.
10. Verify an admin can access `/admin`.
11. Verify playback is unavailable when no authorized provider is configured.
12. If an authorized provider is configured, verify session expiry and renewal.
13. Install the PWA and test offline shell behavior.

## Release rule

Do not call Huni production-ready until every required production gate is checked. A missing licensed audio provider is a product capability limitation, not a reason to fabricate playback.
