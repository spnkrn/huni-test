import { describe, expect, it } from "vitest";

function parseLrc(lrc: string) {
  return lrc.split(/\r?\n/).flatMap(raw => {
    const matches = [...raw.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
    const text = raw.replace(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g, "").trim();
    return matches.map(m => ({
      timeMs: Number(m[1]) * 60000 + Number(m[2]) * 1000 + (m[3] ? Number(m[3]) * (m[3].length === 3 ? 1 : 10) : 0),
      text
    }));
  });
}

it("parses LRC timestamps", () => {
  expect(parseLrc("[01:02.50]Hello")[0]).toEqual({ timeMs: 62500, text: "Hello" });
});