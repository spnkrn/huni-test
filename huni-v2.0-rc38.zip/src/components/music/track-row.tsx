"use client";

import Image from "next/image";
import Link from "next/link";
import { Play } from "lucide-react";
import { TrackActions } from "@/components/music/track-actions";
import { Track } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";
import { formatDuration } from "@/lib/utils";
import { DownloadStatusBadge } from "@/components/music/download-status-badge";

export function TrackRow({ track, index }: { track: Track; index?: number }) {
  const { play } = usePlayer();
  const art = track.artwork?.medium;
  const isPodcast = track.mediaType === "podcast";
  const detailHref = isPodcast && track.podcastId ? `/podcast/${track.podcastId.replace(/^podcast-/, "")}` : `/song/${track.id}`;
  return (
    <div className="track-row group">
      <div className="w-8 text-center text-xs text-white/30">{index ?? ""}</div>
      <div className="relative size-11 overflow-hidden rounded-[9px] bg-white/5">
        {art ? <Image src={art} alt="" fill sizes="44px" className="object-cover" /> : null}
        <button onClick={() => play(track)} className="absolute inset-0 hidden place-items-center bg-black/55 group-hover:grid">
          <Play size={16} fill="currentColor" />
        </button>
      </div>
      <div className="min-w-0 flex-1">
        <Link href={detailHref} className="block truncate text-sm font-medium hover:underline">{track.title}</Link>
        <div className="flex min-w-0 items-center gap-2 truncate text-xs text-white/45">
          {isPodcast ? <span className="shrink-0 rounded-full border border-white/10 bg-white/[.04] px-1.5 py-0.5 text-[9px] uppercase tracking-[.12em] text-white/40">Podcast</span> : null}
          <span className="truncate">{isPodcast ? (track.podcastTitle ?? track.artists.map(a => a.name).join(", ")) : track.artists.map(a => a.name).join(", ")}</span>
        </div>
      </div>
      <Link href={isPodcast && track.podcastId ? detailHref : track.album ? `/album/${track.album.id}` : "#"} className="hidden max-w-[24%] truncate text-xs text-white/35 hover:text-white md:block">
        {track.album?.title}
      </Link>
      <span className="w-12 text-right text-xs tabular-nums text-white/30">{formatDuration(track.durationMs)}</span>
      <TrackActions track={track} />
    </div>
  );
}