"use client";
import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import { PodcastEpisodeRow } from "@/components/podcasts/podcast-episode-row";
import type { Podcast, PodcastEpisode } from "@/lib/podcast-types";

export default function PodcastPage({ params }: { params: Promise<{ id: string }> }) {
  const [id,setId]=useState(""); const [podcast,setPodcast]=useState<Podcast|null>(null); const [episodes,setEpisodes]=useState<PodcastEpisode[]>([]); const [page,setPage]=useState(1); const [hasMore,setHasMore]=useState(false); const [filter,setFilter]=useState(""); const [loading,setLoading]=useState(true);
  useEffect(()=>{params.then(p=>setId(p.id));},[params]);
  useEffect(()=>{if(!id)return;setLoading(true);fetch(`/api/podcasts/${id}?page=${page}&pageSize=20`).then(r=>r.ok?r.json():null).then(d=>{if(d){setPodcast(d.podcast);setEpisodes(d.episodes??[]);setHasMore(Boolean(d.hasMore));}}).finally(()=>setLoading(false));},[id,page]);
  const filtered=useMemo(()=>{const q=filter.trim().toLowerCase();return q?episodes.filter(e=>`${e.title} ${e.description??""}`.toLowerCase().includes(q)):episodes;},[episodes,filter]);
  if(!podcast&&!loading)return <div className="py-24 text-center text-white/35">Podcast not found.</div>;
  return <div className="mx-auto max-w-6xl">{podcast?<>
    <section className="grid gap-7 md:grid-cols-[220px_1fr] md:items-end"><div className="relative aspect-square overflow-hidden rounded-3xl border border-white/10 bg-white/5">{podcast.artwork?<Image src={podcast.artwork} alt="" fill sizes="220px" className="object-cover"/>:null}</div><div><div className="eyebrow">Podcast channel</div><h1 className="mt-2 text-4xl font-semibold tracking-tight md:text-5xl">{podcast.title}</h1><div className="mt-2 text-sm text-white/50">{podcast.author}</div>{podcast.genre?.length?<div className="mt-4 text-xs text-white/35">{podcast.genre.join(" · ")}</div>:null}</div></section>
    <section className="mt-14"><div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><div className="eyebrow">Episodes</div><h2 className="mt-1 text-xl font-semibold">Latest episodes</h2></div><div className="relative w-full sm:max-w-sm"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" size={16}/><input value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Filter episodes…" className="search-input pl-9"/></div></div>
    {loading?<div className="py-12 text-sm text-white/35">Loading episodes…</div>:filtered.length?<div className="mt-4 glass overflow-hidden rounded-2xl px-2 py-1">{filtered.map((e,i)=><PodcastEpisodeRow key={e.id} episode={e} podcastTitle={podcast.title} author={podcast.author} index={(page-1)*20+i+1}/>)}</div>:<div className="mt-4 glass rounded-2xl p-10 text-center text-sm text-white/35">No matching episodes on this page.</div>}
    <div className="mt-5 flex items-center justify-between"><button className="icon-button disabled:opacity-30" disabled={page===1||loading} onClick={()=>setPage(p=>Math.max(1,p-1))} aria-label="Previous page"><ChevronLeft/></button><span className="text-xs text-white/35">Page {page}</span><button className="icon-button disabled:opacity-30" disabled={!hasMore||loading} onClick={()=>setPage(p=>p+1)} aria-label="Next page"><ChevronRight/></button></div></section>
  </>:<div className="py-24 text-center text-white/35">Loading podcast…</div>}</div>;
}
