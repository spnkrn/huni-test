# ReUI integration

Huni is configured for the current ReUI registry workflow. ReUI is a shadcn-compatible registry and supports React 19 + Tailwind CSS 4. The project keeps the registry namespace in `components.json`:

```json
"registries": {
  "@reui": "https://reui.io/r/{style}/{name}.json"
}
```

Free ReUI examples can be added with:

```bash
npx shadcn@latest add @reui/c-alert-1
```

For Huni, ReUI should be used for application primitives and interactive surfaces where it improves consistency; the music-specific glass/player visual language remains custom so the product does not become a generic component-demo aesthetic.

Premium ReUI blocks require a ReUI account/license. Do not commit `REUI_LICENSE_KEY`.
