"use client";

import { ListMusic, Shuffle } from "lucide-react";
import { Track } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";

export function LibraryControls({ tracks }: { tracks: Track[] }) {
  const { playTracks } = usePlayer();
  if (!tracks.length) return null;
  return (
    <div className="mt-6 flex flex-wrap gap-2">
      <button
        type="button"
        onClick={() => playTracks(tracks, 0, false)}
        className="button-primary"
      >
        <ListMusic size={16} />
        Play all
      </button>
      <button
        type="button"
        onClick={() => playTracks(tracks, 0, true)}
        className="button-secondary"
      >
        <Shuffle size={16} />
        Shuffle library
      </button>
    </div>
  );
}
