import { NextRequest, NextResponse } from "next/server";
import { withApiHeaders } from "@/lib/security/api";
import { getUserContentRegion } from "@/lib/region";
import { lookupPodcastWithEpisodes, lookupPodcast, fetchPodcastRss } from "@/lib/providers/podcasts";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const headers = withApiHeaders(req);
  const { id } = await params;
  const page = Math.max(1, Number(req.nextUrl.searchParams.get("page") ?? "1") || 1);
  const pageSize = Math.min(50, Math.max(5, Number(req.nextUrl.searchParams.get("pageSize") ?? "20") || 20));
  const country = (await getUserContentRegion()).region;
  try {
    const podcast = await lookupPodcast(id, country);
    if (!podcast) return NextResponse.json({ error: "Podcast not found" }, { status: 404, headers });
    try {
      const rss = await fetchPodcastRss(podcast, page, pageSize);
      return NextResponse.json(rss, { headers });
    } catch {
      const fallback = await lookupPodcastWithEpisodes(id, country, 100);
      if (!fallback) return NextResponse.json({ error: "Podcast episodes unavailable" }, { status: 502, headers });
      const start = (page - 1) * pageSize;
      return NextResponse.json({ ...fallback, episodes: fallback.episodes.slice(start, start + pageSize), total: fallback.episodes.length, hasMore: start + pageSize < fallback.episodes.length, source: "itunes-fallback" }, { headers });
    }
  } catch { return NextResponse.json({ error: "Podcast unavailable" }, { status: 502, headers }); }
}
