import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-xl items-center justify-center text-center">
      <div className="glass rounded-3xl p-8">
        <div className="eyebrow">404</div>
        <h1 className="mt-3 text-2xl font-semibold">That page isn't in the catalog.</h1>
        <p className="mt-3 text-sm text-white/45">The link may be stale, or the item may no longer exist.</p>
        <Link href="/" className="mt-6 inline-flex rounded-xl bg-white px-4 py-2 text-sm font-medium text-black hover:bg-white/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70">Back home</Link>
      </div>
    </div>
  );
}
