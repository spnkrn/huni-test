const required = [
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY",
  "SUPABASE_SECRET_KEY",
  "PLAYBACK_SESSION_SECRET",
  "PLAYBACK_ENCRYPTION_KEY",
];

const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(", ")}`);
  process.exit(1);
}

if (process.env.PLAYBACK_SESSION_SECRET.length < 32) {
  console.error("PLAYBACK_SESSION_SECRET must contain at least 32 characters.");
  process.exit(1);
}

if (process.env.PLAYBACK_ENCRYPTION_KEY.length < 32) {
  console.error("PLAYBACK_ENCRYPTION_KEY must contain at least 32 characters.");
  process.exit(1);
}

const audioEnabled = process.env.QOBUZ_ENABLED === "true" || process.env.HUNI_AUDIO_PROVIDER_ENABLED === "true";
if (audioEnabled) {
  const audioRequired = [
    "HUNI_AUDIO_PROVIDER_GATEWAY_URL",
    "HUNI_AUDIO_PROVIDER_ALLOWED_HOSTS",
  ];
  const audioMissing = audioRequired.filter((key) => !process.env[key]);
  if (audioMissing.length) {
    console.error(`Audio provider is enabled but missing: ${audioMissing.join(", ")}`);
    process.exit(1);
  }
}

console.log("Huni environment configuration looks structurally valid.");
