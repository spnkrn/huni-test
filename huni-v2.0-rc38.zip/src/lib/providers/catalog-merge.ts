import type { Album, Artist, SearchResponse, Track } from "@/lib/types";
import { normalizeMusicText } from "@/lib/matching";

function artistKey(artist: Artist) {
  return normalizeMusicText(artist.name);
}

function trackKey(track: Track) {
  const artist = track.artists[0]?.name ?? "";
  const album = track.album?.title ?? "";
  return `${normalizeMusicText(artist)}|${normalizeMusicText(track.title)}|${normalizeMusicText(album)}`;
}

function albumKey(album: Album) {
  return `${normalizeMusicText(album.artist.name)}|${normalizeMusicText(album.title)}`;
}

/**
 * Merge normalized provider results without creating duplicate catalog rows.
 * The first provider wins, so callers can deliberately establish precedence
 * (for example Qobuz before iTunes) while still retaining missing providers.
 */
export function mergeSearchResults(...sources: Array<SearchResponse | null | undefined>): SearchResponse {
  const tracks = new Map<string, Track>();
  const albums = new Map<string, Album>();
  const artists = new Map<string, Artist>();

  for (const source of sources) {
    if (!source) continue;
    for (const track of source.tracks ?? []) tracks.set(trackKey(track), mergeTrack(tracks.get(trackKey(track)), track));
    for (const album of source.albums ?? []) albums.set(albumKey(album), mergeAlbum(albums.get(albumKey(album)), album));
    for (const artist of source.artists ?? []) artists.set(artistKey(artist), mergeArtist(artists.get(artistKey(artist)), artist));
  }

  return { tracks: [...tracks.values()], albums: [...albums.values()], artists: [...artists.values()] };
}

function mergeArtist(existing: Artist | undefined, incoming: Artist) {
  if (!existing) return incoming;
  return {
    ...incoming,
    ...existing,
    providerIds: { ...incoming.providerIds, ...existing.providerIds },
    image: existing.image ?? incoming.image,
    country: existing.country ?? incoming.country,
    type: existing.type ?? incoming.type,
    musicbrainzId: existing.musicbrainzId ?? incoming.musicbrainzId
  };
}

function mergeAlbum(existing: Album | undefined, incoming: Album) {
  if (!existing) return incoming;
  return {
    ...incoming,
    ...existing,
    providerIds: { ...incoming.providerIds, ...existing.providerIds },
    artwork: existing.artwork ?? incoming.artwork,
    releaseDate: existing.releaseDate ?? incoming.releaseDate,
    genre: existing.genre?.length ? existing.genre : incoming.genre,
    trackCount: existing.trackCount ?? incoming.trackCount,
    tracks: existing.tracks?.length ? existing.tracks : incoming.tracks,
    artist: mergeArtist(existing.artist, incoming.artist)
  };
}

function mergeTrack(existing: Track | undefined, incoming: Track) {
  if (!existing) return incoming;
  return {
    ...incoming,
    ...existing,
    providerIds: { ...incoming.providerIds, ...existing.providerIds },
    artwork: existing.artwork ?? incoming.artwork,
    album: existing.album ?? incoming.album,
    durationMs: existing.durationMs ?? incoming.durationMs,
    trackNumber: existing.trackNumber ?? incoming.trackNumber,
    discNumber: existing.discNumber ?? incoming.discNumber,
    releaseDate: existing.releaseDate ?? incoming.releaseDate,
    genre: existing.genre?.length ? existing.genre : incoming.genre,
    label: existing.label ?? incoming.label,
    isrc: existing.isrc ?? incoming.isrc,
    previewUrl: existing.previewUrl ?? incoming.previewUrl,
    artists: existing.artists.length ? existing.artists : incoming.artists
  };
}
