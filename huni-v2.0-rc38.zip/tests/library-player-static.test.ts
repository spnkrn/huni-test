import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.cwd());

describe("library/player integration static checks", () => {
  it("exposes a library batch-play action", () => {
    const context = fs.readFileSync(path.join(root, "src/components/player/player-context.tsx"), "utf8");
    const controls = fs.readFileSync(path.join(root, "src/app/library/library-controls.tsx"), "utf8");
    expect(context).toContain("playTracks: (tracks: Track[], startIndex?: number, shuffle?: boolean) => void;");
    expect(context).toContain("const playTracks = (tracks: Track[], startIndex = 0, shouldShuffle = false)");
    expect(controls).toContain("playTracks(tracks, 0, false)");
    expect(controls).toContain("playTracks(tracks, 0, true)");
  });

  it("replaces the active queue before starting a library batch", () => {
    const context = fs.readFileSync(path.join(root, "src/components/player/player-context.tsx"), "utf8");
    expect(context).toContain("setQueue(validTracks);");
    expect(context).toContain("setIndex(safeStart);");
    expect(context).toContain("sessionRequestRef.current?.abort();");
    expect(context).toContain("sessionRef.current = null;");
  });
});
