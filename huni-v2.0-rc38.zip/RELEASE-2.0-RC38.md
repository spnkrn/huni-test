# Huni 2.0 RC38 — Subscriptions & Intelligent Continue Listening

- Clarifies podcast subscriptions as free follows, not paid billing.
- Added authenticated GET for followed podcasts.
- Hydrates followed podcasts into the local-first library state.
- Preserves anonymous local state on sign-out instead of clearing it.
- Added unified Continue Listening across music and podcasts using local progress with authenticated server progress merged in.
- Added Followed Podcasts to Home when follows exist.
- Continue Listening exposes offline availability badges.
- Podcast Continue Listening now falls back to local progress for anonymous users and merges remote/local progress.

## Verification
- Static QA and security audit run after RC38 changes.
- Full dependency-backed build/typecheck remains unverified unless dependencies are installed.
