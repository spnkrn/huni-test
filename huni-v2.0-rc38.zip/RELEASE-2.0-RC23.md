# Huni 2.0 RC23 — Regional charts + multi-provider catalog metadata

## Added

- Home now resolves a user content region and uses it for discovery.
- Apple Music RSS charts are live and regional: most-played albums (25) and most-played songs (10).
- Added Apple Music “What’s new & trending” and “Most-played songs” home sections.
- Added optional authorized Qobuz metadata integration for home discovery, search/detail payloads, artist pages, album pages, and song pages.
- Qobuz home supports normalized new releases, most-streamed albums, bestsellers, and tracks through `QOBUZ_METADATA_GATEWAY_URL`.
- Artist/album/song API routes now understand Qobuz IDs as well as iTunes IDs.
- Added user Content region setting persisted in Supabase `profiles.content_region`.
- Region is passed to Apple Music/iTunes and the authorized Qobuz metadata integration.
- Added security guards for the region mutation endpoint.

## Data provenance

Before RC23, the Home page's public discovery data was sourced from iTunes Search queries (`new music` and `electronic`). RC23 replaces the Home chart surface with Apple Music's official RSS feeds and prefers Qobuz metadata when the authorized metadata gateway is configured, while retaining iTunes as a fallback.

Qobuz credentials and provider-specific API endpoints remain server-side. Huni does not expose Qobuz application secrets to browsers.

## Verification

- Static QA: passed for 18 API route files.
- Security audit: passed for 18 API route files.
- Full TypeScript/Vitest/Next build remains environment-dependent because this workspace still has no package-lock/node_modules and the npm registry was unavailable during the previous certification attempt.
