"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Play, Shuffle, Plus, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { Album } from "@/lib/types";
import { TrackRow } from "@/components/music/track-row";
import { usePlayer } from "@/components/player/player-context";
import { ProviderProvenance } from "@/components/metadata/provider-provenance";

export default function AlbumPage({ params }: { params: Promise<{ id: string }> }) {
  const [album, setAlbum] = useState<Album | null>(null);
  const { play } = usePlayer();

  useEffect(() => {
    params.then(({ id }) => fetch(`/api/album/${id}`).then(r => r.ok ? r.json() : null).then(setAlbum));
  }, [params]);

  if (!album) return <div className="py-24 text-center text-sm text-white/35">Loading album…</div>;

  const art = album.artwork?.large ?? album.artwork?.medium;
  return (
    <div className="mx-auto max-w-6xl">
      <Link href="/search" className="mb-8 inline-flex items-center gap-2 text-xs text-white/40 hover:text-white"><ArrowLeft size={15} /> Back</Link>
      <section className="grid gap-8 md:grid-cols-[300px_1fr] md:items-end">
        <div className="relative aspect-square overflow-hidden rounded-[24px] border border-white/10 bg-white/5 shadow-2xl">
          {art ? <Image src={art} alt="" fill sizes="300px" className="object-cover" priority /> : null}
        </div>
        <div>
          <div className="eyebrow">{album.releaseDate?.slice(0, 4) ?? "Album"}</div>
          <h1 className="mt-2 text-4xl font-semibold tracking-[-.05em] md:text-6xl">{album.title}</h1>
          <div className="mt-3 text-lg text-white/55">{album.artist.name}</div>
          <ProviderProvenance entity={album} />
          <div className="mt-5 flex flex-wrap gap-2 text-xs text-white/35">
            {album.genre?.[0] && <span>{album.genre[0]}</span>} {album.trackCount ? <span>· {album.trackCount} tracks</span> : null}
          </div>
          <div className="mt-7 flex gap-2">
            <button onClick={() => album.tracks?.[0] && play(album.tracks[0])} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-medium text-black"><Play size={16} fill="currentColor" /> Play</button>
            <button className="icon-button"><Shuffle size={17} /></button>
            <button className="icon-button"><Plus size={17} /></button>
          </div>
        </div>
      </section>
      <section className="mt-14">{album.tracks?.map((track, i) => <TrackRow key={track.id} track={track} index={i + 1} />)}</section>
    </div>
  );
}