export const DEFAULT_REGION = (process.env.NEXT_PUBLIC_ITUNES_COUNTRY || "US").toUpperCase();
export const CONTENT_REGIONS = [
  ["US", "United States"], ["GB", "United Kingdom"], ["CA", "Canada"], ["AU", "Australia"],
  ["PH", "Philippines"], ["JP", "Japan"], ["KR", "South Korea"], ["DE", "Germany"],
  ["FR", "France"], ["ES", "Spain"], ["IT", "Italy"], ["BR", "Brazil"], ["MX", "Mexico"],
  ["SG", "Singapore"], ["NZ", "New Zealand"], ["IN", "India"]
] as const;
