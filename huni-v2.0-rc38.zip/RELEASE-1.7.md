# Huni 1.7 — API & Security Hardening

## Scope

This release candidate hardens state-changing API routes and adds a lightweight source-level security audit.

### Added
- Same-origin checks for state-changing API requests when an `Origin` header is present.
- JSON request body size guard on mutation endpoints.
- Consistent private/no-store error responses through the API security helper.
- `npm run audit:security` to detect mutation routes missing same-origin protection and routes without an explicit no-store response path.

### Security boundary
The Origin check is defense-in-depth. Supabase RLS and server-side authentication remain the authorization boundary; the check does not replace them.

### Production note
The included rate limiter is process-local. Multi-instance deployments still need a shared rate-limit store before declaring abuse protection production-complete.
