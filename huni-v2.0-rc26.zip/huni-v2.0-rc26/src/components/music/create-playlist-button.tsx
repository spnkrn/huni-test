"use client";

import { useState } from "react";
import { Loader2, Plus } from "lucide-react";

export function CreatePlaylistButton() {
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  async function create() {
    if (!name.trim() || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/playlists", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: name.trim() }) });
      if (res.ok) { setName(""); window.location.reload(); }
    } finally { setBusy(false); }
  }

  return <div className="flex gap-2">
    <input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void create(); }} placeholder="New playlist name" maxLength={100} className="search-input w-48" />
    <button onClick={() => void create()} disabled={busy || !name.trim()} className="icon-button" title="Create playlist" aria-label="Create playlist">{busy ? <Loader2 size={18} className="animate-spin"/> : <Plus size={18}/>}</button>
  </div>;
}
