import { searchITunes } from "@/lib/providers/itunes";
import { getAppleMostPlayed } from "@/lib/providers/apple-rss";
import { qobuzMetadata } from "@/lib/providers/qobuz-metadata";
import { getUserContentRegion } from "@/lib/region";
import { AlbumCard } from "@/components/music/album-card";
import { TrackRow } from "@/components/music/track-row";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { isTrack } from "@/lib/persistence";
import type { Album, Track } from "@/lib/types";
import { getApplePodcastCharts } from "@/lib/providers/podcasts";
import { PodcastCard } from "@/components/podcasts/podcast-card";
import { RecentMedia } from "@/components/library/recent-media";
import { ContinueListening } from "@/components/library/continue-listening";
import { FollowedPodcasts } from "@/components/library/followed-podcasts";
import { LocalLibraryProvider } from "@/components/library/local-library-provider";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { region } = await getUserContentRegion();
  const [apple, qobuz, fallback, podcastCharts] = await Promise.all([
    getAppleMostPlayed(region).catch(() => ({ albums: [], tracks: [], updated: undefined })),
    qobuzMetadata.isConfigured() ? qobuzMetadata.home(region).catch(() => null) : Promise.resolve(null),
    searchITunes("new music", region).catch(() => ({ tracks: [], albums: [], artists: [] })),
    getApplePodcastCharts(region, 10).catch(() => ({ podcasts: [], channels: [], updated: undefined }))
  ]);

  const qobuzAlbums = [...(qobuz?.newReleases ?? []), ...(qobuz?.mostStreamed ?? []), ...(qobuz?.bestsellers ?? [])];
  const albums = uniqueAlbums([...(qobuzAlbums.length ? qobuzAlbums : fallback.albums), ...apple.albums]).slice(0, 12);
  const discoveryTracks = uniqueTracks([...(qobuz?.tracks ?? []), ...apple.tracks, ...fallback.tracks]).slice(0, 10);

  let recentTracks: Track[] = [];
  let libraryTracks: Track[] = [];
  let signedIn = false;
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    signedIn = Boolean(user);
    if (user) [recentTracks, libraryTracks] = await Promise.all([getUserTracks(supabase, "listening_history", user.id), getUserTracks(supabase, "library_tracks", user.id)]);
  } catch {}

  const chartAlbums = apple.albums.slice(0, 10);
  const chartSongs = apple.tracks.slice(0, 10);

  return (
    <div className="mx-auto max-w-7xl">
      <header className="flex items-end justify-between gap-6">
        <div><div className="eyebrow">Huni / Discover · {region}</div><h1 className="mt-2 text-4xl font-semibold tracking-[-0.055em] md:text-6xl">Music, without the noise.</h1><p className="mt-4 max-w-xl text-sm leading-6 text-white/45">Regional charts, high-fidelity catalog metadata, and synchronized lyrics from real music services.</p></div>
        <Link href="/search" className="hidden rounded-xl border border-white/10 bg-white/[.06] px-4 py-2 text-sm hover:bg-white/[.1] md:block">Search music</Link>
      </header>

      <RecentMedia limit={8} />
      <ContinueListening limit={6} />
      <FollowedPodcasts limit={5} />

      {signedIn && recentTracks.length > 0 ? <section className="mt-12 animate-huni"><SectionHeading eyebrow="Your listening" title="Continue listening" actionHref="/library" actionLabel="Open library" /><div className="glass overflow-hidden rounded-2xl px-2 py-1">{recentTracks.slice(0, 5).map((track, i) => <TrackRow key={`${track.id}-${i}`} track={track} index={i + 1} />)}</div></section> : null}
      {signedIn && libraryTracks.length > 0 ? <section className="mt-14 animate-huni"><SectionHeading eyebrow="Your library" title="Saved music" actionHref="/library" actionLabel="See all" /><div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-6">{libraryTracks.slice(0, 6).map(track => track.album ? <AlbumCard key={track.id} album={{ ...track.album, artist: track.artists[0] ?? { id: "unknown", name: "Unknown artist" }, providerIds: {} }} /> : null)}</div></section> : null}

      {qobuzAlbums.length > 0 ? <section className="mt-16"><SectionHeading eyebrow="Qobuz" title="Hi-Res charts & discoveries" trailing="Authorized Qobuz metadata" /><div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-6">{uniqueAlbums(qobuzAlbums).slice(0, 12).map(album => <AlbumCard key={album.id} album={album} />)}</div></section> : null}

      <section className="mt-16"><SectionHeading eyebrow="Apple Music" title="What's new & trending" trailing={`${region} · Apple Music RSS`} />{chartAlbums.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{chartAlbums.map((album, i) => <RankedAlbum key={album.id} album={album} rank={i + 1} />)}</div> : <Empty text="Apple Music charts are temporarily unavailable for this region." />}</section>

      <section className="mt-16"><SectionHeading eyebrow="Apple Podcasts" title="Top podcasts" actionHref="/podcasts" actionLabel="Open Podcasts" />{podcastCharts.podcasts.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{podcastCharts.podcasts.slice(0, 10).map(p => <PodcastCard key={p.id} podcast={p} />)}</div> : <Empty text="Apple Podcasts charts are temporarily unavailable for this region." />}</section>

      <section className="mt-16"><SectionHeading eyebrow="Apple Music" title="Most-played songs" trailing="Regional chart" />{chartSongs.length ? <div className="glass overflow-hidden rounded-2xl px-2 py-1">{chartSongs.map((track, i) => <TrackRow key={track.id} track={track} index={i + 1} />)}</div> : <Empty text="Apple Music song charts are temporarily unavailable for this region." />}</section>

      <section className="mt-16"><SectionHeading eyebrow="Catalog" title="New & notable" trailing={qobuzMetadata.isConfigured() ? "Qobuz + Apple Music metadata" : "Apple Music / iTunes metadata"} />{albums.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-6">{albums.map(album => <AlbumCard key={album.id} album={album} />)}</div> : <Empty text="Catalog data is temporarily unavailable." />}</section>

      {discoveryTracks.length ? <section className="mt-16"><SectionHeading eyebrow="Fresh tracks" title="Play something new" trailing="Real catalog results" /><div className="glass overflow-hidden rounded-2xl px-2 py-1">{discoveryTracks.map((track, i) => <TrackRow key={track.id} track={track} index={i + 1} />)}</div></section> : null}
      <section className="mt-20"><SectionHeading eyebrow="Explore" title="Genres & moods" /><div className="grid grid-cols-2 gap-3 md:grid-cols-4">{["Electronic", "Alternative", "Hip-Hop", "Classical"].map(label => <Link key={label} href={`/search?q=${encodeURIComponent(label)}`} className="glass rounded-2xl p-5 text-sm text-white/70 transition hover:-translate-y-0.5 hover:text-white"><span className="text-base font-medium">{label}</span><span className="mt-10 block text-xs text-white/30">Explore catalog</span></Link>)}</div></section>
    </div>
  );
}

function uniqueAlbums(items: Album[]) { return [...new Map(items.map(a => [a.id, a])).values()]; }
function uniqueTracks(items: Track[]) { return [...new Map(items.map(t => [t.id, t])).values()]; }
function RankedAlbum({ album, rank }: { album: Album; rank: number }) { return <div className="relative"><div className="absolute left-2 top-2 z-10 rounded-full border border-white/10 bg-black/60 px-2 py-1 text-[10px] font-semibold backdrop-blur">#{rank}</div><AlbumCard album={album} /></div>; }

async function getUserTracks(supabase: Awaited<ReturnType<typeof createClient>>, table: "listening_history" | "library_tracks", userId: string): Promise<Track[]> {
  const { data } = await supabase.from(table).select("track, played_at, created_at").eq("user_id", userId).order(table === "listening_history" ? "played_at" : "created_at", { ascending: false }).limit(12);
  const seen = new Set<string>();
  return (data ?? []).flatMap(row => { if (!isTrack(row.track) || seen.has(row.track.id)) return []; seen.add(row.track.id); return [row.track]; });
}
function SectionHeading({ eyebrow, title, trailing, actionHref, actionLabel }: { eyebrow: string; title: string; trailing?: string; actionHref?: string; actionLabel?: string }) { return <div className="mb-5 flex items-end justify-between gap-4"><div><div className="eyebrow">{eyebrow}</div><h2 className="mt-1 text-xl font-semibold">{title}</h2></div>{actionHref ? <Link href={actionHref} className="text-xs text-white/40 hover:text-white">{actionLabel}</Link> : trailing ? <span className="text-xs text-white/30">{trailing}</span> : null}</div>; }
function Empty({ text }: { text: string }) { return <div className="glass rounded-2xl p-10 text-center text-sm text-white/35">{text}</div>; }
