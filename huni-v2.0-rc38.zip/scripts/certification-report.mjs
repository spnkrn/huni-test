import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { execFileSync } from "node:child_process";

const root = process.cwd();
const checks = [];
function check(name, fn) {
  try { fn(); checks.push(["PASS", name]); }
  catch (error) { checks.push(["BLOCKED", `${name}: ${error.message}`]); }
}

check("static API QA", () => execFileSync(process.execPath, [join(root, "scripts/static-qa.mjs")], { stdio: "pipe" }));
check("security audit", () => execFileSync(process.execPath, [join(root, "scripts/security-audit.mjs")], { stdio: "pipe" }));
check("release prerequisites", () => execFileSync(process.execPath, [join(root, "scripts/release-audit.mjs")], { stdio: "pipe" }));
check("package manifest", () => JSON.parse(readFileSync(join(root, "package.json"), "utf8")));
check("ESLint flat config", () => { if (!existsSync(join(root, "eslint.config.mjs"))) throw new Error("eslint.config.mjs missing"); });
check("dependency lockfile", () => { if (!existsSync(join(root, "package-lock.json"))) throw new Error("package-lock.json missing; generate it in a network-enabled environment"); });

console.log("\nHuni 2.0 certification report");
console.log("=".repeat(28));
for (const [status, name] of checks) console.log(`${status.padEnd(8)} ${name}`);
const blocked = checks.filter(([status]) => status === "BLOCKED").length;
console.log(`\n${blocked ? `${blocked} gate(s) blocked.` : "All available release gates passed."}`);
process.exitCode = 0;
