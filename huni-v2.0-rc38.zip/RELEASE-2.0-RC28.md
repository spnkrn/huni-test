# Huni 2.0 RC28 — Podcast Listening Intelligence

- Added podcast-aware listening progress retrieval.
- Added Continue Listening on the Podcasts surface using persisted progress.
- Podcast progress cards resume through the shared Huni player.
- Progress bars and elapsed position are shown for podcast episodes.
- Music progress behavior remains unchanged.
- Added server-side filtering so podcast Continue Listening only returns tracks explicitly marked as podcast media.
- No raw podcast publisher audio URLs are exposed to the client by this feature.

## Verification

Static/security verification should be run in an environment with the project dependencies installed. Full dependency-backed Next.js/TypeScript/Vitest certification remains environment-dependent.
