import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("RC37 unified listening", () => {
  it("has local recent history and offline status surfaces", () => {
    const store = readFileSync("src/lib/local-store.ts", "utf8");
    const recent = readFileSync("src/components/library/recent-media.tsx", "utf8");
    const badge = readFileSync("src/components/music/download-status-badge.tsx", "utf8");
    expect(store).toContain("recentHistory");
    expect(recent).toContain("Recently played");
    expect(recent).toContain("track.mediaType === \"podcast\"");
    expect(badge).toContain("offlineStore.has");
  });
  it("syncs followed podcasts into authenticated accounts", () => {
    const provider = readFileSync("src/components/library/local-library-provider.tsx", "utf8");
    expect(provider).toContain("/api/podcast-follows");
    expect(provider).toContain("s.followedPodcasts");
  });
});
