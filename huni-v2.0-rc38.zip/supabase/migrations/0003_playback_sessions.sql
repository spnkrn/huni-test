-- v2.0 distributed playback sessions. Upstream URLs are encrypted at rest and never exposed to clients.
create table if not exists public.playback_sessions (
  session_id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id text not null,
  provider text not null,
  stream_url_encrypted text not null,
  download_url_encrypted text,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

alter table public.playback_sessions enable row level security;
create policy "playback_sessions_self_select" on public.playback_sessions for select using (auth.uid() = user_id);
create policy "playback_sessions_self_insert" on public.playback_sessions for insert with check (auth.uid() = user_id);
create policy "playback_sessions_self_update" on public.playback_sessions for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "playback_sessions_self_delete" on public.playback_sessions for delete using (auth.uid() = user_id);
create index if not exists playback_sessions_user_expires_idx on public.playback_sessions(user_id, expires_at);
create index if not exists playback_sessions_expires_idx on public.playback_sessions(expires_at);
