export default function Loading() {
  return (
    <div className="mx-auto max-w-7xl" aria-busy="true" aria-live="polite">
      <div className="eyebrow">Huni</div>
      <div className="mt-4 h-10 w-2/3 max-w-xl animate-pulse rounded-xl bg-white/[.06]" />
      <div className="mt-4 h-4 w-full max-w-lg animate-pulse rounded bg-white/[.04]" />
      <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {Array.from({ length: 6 }, (_, i) => <div key={i} className="aspect-square animate-pulse rounded-2xl bg-white/[.045]" />)}
      </div>
      <span className="sr-only">Loading Huni</span>
    </div>
  );
}
