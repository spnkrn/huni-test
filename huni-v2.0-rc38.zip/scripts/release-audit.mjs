import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = ['README.md','ARCHITECTURE.md','SECURITY.md','DEPLOYMENT.md','PROVIDERS.md','SUPABASE.md','REUI.md','.env.example'];
const failures=[];
for (const file of required) if (!fs.existsSync(path.join(root,file))) failures.push(`missing ${file}`);
if (!fs.existsSync(path.join(root,'package-lock.json'))) failures.push('missing package-lock.json (required for npm ci)');
if (!fs.existsSync(path.join(root,'eslint.config.mjs'))) failures.push('missing eslint.config.mjs (required by ESLint 9)');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if (!pkg.engines?.node || !pkg.engines?.npm) failures.push('package.json must pin supported Node/npm ranges');
const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');
for (const key of ['NEXT_PUBLIC_SUPABASE_URL','NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY','PLAYBACK_SESSION_SECRET']) {
  if (!env.includes(key)) failures.push(`.env.example missing ${key}`);
}
if (failures.length) { console.error('Release audit blocked:'); failures.forEach(x=>console.error(`- ${x}`)); process.exit(1); }
console.log('Release audit passed except external build dependencies are not executed by this static gate.');
