import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import type { PlaybackClaims } from "@/lib/playback/token";
import { createAdminClient } from "@/lib/supabase/admin";

export type StoredPlaybackSession = {
  claims: PlaybackClaims;
  streamUrl: string;
  downloadUrl?: string;
  expiresAt: string;
};

function key() {
  const secret = process.env.PLAYBACK_ENCRYPTION_KEY ?? process.env.PLAYBACK_SESSION_SECRET;
  if (!secret || secret.length < 32) throw new Error("PLAYBACK_ENCRYPTION_KEY must be set and contain at least 32 characters.");
  return createHash("sha256").update(`huni-playback-encryption:${secret}`).digest();
}

function encrypt(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64url")}.${tag.toString("base64url")}.${ciphertext.toString("base64url")}`;
}

function decrypt(value: string) {
  const [ivRaw, tagRaw, ciphertextRaw] = value.split(".");
  if (!ivRaw || !tagRaw || !ciphertextRaw) throw new Error("Invalid encrypted playback value.");
  const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(ivRaw, "base64url"));
  decipher.setAuthTag(Buffer.from(tagRaw, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(ciphertextRaw, "base64url")), decipher.final()]).toString("utf8");
}

export async function cleanupExpiredPlaybackSessions(userId: string) {
  const supabase = createAdminClient();
  const { error } = await supabase
    .from("playback_sessions")
    .delete()
    .eq("user_id", userId)
    .lte("expires_at", new Date().toISOString());
  if (error) throw new Error("Unable to clean up expired playback sessions.");
}

export async function storePlaybackSession(session: StoredPlaybackSession) {
  const supabase = createAdminClient();
  const { error } = await supabase.from("playback_sessions").upsert({
    session_id: session.claims.sessionId,
    user_id: session.claims.userId,
    track_id: session.claims.trackId,
    provider: session.claims.provider,
    stream_url_encrypted: encrypt(session.streamUrl),
    download_url_encrypted: session.downloadUrl ? encrypt(session.downloadUrl) : null,
    expires_at: session.expiresAt,
  }, { onConflict: "session_id" });
  if (error) throw new Error("Unable to persist playback session.");

  // Keep the capability store bounded without requiring a privileged cron job.
  // Cleanup is scoped to the authenticated user whose session was just created.
  try {
    await cleanupExpiredPlaybackSessions(session.claims.userId);
  } catch {
    // Expiry is still enforced by getPlaybackSession; cleanup is best-effort.
  }
}

export async function getPlaybackSession(sessionId: string, userId: string) {
  const supabase = createAdminClient();
  const { data, error } = await supabase.from("playback_sessions")
    .select("session_id,user_id,track_id,provider,stream_url_encrypted,download_url_encrypted,expires_at")
    .eq("session_id", sessionId)
    .eq("user_id", userId)
    .gt("expires_at", new Date().toISOString())
    .maybeSingle();
  if (error || !data) return null;
  try {
    return {
      claims: { sessionId: data.session_id, userId: data.user_id, trackId: data.track_id, provider: data.provider, exp: Math.floor(Date.parse(data.expires_at) / 1000) },
      streamUrl: decrypt(data.stream_url_encrypted),
      ...(data.download_url_encrypted ? { downloadUrl: decrypt(data.download_url_encrypted) } : {}),
      expiresAt: data.expires_at,
    } satisfies StoredPlaybackSession;
  } catch {
    return null;
  }
}
