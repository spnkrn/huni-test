import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("podcast RC31", () => {
  it("supports RSS explicit flags and chapters", () => {
    const source = readFileSync("src/lib/providers/podcasts.ts", "utf8");
    expect(source).toContain("parseChapters");
    expect(source).toContain("itunes:explicit");
    expect(source).toContain("chapters: parseChapters(block)");
  });
  it("has an episode detail surface", () => {
    const page = readFileSync("src/app/podcast-episode/[id]/page.tsx", "utf8");
    expect(page).toContain("Show notes");
    expect(page).toContain("Resume episode");
    expect(page).toContain("Chapters");
    expect(page).toContain("Show notes");
  });
  it("routes episode rows to detail pages", () => {
    const row = readFileSync("src/components/podcasts/podcast-episode-row.tsx", "utf8");
    expect(row).toContain("/podcast-episode/");
    expect(row).toContain("Unplayed");
    expect(row).toContain("/podcast-episode/");
  });
});
