import { highResArtwork } from "@/lib/utils";
import { assertSafePodcastUrl } from "@/lib/providers/http";
import type { Podcast, PodcastEpisode, PodcastSearchResponse } from "@/lib/podcast-types";

const ITUNES = "https://itunes.apple.com";
const APPLE_RSS = "https://rss.marketingtools.apple.com/api/v2";

type ITunesPodcastResult = {
  wrapperType?: string; kind?: string; collectionId?: number; trackId?: number;
  collectionName?: string; trackName?: string; artistName?: string; artworkUrl100?: string; artworkUrl600?: string;
  feedUrl?: string; collectionViewUrl?: string; trackViewUrl?: string; primaryGenreName?: string; genres?: string[];
  releaseDate?: string; trackTimeMillis?: number; description?: string; episodeUrl?: string; episodeGuid?: string;
  episodeFileExtension?: string; episodeNumber?: number; seasonNumber?: number;
};

function clean(value = "") { return value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim(); }
function tag(block: string, name: string) { const m = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, "i")); return m ? clean(m[1]) : undefined; }
function attr(block: string, name: string) { const m = block.match(new RegExp(`<enclosure\\b[^>]*\\b${name}=["']([^"']+)["']`, "i")); return m?.[1]; }
function durationMs(value?: string) { if (!value) return undefined; if (/^\d+$/.test(value)) return Number(value) * 1000; const p = value.split(":").map(Number); if (p.some(Number.isNaN)) return undefined; if (p.length === 3) return (p[0] * 3600 + p[1] * 60 + p[2]) * 1000; if (p.length === 2) return (p[0] * 60 + p[1]) * 1000; return undefined; }

function podcastFrom(r: ITunesPodcastResult, rank?: number): Podcast {
  const id = String(r.collectionId ?? r.trackId ?? r.collectionName ?? "unknown");
  return { id: `podcast-${id}`, collectionId: id, title: r.collectionName ?? r.trackName ?? "Untitled podcast", author: r.artistName ?? "Unknown", artwork: highResArtwork(r.artworkUrl600 ?? r.artworkUrl100, 1200) ?? r.artworkUrl600 ?? r.artworkUrl100, feedUrl: r.feedUrl, appleUrl: r.collectionViewUrl ?? r.trackViewUrl, genre: r.genres ?? (r.primaryGenreName ? [r.primaryGenreName] : []), provider: "itunes", rank };
}

function episodeFrom(r: ITunesPodcastResult, podcastId: string, fallbackAuthor: string, artwork?: string): PodcastEpisode {
  return { id: `podcast-episode-${r.trackId ?? r.episodeGuid ?? `${podcastId}-${r.trackName}`}`, podcastId, title: r.trackName ?? "Untitled episode", author: r.artistName ?? fallbackAuthor, description: r.description, artwork: artwork ?? highResArtwork(r.artworkUrl600 ?? r.artworkUrl100, 1200), publishedAt: r.releaseDate, durationMs: r.trackTimeMillis, episodeUrl: r.episodeUrl, appleUrl: r.trackViewUrl, guid: r.episodeGuid, episodeNumber: r.episodeNumber, seasonNumber: r.seasonNumber };
}

async function itunes<T>(path: string, params: Record<string, string>) {
  const url = new URL(path, ITUNES); Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url, { next: { revalidate: 600 } });
  if (!res.ok) throw new Error(`iTunes podcast request failed: ${res.status}`);
  return res.json() as Promise<T>;
}

export async function searchPodcasts(term: string, country = "US", limit = 25): Promise<PodcastSearchResponse> {
  const data = await itunes<{ results?: ITunesPodcastResult[] }>("/search", { term, media: "podcast", entity: "podcast", country, limit: String(Math.min(50, Math.max(1, limit))) });
  const podcasts = (data.results ?? []).filter(r => r.kind === "podcast").map(r => podcastFrom(r));
  return { podcasts, episodes: [] };
}

export async function lookupPodcast(collectionId: string, country = "US") {
  const data = await itunes<{ results?: ITunesPodcastResult[] }>("/lookup", { id: collectionId, country });
  const show = data.results?.find(r => r.kind === "podcast" || r.wrapperType === "collection");
  return show ? podcastFrom(show) : null;
}

export async function lookupPodcastWithEpisodes(collectionId: string, country = "US", limit = 100) {
  const data = await itunes<{ results?: ITunesPodcastResult[] }>("/lookup", { id: collectionId, country, entity: "podcastEpisode", limit: String(Math.min(200, Math.max(1, limit))) });
  const results = data.results ?? [];
  const show = results.find(r => r.kind === "podcast" || r.wrapperType === "collection");
  if (!show) return null;
  const podcast = podcastFrom(show);
  const episodes = results.filter(r => r.kind === "podcast-episode" || r.wrapperType === "track").map(r => episodeFrom(r, podcast.id, podcast.author, podcast.artwork));
  return { podcast, episodes };
}

export async function resolvePodcastFeedUrl(collectionId: string, country = "US") {
  const direct = await lookupPodcast(collectionId, country);
  if (direct?.feedUrl) return direct.feedUrl;
  return null;
}

function safeHttpUrl(value?: string) { try { const u = new URL(value ?? ""); if (u.protocol !== "https:") return null; return u.toString(); } catch { return null; } }

export async function fetchPodcastRss(podcast: Podcast, page = 1, pageSize = 20) {
  let feedUrl = podcast.feedUrl;
  if (!feedUrl) feedUrl = await resolvePodcastFeedUrl(podcast.collectionId);
  const candidateFeed = safeHttpUrl(feedUrl);
  if (!candidateFeed) throw new Error("Podcast RSS feed is unavailable or not HTTPS.");
  const safeFeed = await assertSafePodcastUrl(candidateFeed);
  const response = await fetch(safeFeed, { headers: { accept: "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.1", "user-agent": "HuniPodcast/2.0" }, cache: "no-store", redirect: "manual", signal: AbortSignal.timeout(10_000) });
  if (!response.ok || response.status >= 300) throw new Error(`Podcast RSS fetch failed: ${response.status}`);
  const xml = await response.text();
  const channelImage = tag(xml.match(/<channel\b[\s\S]*?<\/channel>/i)?.[0] ?? "", "url");
  const items = [...xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)].map(m => m[1]);
  const all = items.map((block, index) => {
    const guid = tag(block, "guid") ?? tag(block, "link") ?? `${podcast.id}-${index}`;
    const audio = attr(block, "url");
    return { id: `podcast-episode-${encodeURIComponent(guid).slice(0, 220)}`, podcastId: podcast.id, title: tag(block, "title") ?? "Untitled episode", author: tag(block, "itunes:author") ?? podcast.author, description: tag(block, "description") ?? tag(block, "content:encoded"), artwork: tag(block, "itunes:image") ? undefined : channelImage, publishedAt: tag(block, "pubDate"), durationMs: durationMs(tag(block, "itunes:duration")), enclosureType: attr(block, "type"), episodeUrl: safeHttpUrl(audio) ?? undefined, appleUrl: tag(block, "link"), guid, episodeNumber: Number(tag(block, "itunes:episode")) || undefined, seasonNumber: Number(tag(block, "itunes:season")) || undefined } satisfies PodcastEpisode;
  }).filter(e => e.episodeUrl);
  const start = Math.max(0, (page - 1) * pageSize); const end = start + pageSize;
  return { podcast: { ...podcast, feedUrl: safeFeed }, episodes: all.slice(start, end), total: all.length, hasMore: end < all.length };
}

export async function getApplePodcastCharts(country = "US", limit = 10) {
  const c = country.toLowerCase();
  async function feed(path: string) { const res = await fetch(`${APPLE_RSS}/${c}/${path}`, { next: { revalidate: 900 } }); if (!res.ok) throw new Error(`Apple Podcasts RSS failed: ${res.status}`); return res.json() as Promise<{ feed?: { updated?: string; results?: Array<{ id?: string; name?: string; artistName?: string; artworkUrl100?: string; url?: string; genres?: { name: string }[] }> } }>; }
  const [top, channels] = await Promise.all([
    feed(`podcasts/top/${limit}/podcasts.json`),
    feed(`podcasts/top-subscriber/${limit}/podcast-channels.json`).catch(() => ({ feed: { results: [] } }))
  ]);
  const map = (results: NonNullable<typeof top.feed>['results']) => (results ?? []).map((r, i) => ({ id: `podcast-${r.id}`, collectionId: r.id ?? "", title: r.name ?? "Untitled podcast", author: r.artistName ?? "Unknown", artwork: highResArtwork(r.artworkUrl100, 1200) ?? r.artworkUrl100, appleUrl: r.url, genre: r.genres?.map(g => g.name), provider: "apple-rss" as const, rank: i + 1 }));
  return { podcasts: map(top.feed?.results), channels: map(channels.feed?.results), updated: top.feed?.updated };
}

export async function getTopPodcastEpisodes(country = "US", limit = 10) {
  const charts = await getApplePodcastCharts(country, limit);
  const shows = await Promise.all(charts.podcasts.slice(0, limit).map(async p => { try { const full = await lookupPodcastWithEpisodes(p.collectionId, country, 10); return full?.episodes.slice(0, 2) ?? []; } catch { return []; } }));
  return shows.flat().slice(0, limit);
}
