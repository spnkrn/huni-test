import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const component = readFileSync("src/components/metadata/provider-provenance.tsx", "utf8");
const artist = readFileSync("src/app/artist/[id]/page.tsx", "utf8");
const album = readFileSync("src/app/album/[id]/page.tsx", "utf8");
const song = readFileSync("src/app/song/[id]/page.tsx", "utf8");

describe("provider provenance", () => {
  it("renders known provider identities without inventing unavailable sources", () => {
    expect(component).toContain("ids.qobuz");
    expect(component).toContain("ids.itunes");
    expect(component).toContain("ids.musicbrainz");
    expect(component).toContain("Metadata source");
  });
  it("is present on artist, album, and song detail pages", () => {
    expect(artist).toContain("ProviderProvenance");
    expect(album).toContain("ProviderProvenance");
    expect(song).toContain("ProviderProvenance");
  });
});
