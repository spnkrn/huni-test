"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Play, Clock3, ListMusic } from "lucide-react";
import type { Track } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";
import { formatDuration } from "@/lib/utils";
import { localStore } from "@/lib/local-store";
import { DownloadButton } from "@/components/music/download-button";

export default function PodcastEpisodePage({ params }: { params: Promise<{ id: string }> }) {
  const [id,setId]=useState(""); const [episode,setEpisode]=useState<Track|null>(null); const [loading,setLoading]=useState(true); const [position,setPosition]=useState(0); const { play, seek }=usePlayer();
  useEffect(()=>{params.then(p=>setId(p.id));},[params]);
  useEffect(()=>{if(!id)return;setLoading(true);fetch(`/api/podcast-episode/${id}`).then(r=>r.ok?r.json():null).then((d:Track|null)=>{setEpisode(d);if(d){const p=localStore.snapshot().progress[d.id];setPosition(p?.positionSeconds??0);}}).finally(()=>setLoading(false));},[id]);
  if(loading) return <div className="py-24 text-center text-sm text-white/35">Loading episode…</div>;
  if(!episode) return <div className="py-24 text-center text-sm text-white/35">Episode not found.</div>;
  const percent=episode.durationMs&&position?Math.min(100,position/(episode.durationMs/1000)*100):0;
  return <div className="mx-auto max-w-4xl">
    <Link href={`/podcast/${episode.podcastId?.replace(/^podcast-/,'')}`} className="inline-flex items-center gap-2 text-xs text-white/40 hover:text-white"><ArrowLeft size={14}/> Back to podcast</Link>
    <section className="mt-8 grid gap-7 md:grid-cols-[220px_1fr] md:items-end">
      <div className="relative aspect-square overflow-hidden rounded-3xl border border-white/10 bg-white/5">{episode.artwork?.large?<Image src={episode.artwork.large} alt="" fill sizes="220px" className="object-cover"/>:null}</div>
      <div><div className="eyebrow">Podcast episode</div><h1 className="mt-2 text-3xl font-semibold tracking-tight md:text-5xl">{episode.title}</h1><Link href={`/podcast/${episode.podcastId?.replace(/^podcast-/,'')}`} className="mt-3 block text-sm text-white/50 hover:text-white">{episode.podcastTitle}</Link><div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-white/40">{episode.releaseDate?<span>{new Date(episode.releaseDate).toLocaleDateString()}</span>:null}{episode.durationMs?<span className="inline-flex items-center gap-1"><Clock3 size={12}/>{formatDuration(episode.durationMs)}</span>:null}{episode.providerIds.itunes?<span className="rounded-full border border-white/10 px-2 py-1">Apple Podcasts</span>:null}</div><div className="mt-6 flex flex-wrap items-center gap-2"><button onClick={()=>play(episode)} className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-medium text-black"><Play size={15} fill="currentColor"/> {percent>1?"Resume episode":"Play episode"}</button><DownloadButton track={episode} /></div></div>
    </section>
    {percent>1?<div className="mt-8"><div className="mb-2 flex justify-between text-[11px] text-white/35"><span>Progress</span><span>{Math.round(percent)}%</span></div><div className="h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-white/70" style={{width:`${percent}%`}}/></div></div>:null}
    {episode.chapters?.length?<section className="mt-12"><div className="eyebrow">Chapters</div><div className="mt-3 glass overflow-hidden rounded-2xl">{episode.chapters.map((chapter,index)=><button key={`${chapter.startSeconds}-${index}`} onClick={()=>{play(episode); window.setTimeout(()=>seek(chapter.startSeconds),250);}} className="flex w-full items-center gap-3 border-b border-white/5 px-4 py-3 text-left last:border-0 hover:bg-white/[.04]"><span className="w-12 text-right text-[11px] tabular-nums text-white/30">{formatDuration(chapter.startSeconds*1000)}</span><ListMusic size={14} className="text-white/30"/><span className="min-w-0 flex-1 truncate text-sm text-white/65">{chapter.title}</span></button>)}</div></section>:null}
    <section className="mt-12"><div className="eyebrow">Show notes</div><div className="mt-3 whitespace-pre-wrap text-sm leading-7 text-white/65">{episode.description ?? "No show notes were supplied by the publisher."}</div></section>
  </div>;
}
