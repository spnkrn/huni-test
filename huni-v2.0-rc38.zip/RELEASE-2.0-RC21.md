# Huni 2.0 RC.21

## Playlist ↔ Player integration

- Added playlist-level Play All and Shuffle controls using the canonical `playTracks` player API.
- Playlist playback now replaces the active queue consistently instead of only starting the first track.
- Empty playlists disable playback controls.
- Added a visible playlist track count.
- Added static coverage for playlist batch playback and protected playlist mutations.
- Corrected the static QA route-count expectation to 16.

## Verification

Static/source checks should be run with the project's installed dependencies. Full dependency-backed certification remains separate from source packaging.
