export type MatchCandidate = {
  artist: string;
  title: string;
  album?: string;
  durationSec?: number;
  isrc?: string;
};

export function normalizeMusicText(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
}

export function normalizeIsrc(value?: string) {
  return value?.replace(/[^a-z0-9]/gi, "").toUpperCase() || "";
}

export function matchScore(a: MatchCandidate, b: MatchCandidate) {
  if (normalizeIsrc(a.isrc) && normalizeIsrc(a.isrc) === normalizeIsrc(b.isrc)) return 100;
  let score = 0;
  if (normalizeMusicText(a.artist) === normalizeMusicText(b.artist)) score += 30;
  if (normalizeMusicText(a.title) === normalizeMusicText(b.title)) score += 30;
  if (a.album && b.album && normalizeMusicText(a.album) === normalizeMusicText(b.album)) score += 20;
  if (a.durationSec && b.durationSec && Math.abs(a.durationSec - b.durationSec) <= 3) score += 10;
  return score;
}

export function rankMatches<T>(target: MatchCandidate, candidates: Array<{ value: T; candidate: MatchCandidate }>) {
  return candidates
    .map((item) => ({ ...item, score: matchScore(target, item.candidate) }))
    .sort((a, b) => b.score - a.score);
}
