import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const root = process.cwd();

describe("playback session storage hardening", () => {
  it("uses the server-only Supabase admin client", () => {
    const source = readFileSync(`${root}/src/lib/playback/session-store.ts`, "utf8");
    expect(source).toContain('import { createAdminClient } from "@/lib/supabase/admin";');
    expect(source).not.toContain('from "@/lib/supabase/server"');
    expect(source).toContain("createAdminClient()");
  });

  it("does not grant client RLS policies on playback_sessions", () => {
    const baseline = readFileSync(`${root}/supabase/migrations/0003_playback_sessions.sql`, "utf8");
    const hardening = readFileSync(`${root}/supabase/migrations/0004_playback_sessions_server_managed.sql`, "utf8");
    expect(baseline).toContain("create table if not exists public.playback_sessions");
    expect(hardening).toContain("alter table public.playback_sessions enable row level security;");
    expect(hardening).toMatch(/drop policy if exists .*playback_sessions_self_insert/i);
    expect(hardening).toMatch(/drop policy if exists .*playback_sessions_self_update/i);
    expect(hardening).toMatch(/drop policy if exists .*playback_sessions_self_delete/i);
  });

  it("keeps provider URLs encrypted at rest", () => {
    const source = readFileSync(`${root}/src/lib/playback/session-store.ts`, "utf8");
    expect(source).toContain("aes-256-gcm");
    expect(source).toContain("PLAYBACK_ENCRYPTION_KEY");
    expect(source).toContain("stream_url_encrypted");
    expect(source).toContain("download_url_encrypted");
  });

  it("requires a dedicated encryption key in the environment verifier", () => {
    const source = readFileSync(`${root}/scripts/verify-env.mjs`, "utf8");
    expect(source).toContain("PLAYBACK_ENCRYPTION_KEY");
    expect(source).toContain("SUPABASE_SECRET_KEY");
  });

  it("cleans up expired sessions without weakening expiry enforcement", () => {
    const source = readFileSync(`${root}/src/lib/playback/session-store.ts`, "utf8");
    expect(source).toContain("cleanupExpiredPlaybackSessions");
    expect(source).toContain('.lte("expires_at", new Date().toISOString())');
    expect(source).toContain('.gt("expires_at", new Date().toISOString())');
    expect(source).toContain('eq("user_id", userId)');
  });
});
