"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import type { Track } from "@/lib/types";
import type { Podcast } from "@/lib/podcast-types";
import { TrackRow } from "@/components/music/track-row";
import { PodcastCard } from "@/components/podcasts/podcast-card";
import { useLocalLibrary } from "@/components/library/local-library-provider";

type Tab = "all" | "music" | "podcasts" | "following";

export function UnifiedLibraryView({ tracks }: { tracks: Track[] }) {
  const { followedPodcasts } = useLocalLibrary();
  const [tab, setTab] = useState<Tab>("all");
  const music = useMemo(() => tracks.filter(t => t.mediaType !== "podcast"), [tracks]);
  const podcasts = useMemo(() => tracks.filter(t => t.mediaType === "podcast"), [tracks]);
  const tabs: Array<[Tab, string, number]> = [["all", "All", tracks.length], ["music", "Music", music.length], ["podcasts", "Podcasts", podcasts.length], ["following", "Followed podcasts", followedPodcasts.length]];
  return <>
    <div className="mt-6 flex flex-wrap gap-2" role="tablist" aria-label="Library filters">
      {tabs.map(([id, label, count]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)} className={`rounded-full border px-3 py-1.5 text-xs transition ${tab === id ? "border-white/20 bg-white text-black" : "border-white/10 bg-white/[.04] text-white/50 hover:text-white"}`}>{label} <span className="ml-1 opacity-50">{count}</span></button>)}
    </div>
    {tab === "following" ? <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{followedPodcasts.length ? followedPodcasts.map((podcast: Podcast) => <PodcastCard key={podcast.id} podcast={podcast} />) : <Empty text="You aren't following any podcasts yet." href="/podcasts" action="Discover podcasts" />}</div> : <div className="mt-8 space-y-2">{(tab === "music" ? music : tab === "podcasts" ? podcasts : tracks).length ? (tab === "music" ? music : tab === "podcasts" ? podcasts : tracks).map((track, index) => <TrackRow key={track.id} track={track} index={index + 1} />) : <Empty text={`No ${tab === "music" ? "music" : "podcasts"} saved yet.`} href={tab === "podcasts" ? "/podcasts" : "/search"} action={tab === "podcasts" ? "Discover podcasts" : "Find music"} />}</div>}
  </>;
}
function Empty({ text, href, action }: { text: string; href: string; action: string }) { return <div className="glass rounded-2xl p-10 text-center text-sm text-white/35">{text}<div className="mt-4"><Link href={href} className="text-white/65 underline underline-offset-4">{action}</Link></div></div>; }
