import { NextRequest, NextResponse } from "next/server";
import { withApiHeaders } from "@/lib/security/api";
import { getUserContentRegion } from "@/lib/region";
import { getApplePodcastCharts, getTopPodcastEpisodes } from "@/lib/providers/podcasts";

export async function GET(req: NextRequest) {
  const headers = withApiHeaders(req); const country = (await getUserContentRegion()).region; const limit = Math.min(25, Math.max(5, Number(req.nextUrl.searchParams.get("limit") ?? "10") || 10));
  try { const [charts, episodes] = await Promise.all([getApplePodcastCharts(country, limit), getTopPodcastEpisodes(country, limit)]); return NextResponse.json({ ...charts, episodes }, { headers }); }
  catch { return NextResponse.json({ error: "Podcast charts temporarily unavailable" }, { status: 502, headers }); }
}
