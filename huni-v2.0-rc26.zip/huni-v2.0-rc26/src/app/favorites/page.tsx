export const dynamic = "force-dynamic";

import { requireUser } from "@/lib/supabase/require-user";
import { Track } from "@/lib/types";
import { TrackRow } from "@/components/music/track-row";
import { FavoriteControls } from "./favorite-controls";

export default async function FavoritesPage() {
  const { supabase, user } = await requireUser();
  const { data: favorites } = await supabase.from("track_favorites").select("track_id, created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(100);
  const ids = (favorites ?? []).map((row) => row.track_id);
  const { data: library } = ids.length ? await supabase.from("library_tracks").select("track_id, track").eq("user_id", user.id).in("track_id", ids) : { data: [] as { track_id: string; track: unknown }[] };
  const byId = new Map((library ?? []).map((row) => [row.track_id, row.track as Track]));
  const tracks = ids.map((id) => byId.get(id)).filter((track): track is Track => Boolean(track?.id && track.title));
  return <div className="mx-auto max-w-5xl">
    <div className="eyebrow">Favorites</div>
    <h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Your favorites</h1>
    <p className="mt-2 text-sm text-white/40">Favorite tracks are kept alongside your saved library.</p>
    {tracks.length ? <><FavoriteControls tracks={tracks} /><div className="mt-8 space-y-2">{tracks.map((track, index) => <TrackRow key={track.id} track={track} index={index + 1} />)}</div></> : <div className="glass mt-10 rounded-2xl p-12 text-center text-sm text-white/35">No favorites yet. Favorite a track to see it here.</div>}
  </div>;
}
