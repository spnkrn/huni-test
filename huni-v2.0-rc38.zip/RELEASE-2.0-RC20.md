# Huni 2.0 RC.20

## History + Library integration

- Added authenticated history GET with server-side track validation and deduplication.
- Added a Favorites page backed by favorite IDs and the user library's canonical track payloads.
- Added Play All and Shuffle Favorites actions.
- Reset the per-track history boundary when intentionally changing tracks so a later play of the same track can be recorded.
- Added static coverage for history/library integration.

## Verification

- Static source checks: expected to run without dependency installation.
- Dependency-backed typecheck/tests/build remain environment-dependent until npm dependencies are available.
