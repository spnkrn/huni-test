# Huni 2.0 RC.16

## Queue and playback lifecycle hardening

- Added queue drag-and-drop reordering with current-index preservation.
- Added explicit remove-from-queue and clear-queue controls to the queue drawer.
- Added shuffle history so sequential `next` operations avoid immediate repeats until the queue has been traversed.
- Added shuffle-aware previous behavior using recent shuffle history.
- Reset shuffle history when shuffle is toggled.
- Preserved queue/index/shuffle/repeat persistence from RC.15.

## Verification

Static/source verification can be run with the existing release scripts. Full dependency-backed typecheck, tests, lint, and Next production build remain dependent on installing the npm dependency graph.
