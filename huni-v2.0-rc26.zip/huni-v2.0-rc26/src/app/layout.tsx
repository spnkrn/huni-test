import "./globals.css";
import { Navigation } from "@/components/layout/nav";
import { PlayerProvider } from "@/components/player/player-context";
import { MiniPlayer } from "@/components/player/mini-player";
import { RegisterServiceWorker } from "@/components/pwa/register-service-worker";

export const metadata = {
  title: "Huni — Hi-Fi Music",
  description: "A premium music discovery experience.",
  applicationName: "Huni",
  themeColor: "#090909"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <RegisterServiceWorker />
        <PlayerProvider>
          <a href="#main-content" className="skip-link">Skip to content</a>
          <Navigation />
          <main id="main-content" className="main-shell" tabIndex={-1}>{children}</main>
          <MiniPlayer />
        </PlayerProvider>
      </body>
    </html>
  );
}