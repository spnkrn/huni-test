export function cn(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(" ");
}

export function highResArtwork(url?: string, size = 1000) {
  if (!url) return undefined;
  return url.replace(/100x100|60x60|100x100bb/g, `${size}x${size}bb`);
}

export function formatDuration(ms?: number) {
  if (!ms || ms < 0) return "—";
  const total = Math.round(ms / 1000);
  const minutes = Math.floor(total / 60);
  const seconds = String(total % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}