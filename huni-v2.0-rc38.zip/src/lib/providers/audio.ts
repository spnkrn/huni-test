import { Track } from "@/lib/types";
import { callAuthorizedAudioGateway } from "@/lib/providers/http";

export type PlaybackSession = {
  sessionId: string;
  expiresAt: string;
  streamUrl: string;
  downloadUrl?: string;
};

export interface AudioProvider {
  readonly id: string;
  isConfigured(): boolean;
  createPlaybackSession(track: Track, userId: string): Promise<PlaybackSession>;
}

/**
 * Gateway-backed provider. The gateway must itself use an authorized provider
 * integration and return short-lived playback URLs. Huni never accepts a raw
 * CDN URL from the browser.
 */
export class AuthorizedGatewayAudioProvider implements AudioProvider {
  readonly id: string;

  constructor(id: string) { this.id = id; }

  isConfigured() {
    return Boolean(process.env.HUNI_AUDIO_PROVIDER_GATEWAY_URL) &&
      (process.env.HUNI_AUDIO_PROVIDER_ENABLED ?? "false") === "true" &&
      Boolean(process.env.HUNI_AUDIO_PROVIDER_ALLOWED_HOSTS);
  }

  createPlaybackSession(track: Track, userId: string) {
    return callAuthorizedAudioGateway({ track, userId, provider: this.id });
  }
}

/** Qobuz must be enabled only when the deployment has a legitimate Qobuz integration. */
export class QobuzAudioProvider extends AuthorizedGatewayAudioProvider {
  readonly id = "qobuz";
  isConfigured() {
    return process.env.QOBUZ_ENABLED === "true" && super.isConfigured();
  }
}
