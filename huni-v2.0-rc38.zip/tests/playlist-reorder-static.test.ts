import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const route = readFileSync("src/app/api/playlists/[id]/tracks/route.ts", "utf8");
const page = readFileSync("src/app/playlists/[id]/page.tsx", "utf8");

describe("playlist reorder hardening", () => {
  it("validates ownership and the complete ordered track set", () => {
    expect(route).toContain('export async function PATCH');
    expect(route).toContain('orderedTrackIds');
    expect(route).toContain('Duplicate track IDs are not allowed');
    expect(route).toContain('Playlist changed; reload and try again');
    expect(route).toContain('.eq("user_id", user.id)');
  });
  it("exposes reorder and removal controls", () => {
    expect(page).toContain('draggable');
    expect(page).toContain('moveInQueue');
    expect(page).toContain('method: "PATCH"');
  });
});
