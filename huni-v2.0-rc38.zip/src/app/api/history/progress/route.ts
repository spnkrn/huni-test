import { NextResponse } from "next/server";
import { bodyWithinLimit, sameOrigin, jsonError, readJson, withApiHeaders } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";
import { isTrack } from "@/lib/persistence";

function validTrackId(value: unknown): value is string { return typeof value === "string" && value.length > 0 && value.length <= 256; }
function validPosition(value: unknown): value is number { return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 604800; }

export async function GET(request: Request) {
  const url = new URL(request.url);
  const trackId = url.searchParams.get("trackId");
  const podcastsOnly = url.searchParams.get("podcasts") === "true";
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  if (podcastsOnly) {
    const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? 12) || 12, 1), 50);
    const [{ data: progressRows, error: progressError }, { data: historyRows, error: historyError }] = await Promise.all([
      supabase.from("listening_progress").select("track_id,position_seconds,duration_seconds,updated_at").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(100),
      supabase.from("listening_history").select("track,played_at,completed").eq("user_id", user.id).order("played_at", { ascending: false }).limit(100),
    ]);
    if (progressError || historyError) return jsonError(request, "Progress could not be loaded", 400);
    const historyById = new Map<string, unknown>();
    for (const row of historyRows ?? []) { if (isTrack(row.track) && !historyById.has(row.track.id)) historyById.set(row.track.id, row.track); }
    const items = (progressRows ?? []).map((row) => ({ ...row, track: historyById.get(row.track_id) })).filter((row) => isTrack(row.track) && row.track.mediaType === "podcast").slice(0, limit);
    return NextResponse.json({ progress: items }, { headers: withApiHeaders(request) });
  }
  if (!validTrackId(trackId)) return jsonError(request, "Invalid trackId", 400);
  const { data, error } = await supabase.from("listening_progress").select("position_seconds,duration_seconds,updated_at").eq("user_id", user.id).eq("track_id", trackId).maybeSingle();
  if (error) return jsonError(request, "Progress could not be loaded", 400);
  return NextResponse.json({ progress: data ?? null }, { headers: withApiHeaders(request) });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`history-progress:${getRequestFingerprint(request)}`, 120, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const body = await readJson<Record<string, unknown>>(request);
  if (!body || !validTrackId(body.trackId) || !validPosition(body.positionSeconds)) return jsonError(request, "Invalid progress", 400);
  const duration = body.durationSeconds === undefined || body.durationSeconds === null ? null : body.durationSeconds;
  if (duration !== null && (!validPosition(duration) || duration <= 0)) return jsonError(request, "Invalid duration", 400);
  const completed = body.completed === true;
  const position = completed && duration !== null ? duration : body.positionSeconds;
  const { error } = await supabase.from("listening_progress").upsert({ user_id: user.id, track_id: body.trackId, position_seconds: position, duration_seconds: duration, updated_at: new Date().toISOString() }, { onConflict: "user_id,track_id" });
  if (error) return jsonError(request, "Progress could not be saved", 400);
  return NextResponse.json({ saved: true }, { headers: withApiHeaders(request) });
}
