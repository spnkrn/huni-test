"use client";

import { useMemo } from "react";
import { usePlayer } from "./player-context";

function formatTime(value: number) {
  if (!Number.isFinite(value) || value < 0) return "0:00";
  const total = Math.floor(value);
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

export function PlayerProgress() {
  const { position, duration, buffered, seek } = usePlayer();
  const percent = useMemo(() => duration ? Math.min(100, Math.max(0, position / duration * 100)) : 0, [position, duration]);
  const bufferedPercent = useMemo(() => duration ? Math.min(100, Math.max(0, buffered / duration * 100)) : 0, [buffered, duration]);

  return (
    <div className="space-y-2">
      <div className="relative h-5 flex items-center">
        <div className="absolute inset-x-0 h-1.5 rounded-full bg-white/10" />
        <div className="absolute left-0 h-1.5 rounded-full bg-white/15" style={{ width: `${bufferedPercent}%` }} />
        <div className="absolute left-0 h-1.5 rounded-full bg-white" style={{ width: `${percent}%` }} />
        <input
          aria-label="Seek"
          type="range"
          min={0}
          max={duration || 0}
          step={0.1}
          value={Math.min(position, duration || 0)}
          onChange={(event) => seek(Number(event.target.value))}
          disabled={!duration}
          className="relative z-10 h-5 w-full cursor-pointer appearance-none bg-transparent accent-white"
        />
      </div>
      <div className="flex justify-between text-[11px] tabular-nums text-white/40">
        <span>{formatTime(position)}</span>
        <span>{formatTime(duration)}</span>
      </div>
    </div>
  );
}
