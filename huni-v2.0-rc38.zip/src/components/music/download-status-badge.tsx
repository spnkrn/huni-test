"use client";
import { Check } from "lucide-react";
import { useEffect, useState } from "react";
import type { Track } from "@/lib/types";
import { offlineStore } from "@/lib/offline-store";
export function DownloadStatusBadge({ track }: { track: Track }) {
 const [saved,setSaved]=useState(false);
 useEffect(()=>{let alive=true;const refresh=()=>void offlineStore.has(track.id).then(v=>{if(alive)setSaved(v)}).catch(()=>{});refresh();window.addEventListener("huni-offline-store",refresh);return()=>{alive=false;window.removeEventListener("huni-offline-store",refresh)}},[track.id]);
 return saved ? <span title="Available offline on this device" className="inline-flex shrink-0 items-center gap-1 rounded-full border border-white/10 bg-white/[.06] px-1.5 py-0.5 text-[9px] uppercase tracking-[.1em] text-white/45"><Check size={9}/> Offline</span> : null;
}
