export type Artwork = { small?: string; medium?: string; large?: string };

export type Artist = {
  id: string;
  name: string;
  image?: string;
  country?: string;
  type?: string;
  musicbrainzId?: string;
  providerIds?: { itunes?: string; qobuz?: string; musicbrainz?: string };
};

export type Track = {
  mediaType?: "music" | "podcast";
  podcastId?: string;
  podcastTitle?: string;
  id: string;
  title: string;
  artists: Artist[];
  album?: { id: string; title: string; artwork?: Artwork; releaseDate?: string };
  durationMs?: number;
  trackNumber?: number;
  discNumber?: number;
  releaseDate?: string;
  genre?: string[];
  label?: string;
  description?: string;
  chapters?: import("@/lib/podcast-types").PodcastChapter[];
  explicit?: boolean;
  isrc?: string;
  artwork?: Artwork;
  providerIds: { itunes?: string; qobuz?: string; musicbrainz?: string };
  previewUrl?: string;
  audioUrl?: string;
};

export type Album = {
  id: string;
  title: string;
  artist: Artist;
  artwork?: Artwork;
  releaseDate?: string;
  genre?: string[];
  trackCount?: number;
  tracks?: Track[];
  providerIds: { itunes?: string; qobuz?: string; musicbrainz?: string };
};

export type LyricsLine = { timeMs: number; text: string };
export type Lyrics = { synced: boolean; lines: LyricsLine[]; plainText?: string; source: "lrclib" | "none" };
export type SearchResponse = { tracks: Track[]; albums: Album[]; artists: Artist[]; podcasts?: import("@/lib/podcast-types").Podcast[]; };

export type QueueState = {
  items: Track[];
  index: number;
  shuffle: boolean;
  repeat: "off" | "all" | "one";
};
