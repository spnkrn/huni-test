# Huni 2.0 RC.14

## Player resilience

- Added playback-generation guards so stale session responses cannot replace a newer track/session.
- Abort pending playback-session requests when switching tracks or pausing.
- Prevent stale playback operations from clearing the loading state of a newer operation.
- Keep Media Session `playbackState` synchronized with Huni player state.
- Preserve single-attempt stream recovery and session expiry renewal.

## Verification

Static source tests cover stale-session protection and Media Session synchronization. Full dependency-backed test/build certification remains dependent on npm package installation.
