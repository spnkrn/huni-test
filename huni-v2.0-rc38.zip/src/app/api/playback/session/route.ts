import { NextResponse } from "next/server";
import { bodyWithinLimit, sameOrigin, jsonError } from "@/lib/security/api";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { getConfiguredAudioProvider } from "@/lib/providers/registry";
import { issuePlaybackToken } from "@/lib/playback/token";
import { lookupTrack } from "@/lib/providers/itunes";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { logError, logEvent } from "@/lib/security/logger";
import { requestId } from "@/lib/security/api";
import { storePlaybackSession } from "@/lib/playback/session-store";
import { verifyPlaybackToken } from "@/lib/playback/token";
import { assertSafePodcastUrl } from "@/lib/providers/http";
import { lookupPodcast, fetchPodcastRss } from "@/lib/providers/podcasts";

const bodySchema = z.object({ trackId: z.string().min(1).max(256) });

function decodePodcastEpisodeId(id: string) {
  try { return JSON.parse(Buffer.from(id.slice("podcast-episode-".length), "base64url").toString("utf8")) as { podcastId: string; guid: string }; } catch { return null; }
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const requestIdValue = requestId(request);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401, headers: { "X-Request-ID": requestIdValue, "Cache-Control": "private, no-store" } });

  const rate = rateLimit(`playback:${getRequestFingerprint(request, user.id)}`, 20, 60_000);
  const baseHeaders = { "X-Request-ID": requestIdValue, ...rateLimitHeaders(rate), "Cache-Control": "private, no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many playback requests" }, { status: 429, headers: { ...baseHeaders, "Retry-After": String(Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000))) } });

  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request" }, { status: 400, headers: baseHeaders });

  if (parsed.data.trackId.startsWith("podcast-episode-")) {
    const decoded = decodePodcastEpisodeId(parsed.data.trackId);
    if (!decoded?.podcastId || !decoded.guid) return NextResponse.json({ error: "Podcast episode could not be resolved" }, { status: 404, headers: baseHeaders });
    try {
      const podcast = await lookupPodcast(decoded.podcastId, process.env.ITUNES_COUNTRY ?? "US");
      if (!podcast) return NextResponse.json({ error: "Podcast could not be resolved" }, { status: 404, headers: baseHeaders });
      const rss = await fetchPodcastRss(podcast, 1, 500);
      const episode = rss.episodes.find(e => e.guid === decoded.guid);
      if (!episode?.episodeUrl) return NextResponse.json({ error: "Podcast episode audio is unavailable" }, { status: 404, headers: baseHeaders });
      const upstream = await assertSafePodcastUrl(episode.episodeUrl);
      const expiresAt = new Date(Date.now() + 60 * 60_000).toISOString();
      const token = issuePlaybackToken({ userId: user.id, trackId: parsed.data.trackId, provider: "podcast" }, 3600);
      const claims = verifyPlaybackToken(token);
      if (!claims) throw new Error("Unable to verify podcast playback token.");
      await storePlaybackSession({ claims, streamUrl: upstream, downloadUrl: upstream, expiresAt });
      const proxyBase = new URL("/api/playback/stream", request.url);
      proxyBase.searchParams.set("token", token);
      const downloadProxy = new URL(proxyBase);
      downloadProxy.searchParams.set("download", "1");
      return NextResponse.json({ sessionId: claims.sessionId, expiresAt, streamUrl: proxyBase.toString(), downloadUrl: downloadProxy.toString(), accessToken: token }, { headers: baseHeaders });
    } catch (error) {
      logError("podcast.playback.session.failed", error, { requestId: requestIdValue, trackId: parsed.data.trackId });
      return NextResponse.json({ error: "Podcast playback provider error", code: "PODCAST_PROVIDER_ERROR", requestId: requestIdValue }, { status: 502, headers: baseHeaders });
    }
  }

  const provider = getConfiguredAudioProvider();
  if (!provider) {
    return NextResponse.json(
      { error: "Playback unavailable", code: "AUDIO_PROVIDER_NOT_CONFIGURED" },
      { status: 503, headers: baseHeaders }
    );
  }

  // The client supplies only a canonical track ID. The provider adapter is the
  // only layer allowed to resolve an authorized playback session. Metadata is
  // resolved server-side; the browser never gets to choose an upstream URL.
  let track = null as Awaited<ReturnType<typeof lookupTrack>>;
  if (parsed.data.trackId.startsWith("itunes-track-")) {
    const itunesId = parsed.data.trackId.slice("itunes-track-".length);
    if (/^\d+$/.test(itunesId)) track = await lookupTrack(itunesId, process.env.ITUNES_COUNTRY ?? "US");
  }

  if (!track) {
    const { data: saved } = await supabase
      .from("library_tracks")
      .select("track")
      .eq("user_id", user.id)
      .eq("track_id", parsed.data.trackId)
      .maybeSingle();
    track = saved?.track ?? null;
  }

  if (!track) {
    return NextResponse.json({ error: "Track could not be resolved by Huni", requestId: requestIdValue }, { status: 404, headers: baseHeaders });
  }

  try {
    const session = await provider.createPlaybackSession(track, user.id);
    const token = issuePlaybackToken({
      userId: user.id,
      trackId: parsed.data.trackId,
      provider: provider.id,
    });
    const claims = verifyPlaybackToken(token);
    if (!claims) throw new Error("Unable to verify issued playback token.");

    await storePlaybackSession({ claims, streamUrl: session.streamUrl, downloadUrl: session.downloadUrl, expiresAt: session.expiresAt });
    logEvent("playback.session.created", { requestId: requestIdValue, trackId: parsed.data.trackId, provider: provider.id });
    const proxyBase = new URL("/api/playback/stream", request.url);
    proxyBase.searchParams.set("token", token);
    const downloadProxy = session.downloadUrl ? new URL(proxyBase) : null;
    if (downloadProxy) downloadProxy.searchParams.set("download", "1");
    return NextResponse.json({ sessionId: claims.sessionId, expiresAt: session.expiresAt, streamUrl: proxyBase.toString(), ...(downloadProxy ? { downloadUrl: downloadProxy.toString() } : {}), accessToken: token }, { headers: baseHeaders });
  } catch (error) {
    logError("playback.session.failed", error, { requestId: requestIdValue, trackId: parsed.data.trackId, provider: provider.id });
    return NextResponse.json(
      { error: "Playback provider error", code: "PROVIDER_ERROR", requestId: requestIdValue },
      { status: 502, headers: baseHeaders }
    );
  }
}
