"use client";
import Image from "next/image";
import Link from "next/link";
import { Play } from "lucide-react";
import type { PodcastEpisode } from "@/lib/podcast-types";
import { episodeToTrack } from "@/lib/podcast-player";
import { usePlayer } from "@/components/player/player-context";
import { formatDuration } from "@/lib/utils";

export function PodcastEpisodeRow({ episode, podcastTitle, author, index }: { episode: PodcastEpisode; podcastTitle: string; author: string; index?: number }) {
  const { play } = usePlayer();
  const track = episodeToTrack(episode, podcastTitle, author);
  return <div className="track-row group">
    <div className="w-8 text-center text-xs text-white/30">{index ?? ""}</div>
    <div className="relative size-11 overflow-hidden rounded-[9px] bg-white/5">
      {episode.artwork ? <Image src={episode.artwork} alt="" fill sizes="44px" className="object-cover" /> : null}
      <button onClick={() => play(track)} className="absolute inset-0 hidden place-items-center bg-black/55 group-hover:grid" aria-label={`Play ${episode.title}`}><Play size={16} fill="currentColor" /></button>
    </div>
    <div className="min-w-0 flex-1">
      <Link href={`/podcast/${episode.podcastId.replace(/^podcast-/, "")}`} className="block truncate text-sm font-medium hover:underline">{episode.title}</Link>
      <div className="truncate text-xs text-white/45">{episode.author}</div>
    </div>
    <span className="hidden max-w-[24%] truncate text-xs text-white/30 md:block">{episode.publishedAt ? new Date(episode.publishedAt).toLocaleDateString() : ""}</span>
    <span className="w-12 text-right text-xs tabular-nums text-white/30">{formatDuration(episode.durationMs)}</span>
  </div>;
}
