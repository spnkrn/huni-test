# Huni 2.0 RC32

## Podcast + Music Media Phase

- Podcast episodes can be downloaded through the authenticated Huni playback proxy when their RSS enclosure is available.
- Publisher audio URLs remain server-side; the browser receives only a short-lived Huni proxy capability.
- Added a reusable Download control to podcast episode pages and music track actions.
- Podcast channel pages now offer Play Episodes and Shuffle controls using the shared Huni queue/player.
- Shared resume selection now prefers the furthest known local/remote progress, improving offline-first and post-sign-in continuity.
- Existing sleep timer, local-first favorites/library/playlists, podcast chapters, explicit/unplayed state, and shared player remain intact.

## Download behavior

Downloads are not a DRM bypass and do not manufacture audio. Huni only exposes a download capability when the authorized playback session resolves a publisher/provider audio source. Podcast downloads use the RSS enclosure URL after the same server-side HTTPS/private-network validation used for playback.
