import { NextResponse } from "next/server";
import { bodyWithinLimit, jsonError, readJson, sameOrigin, withApiHeaders } from "@/lib/security/api";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";
import { createClient } from "@/lib/supabase/server";
import { isTrack } from "@/lib/persistence";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`mutation:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const body = await readJson(request);
  if (!body || !isTrack(body.track)) return jsonError(request, "Invalid track", 400);
  const { error } = await supabase.from("library_tracks").upsert({ user_id: user.id, track_id: body.track.id, track: body.track });
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ saved: true }, { headers: withApiHeaders(request) });
}

export async function DELETE(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`mutation:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const id = new URL(request.url).searchParams.get("trackId");
  if (!id || id.length > 512) return jsonError(request, "trackId is required", 400);
  const { error } = await supabase.from("library_tracks").delete().eq("user_id", user.id).eq("track_id", id);
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ saved: false }, { headers: withApiHeaders(request) });
}

export async function GET(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { data, error } = await supabase.from("library_tracks").select("track_id,track").eq("user_id", user.id);
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ trackIds: data.map(row => row.track_id), tracks: data.map(row => row.track) }, { headers: withApiHeaders(request) });
}
