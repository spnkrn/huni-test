-- Huni persistence baseline for Supabase/Postgres.
-- Run through Supabase migrations, not directly from the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.library_tracks (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id text not null,
  track jsonb not null,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

create table if not exists public.playlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text,
  artwork_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.playlist_tracks (
  playlist_id uuid not null references public.playlists(id) on delete cascade,
  track_id text not null,
  track jsonb not null,
  position integer not null default 0,
  added_at timestamptz not null default now(),
  primary key (playlist_id, track_id)
);

create table if not exists public.listening_history (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id text not null,
  track jsonb not null,
  played_at timestamptz not null default now(),
  position_seconds numeric,
  completed boolean not null default false
);

create table if not exists public.track_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

alter table public.profiles enable row level security;
alter table public.library_tracks enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_tracks enable row level security;
alter table public.listening_history enable row level security;
alter table public.track_favorites enable row level security;

create policy "profiles_self_select" on public.profiles for select using (auth.uid() = id);
create policy "profiles_self_insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_self_update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "library_self_all" on public.library_tracks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "playlists_self_all" on public.playlists for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "playlist_tracks_owner_all" on public.playlist_tracks for all
  using (exists (select 1 from public.playlists p where p.id = playlist_id and p.user_id = auth.uid()))
  with check (exists (select 1 from public.playlists p where p.id = playlist_id and p.user_id = auth.uid()));
create policy "history_self_all" on public.listening_history for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "favorites_self_all" on public.track_favorites for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists listening_history_user_played_at_idx on public.listening_history(user_id, played_at desc);
create index if not exists playlist_tracks_playlist_position_idx on public.playlist_tracks(playlist_id, position);

-- v0.7 provider-resolution cache. Store only non-secret provider metadata.
create table if not exists public.provider_matches (
  track_id text not null,
  provider text not null,
  provider_track_id text,
  isrc text,
  score integer not null,
  metadata jsonb,
  expires_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (track_id, provider)
);

alter table public.provider_matches enable row level security;
-- Provider cache is server-managed; do not expose it to browser clients.
create index if not exists provider_matches_expires_idx on public.provider_matches(expires_at);
