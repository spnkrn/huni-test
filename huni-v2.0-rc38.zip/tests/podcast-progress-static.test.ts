import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
const route = readFileSync("src/app/api/history/progress/route.ts", "utf8");
const component = readFileSync("src/components/podcasts/podcast-continue-listening.tsx", "utf8");
const page = readFileSync("src/app/podcasts/page.tsx", "utf8");
describe("podcast listening progress", () => {
  it("supports podcast-only progress retrieval", () => {
    expect(route).toContain('podcastsOnly');
    expect(route).toContain('row.track.mediaType === "podcast"');
  });
  it("renders persisted progress and resumes through the shared player", () => {
    expect(component).toContain("/api/history/progress?podcasts=true");
    expect(component).toContain("play(track)");
    expect(component).toContain("position_seconds");
  });
  it("mounts Continue Listening on Podcasts", () => expect(page).toContain("PodcastContinueListening"));
});
