"use client";

import Link from "next/link";
import Image from "next/image";
import { AlertCircle, Pause, Play, Loader2, Maximize2 } from "lucide-react";
import { usePlayer } from "./player-context";

export function MiniPlayer() {
  const { track, playing, loading, error, toggle, position, duration } = usePlayer();
  if (!track) return null;

  const artwork = track.artwork?.medium;
  return (
    <div className="fixed bottom-[calc(5.5rem+env(safe-area-inset-bottom))] left-3 right-3 z-40 mx-auto max-w-5xl md:bottom-4">
      <div className="glass-player grid grid-cols-[auto_1fr_auto] items-center gap-3 px-3 py-2">
        <div className="relative size-12 overflow-hidden rounded-[12px] bg-white/5">
          {artwork ? <Image src={artwork} alt="" fill sizes="48px" className="object-cover" /> : null}
        </div>
        <Link href={track.mediaType === "podcast" && track.podcastId ? `/podcast/${track.podcastId.replace(/^podcast-/, "")}` : `/song/${track.id}`} className="min-w-0">
          <div className="truncate text-sm font-medium">{track.title}</div>
          <div className="truncate text-xs text-white/50">{track.mediaType === "podcast" ? (track.podcastTitle ?? "Podcast") : track.artists.map(a => a.name).join(", ")}</div>
          <div className="mt-1 h-0.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-white" style={{ width: duration ? `${Math.min(100, (position / duration) * 100)}%` : "0%" }} />
          </div>
        </Link>
        <div className="flex items-center gap-1">
          <button className="icon-button" onClick={toggle} aria-label={playing ? "Pause" : "Play"} disabled={loading}>
            {loading ? <Loader2 size={17} className="animate-spin" /> : playing ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
          </button>
          <Link className="icon-button hidden sm:flex" href={`/player/${track.id}`} aria-label="Open player"><Maximize2 size={17} /></Link>
        </div>
      </div>
      {error ? (
        <div className="mt-1 flex items-center justify-center gap-1 text-[10px] text-white/45"><AlertCircle size={11} />{error}</div>
      ) : (
        <div className="mt-1 text-center text-[10px] text-white/30">Playback uses an authorized audio provider session.</div>
      )}
    </div>
  );
}
