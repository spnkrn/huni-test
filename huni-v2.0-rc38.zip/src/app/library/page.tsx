"use client";
import { useEffect, useState } from "react";
import { Track } from "@/lib/types";
import { useLocalLibrary } from "@/components/library/local-library-provider";
import { UnifiedLibraryView } from "@/components/library/unified-library-view";
export default function LibraryPage(){const{userId,ready,library}=useLocalLibrary();const[tracks,setTracks]=useState<Track[]>([]);useEffect(()=>{if(!ready)return;if(!userId){setTracks(library);return}fetch('/api/library',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(d=>{if(d)setTracks((d.tracks??[]).filter((x:Track)=>Boolean(x?.id&&x?.title)))}).catch(()=>setTracks(library))},[ready,userId,library]);return <div className="mx-auto max-w-5xl"><div className="eyebrow">Library</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Your library</h1><p className="mt-2 text-sm text-white/40">{userId?'Music, podcast episodes, and follows synced to your Huni account.':'Your saves live on this device until you sign in, then they can sync to your account.'}</p><UnifiedLibraryView tracks={tracks}/></div>}
