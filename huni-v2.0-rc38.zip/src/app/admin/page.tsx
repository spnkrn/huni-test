export const dynamic = "force-dynamic";

import { requireAdmin } from "@/lib/supabase/admin-auth";

export default async function AdminPage() {
  const { user } = await requireAdmin();
  return <div className="mx-auto max-w-5xl"><div className="eyebrow">Admin</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Provider control room</h1><p className="mt-2 text-sm text-white/40">Signed in as {user.email ?? user.id}. Provider health remains read-only until production credentials are configured.</p><div className="glass mt-8 rounded-2xl p-6"><div className="font-medium">Access protected</div><div className="mt-1 text-sm text-white/40">Admin access is controlled by the server-only HUNI_ADMIN_USER_IDS allowlist.</div></div></div>;
}
