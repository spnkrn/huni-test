import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/supabase/require-user";
import { withApiHeaders, sameOrigin, requestId, bodyWithinLimit } from "@/lib/security/api";
import { rateLimit, getRequestFingerprint, rateLimitHeaders } from "@/lib/security/rate-limit";
import { createClient } from "@/lib/supabase/server";

const schema = z.object({ region: z.string().regex(/^[A-Z]{2}$/) });

export async function PATCH(request: NextRequest) {
  const rate = rateLimit(`settings-region:${getRequestFingerprint(request)}`, 20, 60_000);
  const headers = { ...withApiHeaders(request), ...rateLimitHeaders(rate), "X-Request-ID": requestId(request), "Cache-Control": "no-store" };
  if (!rate.allowed) return NextResponse.json({ error: "Too many requests" }, { status: 429, headers });
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-origin request blocked" }, { status: 403, headers });
  if (!bodyWithinLimit(request, 16 * 1024)) return NextResponse.json({ error: "Request body too large" }, { status: 413, headers });
  const { user } = await requireUser();
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400, headers }); }
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid region" }, { status: 400, headers });
  const supabase = await createClient();
  const { error } = await supabase.from("profiles").upsert({ id: user.id, content_region: parsed.data.region }, { onConflict: "id" });
  if (error) return NextResponse.json({ error: "Unable to save region" }, { status: 500, headers });
  return NextResponse.json({ region: parsed.data.region }, { headers });
}
