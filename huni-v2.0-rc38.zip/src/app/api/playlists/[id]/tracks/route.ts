import { NextResponse } from "next/server";
import { bodyWithinLimit, sameOrigin, jsonError, readJson, withApiHeaders } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";
import { isTrack } from "@/lib/persistence";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`playlist-track:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  if (!body || !isTrack(body.track)) return jsonError(request, "Invalid track", 400);
  const { data: playlist } = await supabase.from("playlists").select("id").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!playlist) return jsonError(request, "Playlist not found", 404);
  const { data: last } = await supabase.from("playlist_tracks").select("position").eq("playlist_id", id).order("position", { ascending: false }).limit(1).maybeSingle();
  const position = (last?.position ?? -1) + 1;
  const { error } = await supabase.from("playlist_tracks").upsert({ playlist_id: id, track_id: body.track.id, track: body.track, position });
  if (error) return jsonError(request, "Request could not be completed", 400);
  await supabase.from("playlists").update({ updated_at: new Date().toISOString() }).eq("id", id).eq("user_id", user.id);
  return NextResponse.json({ added: true }, { headers: withApiHeaders(request) });
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`playlist-track:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { id } = await params;
  const trackId = new URL(request.url).searchParams.get("trackId");
  if (!trackId || trackId.length > 512) return jsonError(request, "trackId is required", 400);
  const { data: playlist } = await supabase.from("playlists").select("id").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!playlist) return jsonError(request, "Playlist not found", 404);
  const { error } = await supabase.from("playlist_tracks").delete().eq("playlist_id", id).eq("track_id", trackId);
  if (error) return jsonError(request, "Request could not be completed", 400);
  await supabase.from("playlists").update({ updated_at: new Date().toISOString() }).eq("id", id).eq("user_id", user.id);
  return NextResponse.json({ removed: true }, { headers: withApiHeaders(request) });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`playlist-track-reorder:${getRequestFingerprint(request)}`, 30, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { id } = await params;
  const body = await readJson<Record<string, unknown>>(request);
  const orderedTrackIds = Array.isArray(body?.orderedTrackIds) ? body.orderedTrackIds : null;
  if (!orderedTrackIds || !orderedTrackIds.length || orderedTrackIds.length > 500 || orderedTrackIds.some((value) => typeof value !== "string" || value.length === 0 || value.length > 512)) {
    return jsonError(request, "orderedTrackIds is invalid", 400);
  }
  const uniqueIds = new Set(orderedTrackIds as string[]);
  if (uniqueIds.size !== orderedTrackIds.length) return jsonError(request, "Duplicate track IDs are not allowed", 400);
  const { data: playlist } = await supabase.from("playlists").select("id").eq("id", id).eq("user_id", user.id).maybeSingle();
  if (!playlist) return jsonError(request, "Playlist not found", 404);
  const { data: existing, error: existingError } = await supabase.from("playlist_tracks").select("track_id").eq("playlist_id", id);
  if (existingError) return jsonError(request, "Request could not be completed", 400);
  const existingIds = (existing ?? []).map((row) => row.track_id);
  if (existingIds.length !== orderedTrackIds.length || existingIds.some((trackId) => !uniqueIds.has(trackId))) {
    return jsonError(request, "Playlist changed; reload and try again", 409);
  }
  for (const [position, trackId] of (orderedTrackIds as string[]).entries()) {
    const { error } = await supabase.from("playlist_tracks").update({ position }).eq("playlist_id", id).eq("track_id", trackId);
    if (error) return jsonError(request, "Request could not be completed", 400);
  }
  await supabase.from("playlists").update({ updated_at: new Date().toISOString() }).eq("id", id).eq("user_id", user.id);
  return NextResponse.json({ reordered: true }, { headers: withApiHeaders(request) });
}
