"use client";
import Link from "next/link";
import { PodcastCard } from "@/components/podcasts/podcast-card";
import { useLocalLibrary } from "@/components/library/local-library-provider";
export function FollowedPodcasts({limit=5}:{limit?:number}){const{followedPodcasts}=useLocalLibrary(); if(!followedPodcasts.length)return null; return <section className="mt-14"><div className="mb-5 flex items-end justify-between gap-4"><div><div className="eyebrow">Your shows</div><h2 className="mt-1 text-xl font-semibold">Followed podcasts</h2></div><Link href="/podcasts" className="text-xs text-white/40 hover:text-white">Browse podcasts</Link></div><div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">{followedPodcasts.slice(0,limit).map(p=><PodcastCard key={p.id} podcast={p}/>)}</div></section>}
