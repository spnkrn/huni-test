export const dynamic = "force-dynamic";

import Link from "next/link";
import { CreatePlaylistButton } from "@/components/music/create-playlist-button";
import { requireUser } from "@/lib/supabase/require-user";

export default async function PlaylistsPage() {
  const { supabase, user } = await requireUser();
  const { data: playlists } = await supabase.from("playlists").select("id,name,description,artwork_url,created_at").eq("user_id", user.id).order("updated_at", { ascending: false });
  return <div className="mx-auto max-w-5xl"><div className="eyebrow">Playlists</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Your playlists</h1><div className="mt-8 flex justify-end"><CreatePlaylistButton /></div><div className="mt-4 grid gap-3 sm:grid-cols-2">{playlists?.length ? playlists.map(p => <Link href={`/playlists/${p.id}`} key={p.id} className="glass rounded-2xl p-5 transition hover:bg-white/[.07]"><div className="font-medium">{p.name}</div><div className="mt-1 text-sm text-white/40">{p.description || "No description"}</div></Link>) : <div className="glass col-span-full rounded-2xl p-12 text-center text-sm text-white/35">No playlists yet.</div>}</div></div>;
}

