create table if not exists public.podcast_follows (
  user_id uuid not null references auth.users(id) on delete cascade,
  podcast_id text not null,
  podcast jsonb not null,
  created_at timestamptz not null default now(),
  primary key (user_id, podcast_id)
);
alter table public.podcast_follows enable row level security;
drop policy if exists "podcast_follows_self_all" on public.podcast_follows;
create policy "podcast_follows_self_all" on public.podcast_follows for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
