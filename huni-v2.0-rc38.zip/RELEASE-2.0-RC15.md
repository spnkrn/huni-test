# Huni 2.0 RC.15

## Queue lifecycle

- Persist queue, current index, shuffle, and repeat as one validated player-state record.
- Validate restored queue entries before hydrating the player.
- Clamp restored indices to the recovered queue.
- Add explicit queue removal and full queue clearing.
- Abort pending playback and invalidate the current generation when clearing the queue.
- Prevent an empty queue from retaining an active playback session.

## Verification

Static source coverage was added for queue persistence, restoration validation, and lifecycle clearing. Full dependency-backed certification remains dependent on npm package installation.
