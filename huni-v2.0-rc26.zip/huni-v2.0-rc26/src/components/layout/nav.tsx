"use client";

import Link from "next/link";
import { Home, Search, Library, ListMusic, Radio, MoreHorizontal, ShieldCheck } from "lucide-react";
import { usePathname } from "next/navigation";

const items = [
  ["/", "Home", Home],
  ["/search", "Search", Search],
  ["/podcasts", "Podcasts", Radio],
  ["/library", "Library", Library],
  ["/playlists", "Playlists", ListMusic],
  ["/settings", "More", MoreHorizontal],
  ["/admin", "Admin", ShieldCheck]
] as const;

export function Navigation() {
  const pathname = usePathname();
  return (
    <>
      <aside className="desktop-rail">
        <Link href="/" className="mb-10 px-3 text-xl font-semibold tracking-[-0.04em]">Huni</Link>
        <nav aria-label="Primary navigation" className="space-y-1">
          {items.map(([href, label, Icon]) => (
            <Link key={href} href={href} className={`nav-item ${pathname === href ? "active" : ""}`}>
              <Icon size={18} /> <span>{label}</span>
            </Link>
          ))}
        </nav>
      </aside>
      <nav aria-label="Mobile navigation" className="mobile-nav">
        {items.filter(([href]) => href !== "/admin").map(([href, label, Icon]) => (
          <Link key={href} href={href} className={pathname === href ? "text-white" : "text-white/45"}>
            <Icon size={20} strokeWidth={pathname === href ? 2.4 : 1.8} />
            <span>{label}</span>
          </Link>
        ))}
      </nav>
    </>
  );
}