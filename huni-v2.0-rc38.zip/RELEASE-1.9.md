# Huni 1.9 — Reproducible Build & Release QA

## Purpose

This phase tightens reproducibility and creates a single release gate. It does not claim a green build unless dependencies are actually installed and the full test/build commands have run.

## Required clean-install gate

```bash
npm ci
npm run verify:env
npm run audit:security
npm run typecheck
npm test
npm run test:security
npm run build
npm run qa:release
```

`package-lock.json` is intentionally required for `npm ci`. Generate it in a network-enabled environment with the pinned Node/npm engines from `package.json`, then commit it.

## Security gate

The release check scans source for accidental public secret references and obvious preview-as-playback patterns. This is defense-in-depth and does not replace manual review.

## Current blocker in the build sandbox

Dependency installation has repeatedly timed out, so this environment cannot honestly certify `typecheck`, tests, or `next build` until a clean dependency install completes.
