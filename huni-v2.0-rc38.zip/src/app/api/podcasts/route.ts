import { NextRequest, NextResponse } from "next/server";
import { withApiHeaders } from "@/lib/security/api";
import { getUserContentRegion } from "@/lib/region";
import { searchPodcasts } from "@/lib/providers/podcasts";

export async function GET(req: NextRequest) {
  const headers = withApiHeaders(req);
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const country = (await getUserContentRegion()).region;
  if (!q) return NextResponse.json({ podcasts: [], episodes: [] }, { headers });
  try { return NextResponse.json(await searchPodcasts(q, country), { headers }); }
  catch { return NextResponse.json({ error: "Podcast search temporarily unavailable" }, { status: 502, headers }); }
}
