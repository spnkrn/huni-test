"use client";

import Image from "next/image";
import { GripVertical, X, Trash2, ListX } from "lucide-react";
import { Track } from "@/lib/types";
import { usePlayer } from "./player-context";

export function QueueDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { queue, index, play, removeFromQueue, clearQueue, moveInQueue } = usePlayer();
  if (!open) return null;

  const handleDragStart = (event: React.DragEvent<HTMLDivElement>, fromIndex: number) => {
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", String(fromIndex));
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>, toIndex: number) => {
    event.preventDefault();
    const fromIndex = Number(event.dataTransfer.getData("text/plain"));
    if (Number.isInteger(fromIndex)) moveInQueue(fromIndex, toIndex);
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black/55 backdrop-blur-sm" onClick={onClose}>
      <aside className="absolute right-0 top-0 h-full w-full max-w-md border-l border-white/10 bg-[#0b0b0b]/95 p-5 shadow-2xl backdrop-blur-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <div><div className="eyebrow">Queue</div><div className="mt-1 text-lg font-semibold">Up next</div></div>
          <div className="flex items-center gap-1">
            {queue.length > 0 ? <button className="icon-button" onClick={clearQueue} aria-label="Clear queue" title="Clear queue"><ListX size={18} /></button> : null}
            <button className="icon-button" onClick={onClose} aria-label="Close queue"><X size={18} /></button>
          </div>
        </div>
        <div className="mt-6 space-y-1 overflow-y-auto pb-8">
          {queue.length ? queue.map((item: Track, i) => (
            <div key={`${item.id}-${i}`} draggable onDragStart={(event) => handleDragStart(event, i)} onDragOver={(event) => event.preventDefault()} onDrop={(event) => handleDrop(event, i)} className={`group flex w-full items-center gap-3 rounded-2xl p-2 transition ${i === index ? "bg-white/10" : "hover:bg-white/5"}`}>
              <button onClick={() => play(item)} className="flex min-w-0 flex-1 items-center gap-3 text-left" aria-label={`Play ${item.title}`}>
                <GripVertical size={14} className="shrink-0 cursor-grab text-white/20" aria-hidden="true" />
                <div className="relative size-11 shrink-0 overflow-hidden rounded-xl bg-white/5">{item.artwork?.medium ? <Image src={item.artwork.medium} alt="" fill sizes="44px" className="object-cover" /> : null}</div>
                <div className="min-w-0"><div className="truncate text-sm font-medium">{item.title}</div><div className="truncate text-xs text-white/40">{item.artists.map(a => a.name).join(", ")}</div></div>
              </button>
              <button className="icon-button opacity-50 transition hover:opacity-100" onClick={() => removeFromQueue(item.id)} aria-label={`Remove ${item.title} from queue`} title="Remove from queue"><Trash2 size={16} /></button>
            </div>
          )) : <div className="py-16 text-center text-sm text-white/30">Your queue is empty.</div>}
        </div>
      </aside>
    </div>
  );
}
