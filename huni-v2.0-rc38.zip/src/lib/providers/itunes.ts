import { Album, Artist, SearchResponse, Track } from "@/lib/types";
import { highResArtwork } from "@/lib/utils";

const BASE = "https://itunes.apple.com";

type ITunesResult = {
  wrapperType?: string;
  kind?: string;
  artistId?: number;
  collectionId?: number;
  trackId?: number;
  artistName?: string;
  collectionName?: string;
  trackName?: string;
  artworkUrl60?: string;
  artworkUrl100?: string;
  releaseDate?: string;
  primaryGenreName?: string;
  trackTimeMillis?: number;
  trackNumber?: number;
  trackCount?: number;
  collectionArtistName?: string;
  artistLinkUrl?: string;
  previewUrl?: string;
};

function artistFrom(r: ITunesResult): Artist {
  return {
    id: `itunes-artist-${r.artistId ?? r.artistName ?? "unknown"}`,
    name: r.artistName ?? "Unknown Artist",
    providerIds: { itunes: r.artistId ? String(r.artistId) : undefined }
  };
}

function trackFrom(r: ITunesResult): Track {
  const artwork = highResArtwork(r.artworkUrl100, 1000);
  return {
    id: `itunes-track-${r.trackId ?? `${r.artistName}-${r.trackName}`}`,
    title: r.trackName ?? "Unknown Track",
    artists: [artistFrom(r)],
    album: r.collectionName ? {
      id: `itunes-album-${r.collectionId ?? r.collectionName}`,
      title: r.collectionName,
      artwork: artwork ? { small: r.artworkUrl100, medium: artwork, large: artwork } : undefined,
      releaseDate: r.releaseDate
    } : undefined,
    durationMs: r.trackTimeMillis,
    trackNumber: r.trackNumber,
    releaseDate: r.releaseDate,
    genre: r.primaryGenreName ? [r.primaryGenreName] : [],
    artwork: artwork ? { small: r.artworkUrl60, medium: artwork, large: artwork } : undefined,
    providerIds: { itunes: r.trackId ? String(r.trackId) : undefined },
    previewUrl: r.previewUrl
  };
}

function albumFrom(r: ITunesResult): Album {
  const artwork = highResArtwork(r.artworkUrl100, 1200);
  return {
    id: `itunes-album-${r.collectionId ?? r.collectionName}`,
    title: r.collectionName ?? "Unknown Album",
    artist: artistFrom(r),
    artwork: artwork ? { small: r.artworkUrl100, medium: artwork, large: artwork } : undefined,
    releaseDate: r.releaseDate,
    genre: r.primaryGenreName ? [r.primaryGenreName] : [],
    trackCount: r.trackCount,
    providerIds: { itunes: r.collectionId ? String(r.collectionId) : undefined }
  };
}

export async function searchITunes(term: string, country = "US"): Promise<SearchResponse> {
  const url = new URL("/search", BASE);
  url.searchParams.set("term", term);
  url.searchParams.set("country", country);
  url.searchParams.set("media", "music");
  url.searchParams.set("limit", "50");

  const res = await fetch(url, { next: { revalidate: 300 } });
  if (!res.ok) throw new Error(`iTunes search failed: ${res.status}`);
  const data = (await res.json()) as { results: ITunesResult[] };

  const tracks: Track[] = [];
  const albums = new Map<string, Album>();
  const artists = new Map<string, Artist>();

  for (const r of data.results ?? []) {
    if (r.artistName) artists.set(String(r.artistId ?? r.artistName), artistFrom(r));
    if (r.kind === "song" && r.trackName) tracks.push(trackFrom(r));
    if (r.collectionName && r.collectionId) albums.set(String(r.collectionId), albumFrom(r));
  }

  return { tracks, albums: [...albums.values()], artists: [...artists.values()] };
}

export async function lookupAlbum(collectionId: string, country = "US") {
  const url = new URL("/lookup", BASE);
  url.searchParams.set("id", collectionId);
  url.searchParams.set("entity", "song");
  url.searchParams.set("country", country);

  const res = await fetch(url, { next: { revalidate: 3600 } });
  if (!res.ok) throw new Error(`iTunes album lookup failed: ${res.status}`);
  const data = (await res.json()) as { results: ITunesResult[] };
  const [first, ...songs] = data.results ?? [];
  if (!first) return null;

  const album = albumFrom(first);
  album.tracks = songs.filter(s => s.kind === "song").map(trackFrom);
  album.trackCount = album.tracks.length || album.trackCount;
  return album;
}

export async function lookupTrack(trackId: string, country = "US") {
  const url = new URL("/lookup", BASE);
  url.searchParams.set("id", trackId);
  url.searchParams.set("country", country);

  const res = await fetch(url, { next: { revalidate: 3600 } });
  if (!res.ok) throw new Error(`iTunes track lookup failed: ${res.status}`);
  const data = (await res.json()) as { results: ITunesResult[] };
  return data.results[0] ? trackFrom(data.results[0]) : null;
}

export async function lookupArtist(artistId: string, country = "US") {
  const url = new URL("/lookup", BASE);
  url.searchParams.set("id", artistId);
  url.searchParams.set("entity", "album");
  url.searchParams.set("country", country);
  url.searchParams.set("limit", "200");
  const res = await fetch(url, { next: { revalidate: 3600 } });
  if (!res.ok) throw new Error(`iTunes artist lookup failed: ${res.status}`);
  const data = (await res.json()) as { results: ITunesResult[] };
  const [artistResult, ...releases] = data.results ?? [];
  if (!artistResult) return null;
  const artist = artistFrom(artistResult);
  const albums = new Map<string, Album>();
  for (const r of releases) {
    if (r.collectionId && r.collectionName) albums.set(String(r.collectionId), albumFrom(r));
  }
  return { artist, albums: [...albums.values()] };
}
