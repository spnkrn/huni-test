export type Podcast = {
  id: string;
  collectionId: string;
  title: string;
  author: string;
  artwork?: string;
  description?: string;
  feedUrl?: string;
  appleUrl?: string;
  genre?: string[];
  provider: "itunes" | "apple-rss";
  rank?: number;
};

export type PodcastEpisode = {
  id: string;
  podcastId: string;
  title: string;
  author: string;
  description?: string;
  artwork?: string;
  publishedAt?: string;
  durationMs?: number;
  enclosureType?: string;
  episodeUrl?: string;
  appleUrl?: string;
  guid?: string;
  episodeNumber?: number;
  seasonNumber?: number;
  explicit?: boolean;
  chapters?: PodcastChapter[];
};

export type PodcastChapter = {
  startSeconds: number;
  title: string;
  href?: string;
};

export type PodcastSearchResponse = { podcasts: Podcast[]; episodes: PodcastEpisode[] };
