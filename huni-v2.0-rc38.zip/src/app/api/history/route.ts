import { NextResponse } from "next/server";
import { bodyWithinLimit, sameOrigin, jsonError, readJson, withApiHeaders } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";
import { getRequestFingerprint, rateLimit } from "@/lib/security/rate-limit";
import { isTrack } from "@/lib/persistence";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError(request, "Cross-origin request blocked", 403);
  if (!bodyWithinLimit(request)) return jsonError(request, "Request body too large", 413);
  const mutationLimit = rateLimit(`history:${getRequestFingerprint(request)}`, 60, 60_000);
  if (!mutationLimit.allowed) return jsonError(request, "Too many requests", 429, mutationLimit);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const body = await readJson<Record<string, unknown>>(request);
  if (!body || !isTrack(body.track)) return jsonError(request, "Invalid track", 400);
  const { error } = await supabase.from("listening_history").insert({ user_id: user.id, track_id: body.track.id, track: body.track, position_seconds: typeof body.positionSeconds === "number" ? body.positionSeconds : null, completed: Boolean(body.completed) });
  if (error) return jsonError(request, "Request could not be completed", 400);
  return NextResponse.json({ recorded: true }, { headers: withApiHeaders(request) });
}


export async function GET(request: Request) {
  const limitRaw = new URL(request.url).searchParams.get("limit");
  const limit = Math.min(Math.max(Number(limitRaw ?? 20) || 20, 1), 100);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return jsonError(request, "Unauthorized", 401);
  const { data, error } = await supabase.from("listening_history")
    .select("track, played_at, position_seconds, completed")
    .eq("user_id", user.id)
    .order("played_at", { ascending: false })
    .limit(limit);
  if (error) return jsonError(request, "History could not be loaded", 400);
  const seen = new Set<string>();
  const tracks = (data ?? []).flatMap((row) => {
    if (!isTrack(row.track) || seen.has(row.track.id)) return [];
    seen.add(row.track.id);
    return [{ track: row.track, playedAt: row.played_at, positionSeconds: row.position_seconds, completed: row.completed }];
  });
  return NextResponse.json({ tracks }, { headers: withApiHeaders(request) });
}
