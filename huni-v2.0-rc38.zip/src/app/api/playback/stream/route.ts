import { NextResponse } from "next/server";
import { getPlaybackSession } from "@/lib/playback/session-store";
import { verifyPlaybackToken } from "@/lib/playback/token";
import { getRequestFingerprint, rateLimit, rateLimitHeaders } from "@/lib/security/rate-limit";
import { requestId } from "@/lib/security/api";
import { createClient } from "@/lib/supabase/server";
import { assertSafeUrl, assertSafePodcastUrl } from "@/lib/providers/http";

function headersFor(request: Request, limit?: ReturnType<typeof rateLimit>) {
  return {
    "Cache-Control": "private, no-store",
    "X-Request-ID": requestId(request),
    ...(limit ? rateLimitHeaders(limit) : {}),
  };
}

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token");
  if (!token || token.length > 4096) {
    return NextResponse.json({ error: "Invalid playback token" }, { status: 401, headers: headersFor(request) });
  }

  const claims = verifyPlaybackToken(token);
  if (!claims) {
    return NextResponse.json({ error: "Invalid or expired playback token" }, { status: 401, headers: headersFor(request) });
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || user.id !== claims.userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401, headers: headersFor(request) });
  }

  const session = await getPlaybackSession(claims.sessionId, claims.userId);
  if (!session || session.claims.userId !== claims.userId || session.claims.trackId !== claims.trackId || session.claims.provider !== claims.provider) {
    return NextResponse.json({ error: "Playback session unavailable" }, { status: 404, headers: headersFor(request) });
  }

  const limit = rateLimit(`stream:${getRequestFingerprint(request, claims.userId)}`, 240, 60_000);
  const baseHeaders = headersFor(request, limit);
  if (!limit.allowed) {
    return NextResponse.json({ error: "Too many stream requests" }, { status: 429, headers: { ...baseHeaders, "Retry-After": String(Math.max(1, Math.ceil((limit.resetAt - Date.now()) / 1000))) } });
  }

  const url = new URL(request.url);
  const upstream = url.searchParams.get("download") === "1" ? session.downloadUrl : session.streamUrl;
  if (!upstream) return NextResponse.json({ error: "Download is unavailable" }, { status: 404, headers: baseHeaders });
  try {
    if (claims.provider === "podcast") await assertSafePodcastUrl(upstream);
    else assertSafeUrl(upstream);
  } catch {
    return NextResponse.json({ error: "Playback upstream is not allowed" }, { status: 502, headers: baseHeaders });
  }

  const headers = new Headers();
  const range = request.headers.get("range");
  if (range) headers.set("range", range);
  const ifRange = request.headers.get("if-range");
  if (ifRange) headers.set("if-range", ifRange);
  const ifNoneMatch = request.headers.get("if-none-match");
  if (ifNoneMatch) headers.set("if-none-match", ifNoneMatch);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(upstream, { headers, cache: "no-store", redirect: "manual", signal: controller.signal });
    if (response.status >= 300 && response.status < 400) {
      return NextResponse.json({ error: "Playback upstream redirect rejected" }, { status: 502, headers: baseHeaders });
    }
    const output = new Headers(baseHeaders);
    output.set("X-Content-Type-Options", "nosniff");
    for (const name of ["accept-ranges", "content-length", "content-range", "content-type", "etag", "last-modified"]) {
      const value = response.headers.get(name);
      if (value) output.set(name, value);
    }
    if (url.searchParams.get("download") === "1") output.set("Content-Disposition", 'attachment; filename="huni-audio"');
    return new NextResponse(response.body, { status: response.status, headers: output });
  } catch {
    return NextResponse.json({ error: "Upstream playback request failed" }, { status: 502, headers: baseHeaders });
  } finally {
    clearTimeout(timeout);
  }
}
