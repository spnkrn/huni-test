export type LogContext = Record<string, string | number | boolean | null | undefined>;

function scrub(context: LogContext) {
  const blocked = /token|secret|password|authorization|cookie|streamurl|downloadurl|appsecret/i;
  return Object.fromEntries(Object.entries(context).filter(([key]) => !blocked.test(key)));
}

export function logEvent(event: string, context: LogContext = {}) {
  const payload = JSON.stringify({
    timestamp: new Date().toISOString(),
    event,
    ...scrub(context),
  });
  if (process.env.NODE_ENV === "production") console.log(payload);
  else console.info(payload);
}

export function logError(event: string, error: unknown, context: LogContext = {}) {
  logEvent(event, {
    ...context,
    error: error instanceof Error ? error.message : "unknown-error",
  });
}
