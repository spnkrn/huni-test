import { Artist } from "@/lib/types";

const BASE = process.env.MUSICBRAINZ_BASE_URL || "https://musicbrainz.org/ws/2";
const USER_AGENT = process.env.MUSICBRAINZ_USER_AGENT || "Huni/0.1.0 (contact unavailable)";

let lastRequest = 0;

async function mbFetch(path: string, params: Record<string, string>) {
  const wait = Math.max(0, 1000 - (Date.now() - lastRequest));
  if (wait) await new Promise(r => setTimeout(r, wait));
  lastRequest = Date.now();

  const url = new URL(`${BASE}/${path}`);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  url.searchParams.set("fmt", "json");

  const res = await fetch(url, {
    headers: { "User-Agent": USER_AGENT },
    next: { revalidate: 86400 }
  });
  if (!res.ok) throw new Error(`MusicBrainz failed: ${res.status}`);
  return res.json();
}

export async function searchMusicBrainzArtists(query: string): Promise<Artist[]> {
  const data = await mbFetch("artist", { query, limit: "10" }) as {
    artists?: Array<{ id: string; name: string; country?: string; type?: string }>;
  };
  return (data.artists ?? []).map(a => ({
    id: `mb-artist-${a.id}`,
    name: a.name,
    country: a.country,
    type: a.type,
    musicbrainzId: a.id
  }));
}

export async function getMusicBrainzArtist(id: string): Promise<Artist | null> {
  const rawId = id.replace(/^mb-artist-/, "");
  const data = await mbFetch(`artist/${rawId}`, { inc: "url-rels+genres" }) as {
    id: string; name: string; country?: string; type?: string;
  };
  return {
    id: `mb-artist-${data.id}`,
    name: data.name,
    country: data.country,
    type: data.type,
    musicbrainzId: data.id
  };
}