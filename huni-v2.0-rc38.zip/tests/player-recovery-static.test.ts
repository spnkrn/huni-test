import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("player playback recovery", () => {
  it("rejects stale session responses after a newer playback operation", () => {
    const source = readFileSync(resolve(process.cwd(), "src/components/player/player-context.tsx"), "utf8");
    expect(source).toContain("playbackGenerationRef");
    expect(source).toContain("generation !== playbackGenerationRef.current");
    expect(source).toContain("sessionRequestRef.current?.abort()");
  });

  it("keeps Media Session playback state synchronized", () => {
    const source = readFileSync(resolve(process.cwd(), "src/components/player/player-context.tsx"), "utf8");
    expect(source).toContain("nav.mediaSession.playbackState = playing ? "playing" : "paused"");
  });

  it("retries an authorized session once after a stream error", () => {
    const source = readFileSync(resolve(process.cwd(), "src/components/player/player-context.tsx"), "utf8");
    expect(source).toContain("recoveryAttemptedRef");
    expect(source).toContain("void attachAndPlay(failedTrack)");
    expect(source).toContain("recoveryAttemptedRef.current !== failedTrack.id");
    expect(source).toContain("recoveryAttemptedRef.current = null");
  });
});
