"use client";

import Image from "next/image";
import Link from "next/link";
import { Play } from "lucide-react";
import { TrackActions } from "@/components/music/track-actions";
import { Track } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";
import { formatDuration } from "@/lib/utils";

export function TrackRow({ track, index }: { track: Track; index?: number }) {
  const { play } = usePlayer();
  const art = track.artwork?.medium;
  return (
    <div className="track-row group">
      <div className="w-8 text-center text-xs text-white/30">{index ?? ""}</div>
      <div className="relative size-11 overflow-hidden rounded-[9px] bg-white/5">
        {art ? <Image src={art} alt="" fill sizes="44px" className="object-cover" /> : null}
        <button onClick={() => play(track)} className="absolute inset-0 hidden place-items-center bg-black/55 group-hover:grid">
          <Play size={16} fill="currentColor" />
        </button>
      </div>
      <div className="min-w-0 flex-1">
        <Link href={`/song/${track.id}`} className="block truncate text-sm font-medium hover:underline">{track.title}</Link>
        <div className="truncate text-xs text-white/45">{track.artists.map(a => a.name).join(", ")}</div>
      </div>
      <Link href={track.album ? `/album/${track.album.id}` : "#"} className="hidden max-w-[24%] truncate text-xs text-white/35 hover:text-white md:block">
        {track.album?.title}
      </Link>
      <span className="w-12 text-right text-xs tabular-nums text-white/30">{formatDuration(track.durationMs)}</span>
      <TrackActions track={track} />
    </div>
  );
}