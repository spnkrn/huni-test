import { AudioProvider, QobuzAudioProvider } from "@/lib/providers/audio";

export function getAudioProviders(): AudioProvider[] {
  return [new QobuzAudioProvider()];
}

export function getConfiguredAudioProvider(): AudioProvider | null {
  return getAudioProviders().find((provider) => provider.isConfigured()) ?? null;
}
