# Huni 2.0 RC.18

## Listening progress & resume

- Added `listening_progress`, a per-user track progress table protected by RLS.
- Added authenticated `/api/history/progress` GET/POST endpoints with input validation, same-origin protection for mutations, rate limiting, and no-store response headers.
- Player restores a saved position after authorized playback metadata is available.
- Player periodically persists progress and saves the current position when paused.
- Completed tracks persist their final duration and completion state.
- Resume and progress persistence are best-effort and never block playback.

## Verification

Static QA and security audit should be run before release packaging. Full dependency-backed typecheck, tests, lint, and Next production build remain dependent on a working npm dependency installation environment.
