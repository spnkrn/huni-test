import Image from "next/image";
import Link from "next/link";
import { Album } from "@/lib/types";

export function AlbumCard({ album }: { album: Album }) {
  return (
    <Link href={`/album/${album.id}`} className="group min-w-0">
      <div className="art-card">
        {album.artwork?.medium ? <Image src={album.artwork.medium} alt="" fill sizes="(max-width: 768px) 42vw, 190px" className="object-cover transition duration-500 group-hover:scale-[1.03]" /> : null}
      </div>
      <div className="mt-3 truncate text-sm font-medium">{album.title}</div>
      <div className="truncate text-xs text-white/45">{album.artist.name}</div>
    </Link>
  );
}