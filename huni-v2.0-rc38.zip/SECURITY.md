# Security model

- Do not put provider secrets in `NEXT_PUBLIC_*`.
- Do not expose upstream signed URLs or credentials.
- Do not implement an unrestricted `?url=` proxy.
- Playback sessions should be opaque, short-lived and server-side mapped to a known provider source.
- Any server-side URL fetch should allowlist provider hosts and reject private/link-local destinations.
- Add authentication and Supabase RLS before enabling user libraries or admin settings.
- Do not log access tokens, secrets or upstream signed URLs.

### Playback sessions

Set `PLAYBACK_SESSION_SECRET` to a random server-only value of at least 32 characters. Never expose it through a `NEXT_PUBLIC_*` variable. Playback session responses use `Cache-Control: private, no-store` because authenticated session material must not be cached across users.

## v0.7 audio gateway safeguards

- Gateway URL is server-only.
- Gateway hostname must be explicitly allowlisted.
- Only HTTPS gateway/stream URLs are accepted.
- Gateway calls use `cache: no-store` and an 8-second timeout.
- Returned playback sessions are schema-validated.
- Browser requests contain canonical track IDs, never arbitrary upstream URLs.
- Provider cache contains metadata only and is not readable through browser RLS.

## Playback boundary

The browser cannot submit an upstream audio URL. `/api/playback/session` accepts only a canonical track ID and requires an authenticated Supabase user. The server resolves metadata and delegates playback authorization to the configured provider adapter. Provider gateway URLs and returned stream URLs are HTTPS-only and hostname-allowlisted, and gateway calls are time-limited.

Playback responses are `private, no-store` because they contain short-lived session information. Provider credentials must remain server-side.

## v1.1 / v1.2 browser caching
The service worker never caches `/api/*`, `/auth/*`, audio/provider traffic, or Next image optimization responses. It only caches static browser assets after a successful network response. Authenticated pages remain dynamic. This follows the principle that refreshed SSR auth responses must not be shared through a CDN/cache between users.

## v1.3 production gate

Before deploying, run `npm run verify:env` with the production environment loaded. Never commit `.env.local` or service-role credentials. Authenticated pages are explicitly dynamic to avoid shared-cache leakage, and playback responses are `private, no-store`.

For Supabase SSR, keep the browser and server clients separate and use the current `@supabase/ssr` flow. Supabase currently recommends validating authenticated access with `getClaims()`/`getUser()` as appropriate rather than trusting `getSession()` alone in server protection code.

## v1.4 API abuse controls

- Public metadata/search/lyrics/status endpoints have bounded per-instance rate limits and return `429` with `Retry-After` when exceeded.
- Playback-session creation is limited per authenticated user/IP fingerprint to reduce provider abuse.
- API responses include a request ID for correlation without logging secrets or upstream signed URLs.
- Structured server logs scrub fields whose names commonly contain secrets, tokens, cookies, authorization values, or upstream URLs.
- The included limiter is intentionally dependency-free and process-local. Multi-instance deployments MUST replace it with a shared rate-limit store before relying on it as the sole abuse-control layer.

## v1.5 RC notes

- Health checks must not expose configuration values or provider credentials.
- Authenticated/private API responses use `no-store` and must not be placed in a shared CDN cache.
- Provider match records are server-managed and are not readable through browser RLS policies.
- Production rate limiting must use a shared store when multiple application instances can receive the same user's traffic.

## Authentication redirect policy

The `next` parameter accepted by authentication flows is restricted to a relative path on the Huni origin. Absolute URLs and protocol-relative URLs are rejected and replaced with `/library` (or the route-specific fallback).

## v1.7 API hardening

State-changing API routes reject cross-origin requests when the browser supplies an `Origin` header that does not match the request origin. Mutation endpoints also enforce a conservative request-body size limit. These controls are defense-in-depth and do not replace authentication or Supabase RLS.

Run `npm run audit:security` before deployment to catch API routes that omit the expected hardening helpers.
