-- Huni v1.5 production hardening.
-- Apply after 0001_huni_baseline.sql through Supabase migrations.

alter table public.playlists
  add constraint playlists_name_length check (char_length(name) between 1 and 120);

alter table public.playlists
  add constraint playlists_description_length check (description is null or char_length(description) <= 1000);

alter table public.playlist_tracks
  add constraint playlist_tracks_position_nonnegative check (position >= 0);

alter table public.listening_history
  add constraint listening_history_position_nonnegative check (position_seconds is null or position_seconds >= 0);

alter table public.provider_matches
  add constraint provider_matches_score_range check (score between 0 and 100);

create index if not exists library_tracks_user_created_idx
  on public.library_tracks(user_id, created_at desc);

create index if not exists playlists_user_updated_idx
  on public.playlists(user_id, updated_at desc);

create index if not exists favorites_user_created_idx
  on public.track_favorites(user_id, created_at desc);

create index if not exists listening_history_user_track_played_idx
  on public.listening_history(user_id, track_id, played_at desc);
