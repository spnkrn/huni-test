"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Play, Clock3 } from "lucide-react";
import type { Track } from "@/lib/types";
import { localStore } from "@/lib/local-store";
import { usePlayer } from "@/components/player/player-context";

export function RecentMedia({ limit = 8 }: { limit?: number }) {
  const [items, setItems] = useState<Array<{ track: Track; playedAt: string; positionSeconds?: number; completed?: boolean }>>([]);
  const { play } = usePlayer();
  const refresh = () => setItems(localStore.recentHistory(limit));
  useEffect(() => { refresh(); const fn = () => refresh(); window.addEventListener("huni-local-store", fn); return () => window.removeEventListener("huni-local-store", fn); }, [limit]);
  if (!items.length) return null;
  return <section className="mt-14">
    <div className="mb-5 flex items-end justify-between gap-4"><div><div className="eyebrow">Your listening</div><h2 className="mt-1 text-xl font-semibold">Recently played</h2></div><Link href="/library" className="text-xs text-white/40 hover:text-white">Open library</Link></div>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {items.map(({ track, playedAt }) => { const art = track.artwork?.medium ?? track.artwork?.small ?? track.artwork?.large; const href = track.mediaType === "podcast" && track.podcastId ? `/podcast-episode/${track.id}` : `/song/${track.id}`; return <div key={track.id} className="glass group flex min-w-0 items-center gap-3 rounded-2xl p-3">
        <div className="relative size-12 shrink-0 overflow-hidden rounded-xl bg-white/5">{art ? <Image src={art} alt="" fill sizes="48px" className="object-cover" /> : null}<button onClick={() => play(track)} aria-label={`Play ${track.title}`} className="absolute inset-0 grid place-items-center bg-black/45 opacity-0 transition group-hover:opacity-100"><Play size={15} fill="currentColor" /></button></div>
        <div className="min-w-0 flex-1"><Link href={href} className="block truncate text-sm font-medium hover:underline">{track.title}</Link><div className="truncate text-xs text-white/35">{track.mediaType === "podcast" ? (track.podcastTitle ?? "Podcast") : track.artists.map(a => a.name).join(", ")}</div><div className="mt-1 flex items-center gap-1 text-[10px] text-white/25"><Clock3 size={10}/>{new Date(playedAt).toLocaleDateString()}</div></div>
      </div> })}
    </div>
  </section>;
}
