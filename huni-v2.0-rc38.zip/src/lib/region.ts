import { createClient } from "@/lib/supabase/server";
import { DEFAULT_REGION } from "@/lib/region-options";

export async function getUserContentRegion() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { region: DEFAULT_REGION, userId: null };
    const { data } = await supabase.from("profiles").select("content_region").eq("id", user.id).maybeSingle();
    return { region: (data?.content_region || DEFAULT_REGION).toUpperCase(), userId: user.id };
  } catch {
    return { region: DEFAULT_REGION, userId: null };
  }
}
