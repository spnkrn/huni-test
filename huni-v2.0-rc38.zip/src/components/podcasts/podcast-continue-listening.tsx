"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Play } from "lucide-react";
import { usePlayer } from "@/components/player/player-context";
import type { Track } from "@/lib/types";
import { localStore } from "@/lib/local-store";

export function PodcastContinueListening() {
  const [items, setItems] = useState<Array<{ track: Track; position_seconds: number; duration_seconds?: number | null }>>([]);
  const { play } = usePlayer();
  useEffect(() => { const load=async()=>{ const local=Object.values(localStore.snapshot().progress).filter(x=>x.track.mediaType==="podcast"&&!x.completed&&x.positionSeconds>5).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)).slice(0,12).map(x=>({track:x.track,position_seconds:x.positionSeconds,duration_seconds:x.durationSeconds})); const remote=await fetch("/api/history/progress?podcasts=true&limit=12", { cache: "no-store" }).then(r=>r.ok?r.json():null).catch(()=>null); const remoteItems=(remote?.progress??[]).filter((x:any)=>x?.track&&!x.completed&&Number(x.position_seconds??0)>5); const merged=new Map<string, any>(); for(const x of remoteItems) merged.set(x.track.id,x); for(const x of local) if(!merged.has(x.track.id)) merged.set(x.track.id,x); setItems([...merged.values()].slice(0,12) as typeof local); }; void load(); const fn=()=>void load(); window.addEventListener("huni-local-store",fn); return()=>window.removeEventListener("huni-local-store",fn); }, []);
  if (!items.length) return null;
  return <section className="mt-16">
    <div className="mb-5"><div className="eyebrow">For you</div><h2 className="mt-1 text-xl font-semibold">Continue listening</h2></div>
    <div className="grid gap-3 md:grid-cols-2">
      {items.map(({ track, position_seconds, duration_seconds }) => {
        const percent = duration_seconds && duration_seconds > 0 ? Math.min(100, position_seconds / duration_seconds * 100) : 0;
        return <button key={track.id} onClick={() => play(track)} className="glass group flex min-w-0 items-center gap-3 rounded-2xl p-3 text-left transition hover:bg-white/[.07]">
          <div className="relative size-14 shrink-0 overflow-hidden rounded-xl bg-white/5">{track.artwork?.medium || track.artwork?.large ? <Image src={(track.artwork.medium ?? track.artwork.large)!} alt="" fill sizes="56px" className="object-cover" /> : null}<span className="absolute inset-0 grid place-items-center bg-black/30 opacity-0 transition group-hover:opacity-100"><Play size={17} fill="currentColor" /></span></div>
          <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{track.title}</div><div className="truncate text-xs text-white/40">{track.podcastTitle ?? "Podcast"}</div><div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-white/65" style={{ width: `${percent}%` }} /></div></div>
          <span className="shrink-0 text-[10px] text-white/30">{Math.floor(position_seconds / 60)}m</span>
        </button>;
      })}
    </div>
  </section>;
}
