"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Play, ArrowLeft, Maximize2 } from "lucide-react";
import { Track, Lyrics } from "@/lib/types";
import { usePlayer } from "@/components/player/player-context";
import { LyricsView } from "@/components/lyrics/lyrics-view";
import { ProviderProvenance } from "@/components/metadata/provider-provenance";

export default function SongPage({ params }: { params: Promise<{ id: string }> }) {
  const [track, setTrack] = useState<Track | null>(null);
  const [lyrics, setLyrics] = useState<Lyrics | null>(null);
  const { play } = usePlayer();

  useEffect(() => {
    params.then(({ id }) => fetch(`/api/track/${id}`).then(r => r.ok ? r.json() : null).then(async t => {
      setTrack(t);
      if (t) {
        const qs = new URLSearchParams({
          track: t.title,
          artist: t.artists[0]?.name ?? "",
          ...(t.album?.title ? { album: t.album.title } : {}),
          ...(t.durationMs ? { duration: String(Math.round(t.durationMs / 1000)) } : {})
        });
        const lr = await fetch(`/api/lyrics?${qs}`);
        if (lr.ok) setLyrics(await lr.json());
      }
    }));
  }, [params]);

  if (!track) return <div className="py-24 text-center text-sm text-white/35">Loading track…</div>;
  const art = track.artwork?.large ?? track.artwork?.medium;

  return (
    <div className="mx-auto max-w-6xl">
      <Link href="/search" className="mb-8 inline-flex items-center gap-2 text-xs text-white/40 hover:text-white"><ArrowLeft size={15} /> Back</Link>
      <div className="grid gap-12 lg:grid-cols-[360px_1fr]">
        <div>
          <div className="relative aspect-square overflow-hidden rounded-[28px] border border-white/10 bg-white/5">
            {art ? <Image src={art} alt="" fill sizes="360px" className="object-cover" priority /> : null}
          </div>
          <div className="mt-5 flex items-center gap-2">
            <button onClick={() => play(track)} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-medium text-black"><Play size={16} fill="currentColor" /> Play</button>
            <Link href={`/player/${track.id}`} className="icon-button"><Maximize2 size={17} /></Link>
          </div>
        </div>
        <div>
          <div className="eyebrow">Song</div>
          <h1 className="mt-2 text-4xl font-semibold tracking-[-.05em] md:text-6xl">{track.title}</h1>
          <div className="mt-3 text-lg text-white/55">{track.artists.map(a => a.name).join(", ")}</div>
          <ProviderProvenance entity={track} />
          <div className="mt-8 border-t border-white/10 pt-6">
            <div className="grid grid-cols-2 gap-5 text-xs">
              <Meta label="Album" value={track.album?.title} />
              <Meta label="Release" value={track.releaseDate?.slice(0, 10)} />
              <Meta label="Genre" value={track.genre?.join(", ")} />
              <Meta label="ISRC" value={track.isrc} />
            </div>
          </div>
          <div className="mt-14">
            <div className="eyebrow mb-4">Lyrics</div>
            {lyrics ? <LyricsView lyrics={lyrics} /> : <div className="text-sm text-white/35">Loading lyrics…</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
function Meta({ label, value }: { label: string; value?: string }) {
  return <div><div className="text-white/25">{label}</div><div className="mt-1 text-white/65">{value || "—"}</div></div>;
}