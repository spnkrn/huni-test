export const dynamic = "force-dynamic";

import { requireUser } from "@/lib/supabase/require-user";
import { Track } from "@/lib/types";
import { TrackRow } from "@/components/music/track-row";
import { LibraryControls } from "./library-controls";

export default async function LibraryPage() {
  const { supabase, user } = await requireUser();
  const { data: tracks } = await supabase.from("library_tracks").select("track_id, track, created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(100);
  const libraryTracks = (tracks ?? []).map((row) => row.track as Track).filter((track) => track?.id && track?.title);
  return (
    <div className="mx-auto max-w-5xl">
      <div className="eyebrow">Library</div>
      <h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Your library</h1>
      <p className="mt-2 text-sm text-white/40">Saved music follows your Huni account.</p>
      {libraryTracks.length ? <>
        <LibraryControls tracks={libraryTracks} />
        <div className="mt-8 space-y-2">{libraryTracks.map((track, index) => <TrackRow key={track.id} track={track} index={index + 1} />)}</div>
      </> : <div className="glass mt-10 rounded-2xl p-12 text-center text-sm text-white/35">Your library is empty. Save tracks from search or album pages with the heart button.</div>}
    </div>
  );
}
