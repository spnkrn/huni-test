import { describe, expect, it, beforeEach } from "vitest";
import { issuePlaybackToken, verifyPlaybackToken } from "@/lib/playback/token";

describe("playback session tokens", () => {
  beforeEach(() => {
    process.env.PLAYBACK_SESSION_SECRET = "test-secret-that-is-long-enough-32-chars";
  });

  it("issues and verifies a token", () => {
    const token = issuePlaybackToken({ userId: "u1", trackId: "t1", provider: "qobuz" });
    const claims = verifyPlaybackToken(token);
    expect(claims?.userId).toBe("u1");
    expect(claims?.trackId).toBe("t1");
  });

  it("rejects tampering", () => {
    const token = issuePlaybackToken({ userId: "u1", trackId: "t1", provider: "qobuz" });
    const parts = token.split(".");
    parts[1] = parts[1].slice(0, -1) + (parts[1].endsWith("A") ? "B" : "A");
    expect(verifyPlaybackToken(parts.join("."))).toBeNull();
  });

  it("rejects invalid TTLs", () => {
    expect(() => issuePlaybackToken({ userId: "u1", trackId: "t1", provider: "qobuz" }, 0)).toThrow();
    expect(() => issuePlaybackToken({ userId: "u1", trackId: "t1", provider: "qobuz" }, 3601)).toThrow();
  });

  it("rejects expired tokens", () => {
    const token = issuePlaybackToken({ userId: "u1", trackId: "t1", provider: "qobuz" }, -1);
    expect(verifyPlaybackToken(token)).toBeNull();
  });
});
