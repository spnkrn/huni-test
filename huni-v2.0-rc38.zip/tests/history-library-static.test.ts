import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(process.cwd());

describe("RC20 history/library integration", () => {
  it("history API exposes deduplicated authenticated tracks", () => {
    const source = readFileSync(resolve(root, "src/app/api/history/route.ts"), "utf8");
    expect(source).toContain("export async function GET");
    expect(source).toContain("new Set<string>()");
    expect(source).toContain("listening_history");
  });
  it("favorites page preserves favorite ordering and supports batch playback", () => {
    const page = readFileSync(resolve(root, "src/app/favorites/page.tsx"), "utf8");
    const controls = readFileSync(resolve(root, "src/app/favorites/favorite-controls.tsx"), "utf8");
    expect(page).toContain("track_favorites");
    expect(page).toContain("in(\"track_id\", ids)");
    expect(controls).toContain("playTracks(tracks)");
    expect(controls).toContain("playTracks(tracks, 0, true)");
  });
  it("deliberate track changes create a fresh history play boundary", () => {
    const source = readFileSync(resolve(root, "src/components/player/player-context.tsx"), "utf8");
    expect(source).toContain("historyRecordedRef.current = null;");
  });
});
