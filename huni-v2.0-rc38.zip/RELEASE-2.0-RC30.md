# Huni 2.0 RC30 — Local-first library & account sync

- Anonymous users can favorite tracks and podcast episodes, save media, and create/edit local playlists without authentication.
- Local-first data is stored in `localStorage` under a versioned Huni store.
- Library, favorites and playlist surfaces work without an account.
- Authenticated users continue to write authoritative data to Supabase.
- On sign-in, local favorites, library items, playlists/tracks and recent history are migrated to the authenticated account; local state is cleared only after the migration completes successfully.
- On sign-out, account-local cached data is cleared from the local store.
- Podcast episodes use the same local favorite/save/playlist path as songs.
- Playback progress and history fall back to local storage when an account is unavailable, and authenticated playback remains server-backed.
- Protected account settings/admin routes remain protected; library and playlists are intentionally public-capable client surfaces.
- Added regression-oriented local store and anonymous-flow checks.
