# Huni 2.0 RC33

## Offline/local downloads
- Replaced browser-triggered downloads with a real IndexedDB offline store.
- Downloaded authorized audio is stored as a Blob on the device.
- The shared player checks the offline store before requesting a network playback session.
- Added an Offline Downloads page and navigation entry.
- Downloads can be removed from the device.
- Works for podcast episodes and music tracks when the authorized provider exposes a download URL.

## Browser reality
- Offline playback is device/browser storage, not a server cache.
- Storage is subject to browser quota and eviction rules; users should not treat it as permanent file storage.
- iOS/Safari and private browsing can impose tighter storage limits.
- The app cannot guarantee unlimited offline storage or OS-level background downloading.
- A downloaded Blob remains playable while the browser's origin storage remains available.

## Security
- The original upstream publisher/provider URL is not stored in the browser metadata.
- Downloads still require an authorized Huni playback session.
- This is not DRM circumvention.
