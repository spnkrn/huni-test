"use client";

import { useEffect, useState } from "react";
import { CONTENT_REGIONS, DEFAULT_REGION } from "@/lib/region-options";

export default function SettingsPage() {
  const [email, setEmail] = useState("");
  const [region, setRegion] = useState(DEFAULT_REGION);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => { fetch("/api/settings/profile").then(r => r.ok ? r.json() : null).then(v => { if (v) { setEmail(v.email ?? ""); setRegion(v.region ?? DEFAULT_REGION); } }); }, []);
  async function save(next: string) {
    setRegion(next); setSaved(false); setError("");
    const res = await fetch("/api/settings/region", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ region: next }) });
    if (!res.ok) setError("Could not save your region."); else setSaved(true);
  }

  return <div className="mx-auto max-w-5xl"><div className="eyebrow">Settings</div><h1 className="mt-2 text-4xl font-semibold tracking-[-.05em]">Settings</h1><div className="mt-3 text-sm text-white/40">{email}</div>
    <div className="mt-10 grid gap-3">
      <section className="glass rounded-2xl p-5"><div className="font-medium">Content region</div><p className="mt-1 max-w-2xl text-sm leading-6 text-white/35">Huni uses this storefront region for Apple Music charts and iTunes metadata, and passes it to your authorized Qobuz metadata integration. It does not change your account location with any provider.</p><select value={region} onChange={e => save(e.target.value)} className="mt-5 w-full max-w-sm rounded-xl border border-white/10 bg-black/30 px-3 py-3 text-sm outline-none">{CONTENT_REGIONS.map(([code, name]) => <option key={code} value={code}>{name} ({code})</option>)}</select>{saved ? <div className="mt-2 text-xs text-white/35">Saved.</div> : null}{error ? <div className="mt-2 text-xs text-red-300">{error}</div> : null}</section>
      {["Playback", "Audio quality", "Lyrics", "Appearance", "Privacy", "Providers"].map(x => <div key={x} className="glass rounded-2xl p-5"><div className="font-medium">{x}</div><div className="mt-1 text-sm text-white/35">Configuration surface ready for the provider and persistence layers.</div></div>)}
    </div>
    <form action="/auth/logout" method="post" className="mt-8"><button className="rounded-xl border border-white/10 px-4 py-2 text-sm text-white/70 hover:bg-white/5">Sign out</button></form>
  </div>;
}
