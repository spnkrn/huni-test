import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const configured = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);
  const response = NextResponse.json(
    { status: configured ? "ok" : "degraded", service: "huni", version: "2.0.0-rc.3" },
    { status: configured ? 200 : 503 },
  );
  response.headers.set("Cache-Control", "no-store");
  const id = request.headers.get("x-request-id");
  if (id) response.headers.set("X-Request-ID", id.slice(0, 128));
  return response;
}
